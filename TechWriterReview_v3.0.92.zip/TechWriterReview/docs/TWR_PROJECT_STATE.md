# TechWriterReview - Project State
## Version: 3.0.91d (January 27, 2026)

---

## Project Overview

**TechWriterReview (TWR)** is a Flask-based document analysis tool for technical writers working in government contracting, defense, and aerospace documentation environments. It's designed for **air-gapped Windows networks** with no internet access after initial setup.

### Core Capabilities
- **Document Analysis**: 50+ quality checks for grammar, compliance, spelling, punctuation, requirements language
- **Role Extraction**: AI-powered identification with 94.7% precision across document types
- **RACI Matrix Generation**: Automatically generates RACI matrices from document content
- **Relationship Graph**: D3.js visualization showing role-document relationships
- **Statement Forge**: Extract actionable requirements and procedures
- **Scan History**: Tracks document scans and aggregates roles across documents
- **Docling Integration** (v3.0.91+): Advanced AI-powered document extraction with 95% table accuracy
- **Built-in Update System**: Apply patches from local files without reinstalling

### Technology Stack
- **Backend**: Python 3.10+, Flask, Waitress (WSGI)
- **Frontend**: Vanilla JS (ES6+), D3.js, Chart.js, Lucide icons
- **Database**: SQLite (scan_history.db, roles.db)
- **Document Processing**: Docling (preferred), python-docx, pdfplumber, PyMuPDF, Camelot, Tabula
- **AI/NLP**: Docling layout/table models, spaCy, scikit-learn (all optional, all offline)

---

## Installation Path (Flat Mode - v3.0.91d+)

\`\`\`
TechWriterReview/               # Main application folder
├── app.py                      # Flask application entry point
├── updates/                    # Drop update files here
│   └── UPDATE_README.md        # Update instructions
├── backups/                    # Auto-created before updates
├── logs/                       # Application logs
└── ...                         # Other source files
\`\`\`

### Quick Start
1. Extract \`TechWriterReview_v3.0.91d.zip\` 
2. Run \`setup.bat\` to create virtual environment and install dependencies
3. Run \`python app.py\` or \`Run_TWR.bat\` to start server
4. Open \`http://localhost:5050\` in browser

---

## Current Version Features (v3.0.91d)

### Role Extraction (v3.0.91d)
| Feature | Status | Notes |
|---------|--------|-------|
| Pattern-based extraction | ✅ | 20+ regex patterns for job titles |
| Known roles database | ✅ | 158 pre-defined roles with aliases |
| False positive filtering | ✅ | 167 exclusions (facilities, processes) |
| Acronym expansion | ✅ | 22 role acronyms (PM, SE, COR, etc.) |
| Table confidence boost | ✅ | +20% for RACI table roles |
| Cross-document validation | ✅ | 94.7% precision, 92.3% F1 score |

### Update System (v3.0.91d)
| Feature | Status | Notes |
|---------|--------|-------|
| Flat mode support | ✅ | updates/ inside app folder |
| Auto-detect app_dir | ✅ | No longer hardcodes "app" |
| Directory-structured updates | ✅ | Mirror app structure |
| Prefix-based updates | ✅ | static_js_features_X.js |
| .txt wrapper support | ✅ | For air-gapped file transfers |
| Automatic backups | ✅ | Created before applying |
| Rollback capability | ✅ | Restore from any backup |

### Backend APIs
| Endpoint | Method | Purpose |
|----------|--------|---------|
| \`/api/upload\` | POST | Upload document for analysis |
| \`/api/review\` | POST | Run analysis with checkers |
| \`/api/roles/aggregated\` | GET | All roles across all documents |
| \`/api/roles/extract\` | GET | Extract roles from current doc |
| \`/api/roles/raci\` | GET | RACI matrix data |
| \`/api/updates/status\` | GET | Update system status |
| \`/api/updates/apply\` | POST | Apply pending updates |
| \`/api/docling/status\` | GET | Docling AI status |

---

## Validation Results (v3.0.91d)

| Document Type | Domain | Precision | Recall | F1 Score |
|---------------|--------|-----------|--------|----------|
| NASA ATOM-4 SOW | Government Contract | 100% | 85.7% | 92.3% |
| DoD SEP Outline | Defense Systems Engineering | 100% | 87.5% | 93.3% |
| Smart Columbus SEMP | Agile/Smart City | 100% | 100% | 100% |
| INCOSE/APM SEPM Guide | Industry Standard | 84.6% | 84.6% | 84.6% |
| **Overall Average** | - | **94.7%** | **90.0%** | **92.3%** |

---

## Recent Development History

| Version | Date | Key Changes |
|---------|------|-------------|
| 3.0.91d | Jan 27 | False positive filtering fix, update manager path fix, doc overhaul |
| 3.0.91c | Jan 27 | Cross-document verification, Agile/Executive roles |
| 3.0.91b | Jan 27 | Role extraction precision 52% → 100% |
| 3.0.91 | Jan 27 | Docling AI integration, air-gap deployment |
| 3.0.90 | Jan 27 | Comprehensive merge of all v3.0.76-89 fixes |

---

## Testing Checklist

After installation, verify:

- [ ] Help → About shows version 3.0.91d
- [ ] Review a document → roles extracted
- [ ] Settings → Updates shows updates/ folder path
- [ ] Place a test file in updates/ → appears in pending updates

---

## Contact / Support

- **In-App Help**: Press F1 or click Help → Documentation
- **Development Notes**: See \`TWR_LESSONS_LEARNED.md\` for patterns and fixes
