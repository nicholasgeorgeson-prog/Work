<#
.SYNOPSIS
    TechWriterReview v3.0.49 Complete Installer
.DESCRIPTION
    Clean install of TechWriterReview - removes old files, handles all edge cases.
    Uses system Python (no virtual environment).
.NOTES
    Run with: Right-click > Run with PowerShell
#>

$ErrorActionPreference = "Continue"
trap {
    Write-Host ""
    Write-Host "ERROR: $_" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

$VERSION = "3.0.49"

# ============================================================
# HEADER
# ============================================================

Clear-Host
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  TechWriterReview v$VERSION - Complete Installer" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$SOURCE = $PSScriptRoot
Write-Host "Source folder: $SOURCE"
Write-Host ""

# ============================================================
# STEP 1: CHECK PYTHON
# ============================================================

Write-Host "[1/5] Checking Python..." -ForegroundColor White

$pythonCmd = $null
try {
    $result = & python --version 2>&1
    if ($result -match "Python (\d+\.\d+)") {
        $pythonCmd = "python"
        Write-Host "      Found: $result" -ForegroundColor Green
    }
} catch {}

if (-not $pythonCmd) {
    try {
        $result = & py --version 2>&1
        if ($result -match "Python (\d+\.\d+)") {
            $pythonCmd = "py"
            Write-Host "      Found: $result" -ForegroundColor Green
        }
    } catch {}
}

if (-not $pythonCmd) {
    Write-Host "      ERROR: Python not found!" -ForegroundColor Red
    Write-Host "      Install Python 3.8+ from https://python.org" -ForegroundColor Yellow
    Write-Host "      Make sure to check 'Add Python to PATH'" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# ============================================================
# STEP 2: CLEAN OLD INSTALLATION
# ============================================================

Write-Host ""
Write-Host "[2/5] Cleaning old installation..." -ForegroundColor White

$APP_DIR = Join-Path $SOURCE "app"

if (Test-Path $APP_DIR) {
    Write-Host "      Removing old app folder..." -ForegroundColor Gray
    Remove-Item -Recurse -Force $APP_DIR -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
}

# Remove old batch files too
@("Run_TWR.bat", "Stop_TWR.bat") | ForEach-Object {
    $f = Join-Path $SOURCE $_
    if (Test-Path $f) { Remove-Item -Force $f -ErrorAction SilentlyContinue }
}

Write-Host "      Clean" -ForegroundColor Green

# ============================================================
# STEP 3: CREATE DIRECTORIES & COPY FILES
# ============================================================

Write-Host ""
Write-Host "[3/5] Creating directories and copying files..." -ForegroundColor White

# Create all needed directories
$directories = @(
    "app",
    "app\templates",
    "app\static",
    "app\static\css",
    "app\static\js",
    "app\static\js\vendor",
    "app\static\js\ui",
    "app\static\js\api",
    "app\static\js\features",
    "app\static\js\utils",
    "app\statement_forge",
    "app\tools"
)

foreach ($dir in $directories) {
    $path = Join-Path $SOURCE $dir
    if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
}

# Copy and rename files
$copied = 0
$errors = 0

Get-ChildItem -Path $SOURCE -Filter "*.txt" -File | ForEach-Object {
    $srcFile = $_
    $srcName = $_.Name
    $destPath = $null
    
    # Handle __PATH__ encoded files (e.g., __PATH__static__css__style__EXT__.css.txt)
    if ($srcName -match "^__PATH__(.+)__EXT__\.(.+)\.txt$") {
        $pathPart = $matches[1]
        $ext = $matches[2]
        
        # Special handling for __init__.py files (encoded as ___INIT___)
        $pathPart = $pathPart -replace "___INIT___", "\__init__"
        $pathPart = $pathPart -replace "__", "\"
        
        $destPath = Join-Path $SOURCE "app\$pathPart.$ext"
    }
    # Handle root-level .py.txt files
    elseif ($srcName -match "^(.+)\.py\.txt$") {
        $destPath = Join-Path $SOURCE "app\$($matches[1]).py"
    }
    # Handle special config files
    elseif ($srcName -eq "requirements.txt.txt") {
        $destPath = Join-Path $SOURCE "app\requirements.txt"
    }
    elseif ($srcName -eq "config.json.txt") {
        $destPath = Join-Path $SOURCE "app\config.json"
    }
    elseif ($srcName -eq "version.json.txt") {
        $destPath = Join-Path $SOURCE "app\version.json"
    }
    # Skip installer/manifest files
    elseif ($srcName -match "^(INSTALLER|MANIFEST|README|FILES|VERIFY|SIMPLE|COMPLETE|DOWNLOAD|DIAGNOSE|twr_|NEXT_SESSION|Run_TWR|Stop_TWR|manifest\.json)") {
        return
    }
    
    if ($destPath) {
        try {
            # Create parent directory if needed
            $destDir = Split-Path -Parent $destPath
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }
            
            Copy-Item -Path $srcFile.FullName -Destination $destPath -Force
            $copied++
            
            # Show progress
            if ($copied % 10 -eq 0) {
                Write-Host "      Copied $copied files..." -ForegroundColor Gray
            }
        } catch {
            Write-Host "      ERROR copying $srcName : $_" -ForegroundColor Red
            $errors++
        }
    }
}

# Fix __init__.py if it was named incorrectly
$wrongInit = Join-Path $SOURCE "app\statement_forge\_INIT_.py"
$correctInit = Join-Path $SOURCE "app\statement_forge\__init__.py"
if ((Test-Path $wrongInit) -and (-not (Test-Path $correctInit))) {
    Rename-Item -Path $wrongInit -NewName "__init__.py" -Force
    Write-Host "      Fixed: __init__.py renamed" -ForegroundColor Yellow
}

Write-Host "      Copied $copied files ($errors errors)" -ForegroundColor Green

# ============================================================
# STEP 4: INSTALL DEPENDENCIES
# ============================================================

Write-Host ""
Write-Host "[4/5] Installing Python dependencies..." -ForegroundColor White
Write-Host "      This may take 1-2 minutes..." -ForegroundColor Gray

$packages = @(
    "flask",
    "waitress", 
    "python-docx",
    "lxml",
    "openpyxl",
    "PyMuPDF",
    "PyPDF2"
)

$pipArgs = @(
    "install"
    "--trusted-host", "pypi.org"
    "--trusted-host", "pypi.python.org"
    "--trusted-host", "files.pythonhosted.org"
    "--quiet"
) + $packages

& $pythonCmd -m pip $pipArgs 2>&1 | Out-Null

# Verify flask installed
try {
    & $pythonCmd -c "import flask" 2>&1 | Out-Null
    Write-Host "      Dependencies installed" -ForegroundColor Green
} catch {
    Write-Host "      WARNING: Some dependencies may be missing" -ForegroundColor Yellow
    Write-Host "      Try running: pip install flask waitress python-docx lxml openpyxl" -ForegroundColor Yellow
}

# ============================================================
# STEP 5: CREATE LAUNCHER SCRIPTS
# ============================================================

Write-Host ""
Write-Host "[5/5] Creating launcher scripts..." -ForegroundColor White

$appPath = Join-Path $SOURCE "app"

# Run_TWR.bat
$runScript = @"
@echo off
title TechWriterReview v$VERSION
cd /d "$appPath"

echo.
echo  ============================================
echo   TechWriterReview v$VERSION
echo  ============================================
echo.
echo  Starting server...
echo  Open http://127.0.0.1:5000 in your browser
echo.
echo  Keep this window open while using the tool.
echo  Press Ctrl+C or close this window to stop.
echo.

python app.py

if errorlevel 1 (
    echo.
    echo  ERROR: Application failed to start!
    echo.
    pause
)
"@

$runScript | Set-Content (Join-Path $SOURCE "Run_TWR.bat") -Encoding ASCII
Write-Host "      Run_TWR.bat created" -ForegroundColor Green

# Stop_TWR.bat
$stopScript = @"
@echo off
title Stop TechWriterReview
echo.
echo  Stopping TechWriterReview server...
echo.

for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5000.*LISTENING" ^| findstr /v "^\s*$"') do (
    echo  Stopping process %%a...
    taskkill /F /PID %%a >nul 2>&1
)

for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5050.*LISTENING" ^| findstr /v "^\s*$"') do (
    echo  Stopping process %%a...
    taskkill /F /PID %%a >nul 2>&1
)

echo.
echo  Server stopped.
echo.
pause
"@

$stopScript | Set-Content (Join-Path $SOURCE "Stop_TWR.bat") -Encoding ASCII
Write-Host "      Stop_TWR.bat created" -ForegroundColor Green

# ============================================================
# VERIFICATION
# ============================================================

Write-Host ""
Write-Host "Verifying installation..." -ForegroundColor White

$checks = @(
    @{ Path = "app\app.py"; Name = "Main application" },
    @{ Path = "app\core.py"; Name = "Core engine" },
    @{ Path = "app\templates\index.html"; Name = "HTML template" },
    @{ Path = "app\static\css\style.css"; Name = "Stylesheet" },
    @{ Path = "app\static\js\app.js"; Name = "Main JavaScript" },
    @{ Path = "app\static\js\features\roles.js"; Name = "Roles module" },
    @{ Path = "app\statement_forge\__init__.py"; Name = "Statement Forge init" },
    @{ Path = "app\statement_forge\routes.py"; Name = "Statement Forge routes" }
)

$allOk = $true
foreach ($check in $checks) {
    $fullPath = Join-Path $SOURCE $check.Path
    if (Test-Path $fullPath) {
        $size = (Get-Item $fullPath).Length
        if ($size -gt 100) {
            Write-Host "      OK: $($check.Name) ($size bytes)" -ForegroundColor Green
        } else {
            Write-Host "      WARNING: $($check.Name) seems too small ($size bytes)" -ForegroundColor Yellow
            $allOk = $false
        }
    } else {
        Write-Host "      MISSING: $($check.Name)" -ForegroundColor Red
        $allOk = $false
    }
}

# ============================================================
# DONE
# ============================================================

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  INSTALLATION COMPLETE!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Location: $SOURCE"
Write-Host ""
Write-Host "  TO START:" -ForegroundColor Cyan
Write-Host "    1. Double-click Run_TWR.bat"
Write-Host "    2. Open http://127.0.0.1:5000 in your browser"
Write-Host ""
Write-Host "  TO STOP:" -ForegroundColor Cyan
Write-Host "    Double-click Stop_TWR.bat (or close the server window)"
Write-Host ""

if (-not $allOk) {
    Write-Host "  WARNING: Some files may be missing or corrupted." -ForegroundColor Yellow
    Write-Host "  Try re-downloading from GitHub and running installer again." -ForegroundColor Yellow
    Write-Host ""
}

$run = Read-Host "  Start TechWriterReview now? (Y/n)"
if ($run -ne 'n') {
    Start-Process (Join-Path $SOURCE "Run_TWR.bat")
    Write-Host ""
    Write-Host "  Server starting... Open http://127.0.0.1:5000" -ForegroundColor Cyan
}

Write-Host ""
Read-Host "  Press Enter to close"
