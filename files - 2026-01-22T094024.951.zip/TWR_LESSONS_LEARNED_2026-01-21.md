# TechWriterReview - Lessons Learned: Installation & File Transfer Issues

**Date:** 2026-01-21  
**Version:** 3.0.49  
**Environment:** Windows 11, PowerShell 5.1, Corporate Network (Air-Gapped)

---

## Summary

Extended debugging session to get TWR installer working on a restricted corporate Windows environment. Multiple issues discovered related to file transfer corruption, OneDrive sync, Outlook security policies, and batch file compatibility.

---

## Issues Encountered & Root Causes

### 1. Installer Crash at Pip Upgrade

**Symptom:** INSTALLER.bat runs but crashes/hangs at Step 6 (Creating virtual environment)

**Root Cause:** This line tries to access the internet:
```batch
"%VENV_PYTHON%" -m pip install --upgrade pip --quiet 2>nul
```

**Fix:** Comment out or skip pip upgrade on air-gapped/restricted networks:
```batch
:: SKIP pip upgrade - can hang on restricted networks
echo           Using bundled pip (skipping upgrade)
```

---

### 2. Batch Files Won't Execute (Window Flashes & Closes)

**Symptom:** Double-clicking .bat file does nothing, or window appears briefly then closes

**Possible Causes:**
- File has wrong line endings (Unix LF vs Windows CRLF)
- File content is corrupted/truncated
- File is a OneDrive placeholder (128 bytes)

**Diagnosis:** Run from command prompt to see errors:
```cmd
cd C:\path\to\folder
INSTALLER.bat
```

If nothing happens (no output), the file is likely corrupted.

---

### 3. Mac → Email → Windows File Transfer Corruption

**Symptom:** Files arrive on Windows with only 128 bytes, content is garbage

**Root Cause:** Multiple factors:
- Mac Mail or Outlook may alter file encoding
- Corporate email security policies strip/modify attachments
- OneDrive Files On-Demand shows placeholders instead of real files

**Key Finding:** Unix line endings (LF) transferred OK, but Windows line endings (CRLF) got corrupted in this specific environment.

---

### 4. OneDrive Files On-Demand (128-byte Placeholders)

**Symptom:** Files appear in folder but are all 128 bytes

**Root Cause:** OneDrive shows cloud-only placeholder files that haven't been downloaded

**Fix:** 
1. Right-click folder → "Always keep on this device"
2. Wait for sync to complete
3. Or move files to a non-OneDrive location (e.g., `C:\TWR_Install`)

---

### 5. Outlook Stripping Attachment Content

**Symptom:** Saving .txt attachments from Outlook results in 128-byte files with no content

**Root Cause:** Corporate security policy strips or modifies certain attachment types

**Fix:** Rename the ZIP file to bypass filters:
- Use `.ngzip` instead of `.zip`
- Email the `.ngzip` file
- Rename back to `.zip` on Windows before extracting

---

## Diagnostic Approach

### Created DIAGNOSE.ps1 Script

When debugging remotely, create a diagnostic script the user can run:

```powershell
$ErrorActionPreference = "Continue"
$out = "DIAGNOSTIC_REPORT.txt"

"=== TWR DIAGNOSTIC REPORT ===" | Out-File $out
"Generated: $(Get-Date)" | Out-File $out -Append

"=== POWERSHELL VERSION ===" | Out-File $out -Append
$PSVersionTable | Out-File $out -Append

"=== EXECUTION POLICY ===" | Out-File $out -Append
Get-ExecutionPolicy -List | Out-File $out -Append

"=== FILES IN FOLDER ===" | Out-File $out -Append
Get-ChildItem -Name | Out-File $out -Append

"=== CHECKING KEY FILES ===" | Out-File $out -Append
$files = @("INSTALLER.bat.txt", "twr_reconstruct.ps1.txt", "manifest.json.txt")
foreach ($f in $files) {
    if (Test-Path $f) {
        "FOUND: $f (Size: $((Get-Item $f).Length) bytes)" | Out-File $out -Append
    } else {
        "MISSING: $f" | Out-File $out -Append
    }
}

"=== PYTHON CHECK ===" | Out-File $out -Append
try {
    $pyver = & python --version 2>&1
    "Python: $pyver" | Out-File $out -Append
} catch {
    "Python not in PATH" | Out-File $out -Append
}

notepad $out
Read-Host "Press Enter to close"
```

**Key Insight:** File sizes revealed the corruption - 128 bytes instead of expected 16,000+ bytes.

---

## Best Practices for Restricted Environments

### 1. File Transfer
- **Never rely on email for individual files** - use ZIP/archive
- **Use obscure file extensions** (`.ngzip`, `.dat`) to bypass email filters
- **Always verify file sizes after transfer** - look for 128-byte placeholders
- **Avoid OneDrive-synced folders** for installation - use `C:\` directly

### 2. Installer Design
- **Skip pip upgrade** - use bundled pip version
- **Provide both .bat and .ps1 installers** - one may transfer better than the other
- **Add verbose output** - so user can see where it fails
- **Keep window open on error** - use `pause` at end

### 3. PowerShell vs Batch
- PowerShell scripts (.ps1) may be more resilient to line ending corruption
- Both require proper line endings to work
- Create files directly in Notepad on Windows if transfer fails

### 4. Offline/Air-Gapped Installation
- Bundle wheel files for fully offline pip install
- Skip any network calls (pip upgrade, hash verification against remote)
- Use `--trusted-host` flags for corporate proxy environments:
  ```
  pip install -r requirements.txt --trusted-host pypi.org --trusted-host files.pythonhosted.org
  ```

---

## Working Transfer Method

1. Create ZIP package on build machine
2. Rename `.zip` → `.ngzip` 
3. Email `.ngzip` file (bypasses most email filters)
4. On Windows: Save to `C:\TWR_Install` (NOT OneDrive)
5. Rename `.ngzip` → `.zip`
6. Right-click → Extract All
7. Verify file sizes (INSTALLER.bat.txt should be ~17KB)
8. Rename `INSTALLER.bat.txt` → `INSTALLER.bat`
9. Run installer

---

## Files That Must Transfer Correctly

| File | Expected Size | Purpose |
|------|---------------|---------|
| INSTALLER.bat.txt | ~17 KB | Main batch installer |
| install_twr.ps1.txt | ~16 KB | PowerShell installer (backup) |
| twr_reconstruct.ps1.txt | ~5 KB | Rebuilds directory tree from manifest |
| manifest.json.txt | ~27 KB | File mapping for reconstruction |
| app.py.txt | ~145 KB | Main Flask application |
| core.py.txt | ~54 KB | Document processing engine |

If any of these are 128 bytes, the transfer failed.

---

## Quick Troubleshooting Checklist

- [ ] File sizes correct? (not 128 bytes)
- [ ] Files in non-OneDrive folder?
- [ ] ZIP extracted successfully?
- [ ] Python 3.8+ installed?
- [ ] Running from command prompt shows errors?
- [ ] PowerShell execution policy allows scripts?

---

## Final Working Solution: GitHub Transfer

Email transfer ultimately failed completely due to corporate security scanning content (not just extensions). The working solution:

1. **Upload to GitHub** - Upload .ngzip file to a GitHub repo
2. **Download on Windows** - Use PowerShell `Invoke-WebRequest` or browser to download
3. **Rename and extract** - `.ngzip` → `.zip` → Extract All
4. **Run COMPLETE_INSTALL.ps1** - Handles everything including `__init__.py` fix

### GitHub Download Script (DOWNLOAD.ps1)
```powershell
$url = "https://github.com/YOUR_REPO/raw/main/TechWriterReview_v3_0_49_COMPLETE.ngzip"
$out = "C:\TWR_Install\TWR.zip"

Write-Host "Downloading from GitHub..."
New-Item -ItemType Directory -Path "C:\TWR_Install" -Force | Out-Null
Invoke-WebRequest -Uri $url -OutFile $out

$size = (Get-Item $out).Length
if ($size -gt 800000) {
    Write-Host "Download OK! Extracting..."
    Expand-Archive -Path $out -DestinationPath "C:\TWR_Install" -Force
    Write-Host "Done!"
} else {
    Write-Host "ERROR: Download failed"
}
```

---

## Additional Issue: `__init__.py` Encoding Bug

**Symptom:** Statement Forge doesn't work, "StatementForge is not defined" error in browser

**Root Cause:** The filename encoding scheme uses `__` as a separator, but `__init__.py` contains `__` in its name. This causes:
- `__init__.py` → encoded as `__PATH__statement_forge___INIT___EXT__.py.txt`
- When decoded, `___INIT___` becomes `_INIT_` instead of `__init__`

**Fix:** The COMPLETE_INSTALL.ps1 automatically renames `_INIT_.py` to `__init__.py`

---

## Additional Issue: Virtual Environment Failure

**Symptom:** Installer crashes at Step 6/9 "Creating virtual environment"

**Root Cause:** Unknown - possibly corporate Python restrictions or venv module issues

**Fix:** Use system Python directly instead of venv. The COMPLETE_INSTALL.ps1 skips venv creation and installs packages to system Python.

---

## Version History

| Date | Issue | Resolution |
|------|-------|------------|
| 2026-01-21 | Pip upgrade hangs | Skip pip upgrade |
| 2026-01-21 | Batch files won't run | Transfer corruption - use ZIP with .ngzip extension |
| 2026-01-21 | 128-byte files | OneDrive + Outlook stripping content - save to C:\ directly |
| 2026-01-22 | Email strips all attachments | Use GitHub for file transfer |
| 2026-01-22 | Venv creation fails | Skip venv, use system Python |
| 2026-01-22 | `__init__.py` named wrong | Auto-rename in installer |
| 2026-01-22 | roles.js truncated/corrupted | Re-download fresh from GitHub |
