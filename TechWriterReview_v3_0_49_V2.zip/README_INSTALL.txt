================================================================================
  TechWriterReview v3.0.49 - Air-Gapped Installation Guide
================================================================================

OVERVIEW
--------
TechWriterReview is a Flask-based document analysis application for air-gapped
Windows environments. It analyzes technical documents (DOCX, PDF) against
enterprise writing standards.

SYSTEM REQUIREMENTS
-------------------
* Operating System: Windows 10/11 (build 1903+), Windows Server 2016+
* Python: 3.8 or later
* PowerShell: 5.0 or later (for hash verification)
* Browser: Chrome, Edge, or Firefox (modern versions)
* Disk Space: ~200MB (including dependencies)
* Memory: 2GB RAM minimum recommended

QUICK START (3 STEPS)
---------------------
1. Extract this transport package to a folder (e.g., C:\TWR_Install)

2. Rename INSTALLER.bat.txt to INSTALLER.bat and run it
   - Or from command prompt: copy INSTALLER.bat.txt INSTALLER.bat && INSTALLER.bat
   - Default install location: %LOCALAPPDATA%\TWR
   - You will be prompted to accept or change this location

3. After installation, use:
   - Run_TWR.bat to start the server
   - Stop_TWR.bat to stop the server
   - Open http://127.0.0.1:5000 in your browser

INSTALLATION OPTIONS
--------------------
The installer supports command-line options:

  INSTALLER.bat [/INSTALL_DIR=path] [/ONLINE=1]

  /INSTALL_DIR=path    Install to a custom directory
  /ONLINE=1            Allow online pip install (requires internet)

Examples:
  INSTALLER.bat
  INSTALLER.bat /INSTALL_DIR=C:\Apps\TWR
  INSTALLER.bat /ONLINE=1

AIR-GAPPED INSTALLATION (NO INTERNET)
-------------------------------------
For fully air-gapped environments, you have two options:

Option A: Bundle wheels (recommended)
  1. On a connected machine with Python installed:
     pip download -d wheels Flask waitress python-docx lxml openpyxl PyMuPDF PyPDF2
  2. Copy the 'wheels' folder into the install directory before running installer
  3. Run INSTALLER.bat - it will use bundled wheels automatically

Option B: Pre-install dependencies
  1. On the target machine, manually install required packages:
     pip install Flask waitress python-docx lxml openpyxl PyMuPDF PyPDF2
  2. Run INSTALLER.bat - it will detect installed packages

PACKAGE INTEGRITY
-----------------
All files (including installer scripts) have SHA-256 hashes in manifest.json.txt.
The installer verifies these automatically before installation.

To manually verify before installation:
  1. Open PowerShell
  2. Navigate to the extracted folder
  3. Run: powershell -ExecutionPolicy Bypass -File twr_verify.ps1.txt "."

Files verified include:
  - All application source files (*.py, *.js, *.css, *.html)
  - Installer scripts (INSTALLER.bat, Run_TWR.bat, Stop_TWR.bat)
  - PowerShell helper scripts (twr_verify.ps1, twr_reconstruct.ps1)
  - This README

SERVER CONFIGURATION
--------------------
The server binds to the host and port specified in Run_TWR.bat.
Default: http://127.0.0.1:5000

To change the port:
  1. Edit Run_TWR.bat after installation
  2. Change the PORT variable at line 18
  3. The app reads TWR_HOST and TWR_PORT environment variables

Environment variables (set before running app.py):
  - TWR_HOST: Server host (default: 127.0.0.1)
  - TWR_PORT: Server port (default: 5000)
  - TWR_DEBUG: Enable debug mode (default: false)

PRODUCTION SERVER
-----------------
The application uses Waitress (a production-grade WSGI server) when available.
If Waitress is not installed, it falls back to Flask's built-in development
server with threading enabled.

For production deployments, ensure Waitress is installed:
  pip install waitress

CONFIGURATION FILES
-------------------
config.json (in app/ directory):
  - Currently only controls CSP (Content Security Policy) settings
  - The 'allow_cdn_fallback' option controls whether CDN fallback is permitted
  - Runtime settings (host/port/logging) are controlled via environment variables

Note: config.json does NOT control host, port, or logging configuration.
Those are set via environment variables (TWR_HOST, TWR_PORT, etc.).

INSTALLED STRUCTURE
-------------------
After installation, the directory structure will be:

  <install_dir>\
  +-- app\                   Application files
  |   +-- app.py             Main Flask application
  |   +-- config.json        CSP configuration (see note above)
  |   +-- requirements.txt   Python dependencies
  |   +-- static\            CSS, JS, images
  |   |   +-- css\           Stylesheets
  |   |   +-- js\            JavaScript modules
  |   |       +-- vendor\    Third-party libraries
  |   +-- templates\         HTML templates
  |   +-- statement_forge\   Statement Forge modules
  |   +-- tools\             Utility scripts
  +-- .venv\                 Python virtual environment
  +-- logs\                  Application logs
  +-- Run_TWR.bat            Start server
  +-- Stop_TWR.bat           Stop server
  +-- install.log            Installation log

TROUBLESHOOTING
---------------
Problem: "Python not found"
Solution: Install Python 3.8+ and ensure it's in PATH.
          Download from https://python.org (on a connected machine)
          The installer also checks common installation locations.

Problem: "Hash verification failed"
Solution: The transport package may be corrupted. Re-extract or re-download.

Problem: "Failed to install dependencies"
Solution: For air-gapped systems, bundle wheel files or use /ONLINE=1 on a
          connected system first.

Problem: "Port already in use"
Solution: Edit Run_TWR.bat to change the PORT variable, or stop whatever
          is using the port.

Problem: "Module not found" errors
Solution: The virtual environment may be incomplete. Delete .venv\ and run
          INSTALLER.bat again with /ONLINE=1.

Problem: ANSI colors not displaying (shows [91m instead of red)
Solution: Enable Virtual Terminal Processing in Windows:
          reg add HKCU\Console /v VirtualTerminalLevel /t REG_DWORD /d 1

Problem: "favicon.ico not found" (404 in browser console)
Solution: This is harmless. The favicon file is optional and not included
          in the default package.

LOGS
----
* Installation log: <install_dir>\install.log
* Server log: <install_dir>\logs\server_YYYYMMDD_HHMMSS.log
* Server errors: <install_dir>\logs\server_error.log
* Application logs: <install_dir>\app\logs\ (created at runtime)

KNOWN LIMITATIONS
-----------------
1. Favicon: A favicon.ico file is not included. The browser will show a
   404 error for /favicon.ico which is harmless.

2. ANSI Colors: The installer and run/stop scripts use ANSI color codes
   which may not display correctly on older Windows versions or terminals
   that don't support Virtual Terminal Processing.

3. WMIC Deprecation: This version does NOT use WMIC commands, using
   PowerShell equivalents instead for better compatibility with Windows 11.

VERSION INFORMATION
-------------------
Package Version: 3.0.49
Build Date: 2026-01-22
Python Requirement: >=3.8

Dependencies:
- Flask >=2.0.0
- waitress >=2.0.0 (production WSGI server)
- python-docx >=0.8.11
- lxml >=4.9.0
- openpyxl >=3.0.0
- PyMuPDF >=1.22.0
- PyPDF2 >=3.0.0

CHANGELOG (v3.0.49)
-------------------
- Fixed: Port mismatch - Run_TWR.bat now sets TWR_PORT env var correctly
- Fixed: Run_TWR.bat uses Windows-compatible logging (no Unix 'tee')
- Fixed: Static file serving properly handles nested paths (ui/state.js)
- Fixed: PowerShell scripts use positional args for paths with spaces
- Fixed: Added statement_forge/__init__.py for proper package imports
- Fixed: index.html path lookup checks templates/ directory first
- Fixed: Statement Forge imports support both package and flat layouts
- Fixed: WMIC removed - uses PowerShell for timestamps and process checks
- Fixed: ANSI colors now use proper ESC sequences (Windows 10+)
- Fixed: Installer scripts now included in hash verification
- Added: waitress to requirements.txt for production WSGI server
- Added: Documentation for config.json scope and environment variables

================================================================================
  End of Installation Guide
================================================================================
