/**
 * TechWriterReview Help Content Renderer
 * ======================================
 * Handles help modal rendering, navigation, and search
 * Version: 2.9.6
 * 
 * Issue #55: Complete help content overhaul
 * Issue #25: Full-screen modal support
 * Issue #26: Revision history integration
 */

'use strict';

const HelpContent = {
    version: '2.9.6',
    currentSection: 'quick-start',
    scrollPositions: {},
    
    // Initialize help system
    init: function() {
        console.log('[HelpContent] Initializing v' + this.version);
        
        this.bindEvents();
        this.buildNavigation();
        this.renderSection('quick-start');
        
        console.log('[HelpContent] Initialized');
    },
    
    // Build sidebar navigation from HelpDocs structure
    buildNavigation: function() {
        const sidebar = document.querySelector('.help-sidebar');
        if (!sidebar || !window.HelpDocs) return;
        
        // Clear existing navigation (keep header)
        const existingSections = sidebar.querySelectorAll('.help-nav-section');
        existingSections.forEach(s => s.remove());
        
        // Build from HelpDocs.navigation
        const nav = HelpDocs.navigation;
        
        nav.forEach(section => {
            const sectionEl = document.createElement('div');
            sectionEl.className = 'help-nav-section';
            
            // Section title (not clickable if has subsections)
            if (section.subsections && section.subsections.length > 0) {
                const titleEl = document.createElement('div');
                titleEl.className = 'help-nav-title';
                titleEl.textContent = section.title;
                sectionEl.appendChild(titleEl);
                
                // Add subsection buttons
                section.subsections.forEach(sub => {
                    const btn = this.createNavButton(sub.id, sub.title, sub.icon);
                    sectionEl.appendChild(btn);
                });
            } else {
                // Single section without subsections
                const btn = this.createNavButton(section.id, section.title, section.icon);
                sectionEl.appendChild(btn);
            }
            
            sidebar.appendChild(sectionEl);
        });
        
        // Add footer
        const footer = document.createElement('div');
        footer.className = 'help-nav-footer';
        footer.innerHTML = `
            <span class="help-version">v${HelpDocs.version}</span>
            <span class="help-credit">Nicholas Georgeson</span>
        `;
        sidebar.appendChild(footer);
    },
    
    // Create navigation button
    createNavButton: function(id, title, icon) {
        const btn = document.createElement('button');
        btn.className = 'help-tab';
        btn.setAttribute('data-tab', id);
        btn.innerHTML = `<i data-lucide="${icon || 'file'}"></i> ${title}`;
        
        btn.addEventListener('click', () => {
            this.navigateTo(id);
        });
        
        return btn;
    },
    
    // Navigate to a section
    navigateTo: function(sectionId) {
        // Save current scroll position
        const mainContent = document.querySelector('.help-main');
        if (mainContent && this.currentSection) {
            this.scrollPositions[this.currentSection] = mainContent.scrollTop;
        }
        
        // Update active state
        document.querySelectorAll('.help-tab').forEach(tab => {
            tab.classList.remove('active');
            if (tab.getAttribute('data-tab') === sectionId) {
                tab.classList.add('active');
            }
        });
        
        // Render section
        this.renderSection(sectionId);
        this.currentSection = sectionId;
        
        // Restore scroll position if we've been here before
        if (mainContent && this.scrollPositions[sectionId]) {
            mainContent.scrollTop = this.scrollPositions[sectionId];
        } else if (mainContent) {
            mainContent.scrollTop = 0;
        }
    },
    
    // Render a section
    renderSection: function(sectionId) {
        const mainContent = document.querySelector('.help-main');
        if (!mainContent || !window.HelpDocs) return;
        
        const section = HelpDocs.content[sectionId];
        if (!section) {
            console.warn('[HelpContent] Section not found:', sectionId);
            mainContent.innerHTML = `
                <div class="help-section">
                    <h1>Section Not Found</h1>
                    <p>The help section "${sectionId}" could not be found.</p>
                </div>
            `;
            return;
        }
        
        mainContent.innerHTML = `
            <div class="help-section" id="help-${sectionId}">
                <div class="help-article-header">
                    <h1>${section.title}</h1>
                    ${section.subtitle ? `<p class="help-subtitle">${section.subtitle}</p>` : ''}
                </div>
                <div class="help-article-content">
                    ${section.html}
                </div>
            </div>
        `;
        
        // Re-initialize Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    },
    
    // Bind events
    bindEvents: function() {
        // Search input
        const searchInput = document.getElementById('help-search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });
            
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    searchInput.value = '';
                    this.closeSearchResults();
                }
            });
        }
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            // Only if help modal is visible
            const helpModal = document.getElementById('modal-help');
            if (!helpModal || !helpModal.classList.contains('active')) return;
            
            if (e.key === 'Escape') {
                // Close help modal
                helpModal.classList.remove('active');
            }
        });
        
        // Close search results when clicking outside
        document.addEventListener('click', (e) => {
            const searchContainer = document.querySelector('.help-search-container');
            if (searchContainer && !searchContainer.contains(e.target)) {
                this.closeSearchResults();
            }
        });
    },
    
    // Handle search
    handleSearch: function(query) {
        if (!query || query.length < 2) {
            this.closeSearchResults();
            return;
        }
        
        if (!window.HelpDocs || !HelpDocs.search) return;
        
        const results = HelpDocs.search(query);
        this.showSearchResults(results, query);
    },
    
    // Show search results
    showSearchResults: function(results, query) {
        let dropdown = document.querySelector('.help-search-results');
        
        if (!dropdown) {
            dropdown = document.createElement('div');
            dropdown.className = 'help-search-results';
            const searchContainer = document.querySelector('.help-search-container');
            if (searchContainer) {
                searchContainer.appendChild(dropdown);
            }
        }
        
        if (results.length === 0) {
            dropdown.innerHTML = `
                <div class="help-search-empty">
                    No results found for "${query}"
                </div>
            `;
        } else {
            dropdown.innerHTML = results.map(r => `
                <div class="help-search-result" data-section="${r.id}">
                    <div class="help-search-result-title">${r.title}</div>
                    ${r.subtitle ? `<div class="help-search-result-subtitle">${r.subtitle}</div>` : ''}
                </div>
            `).join('');
            
            // Add click handlers
            dropdown.querySelectorAll('.help-search-result').forEach(item => {
                item.addEventListener('click', () => {
                    const sectionId = item.getAttribute('data-section');
                    this.navigateTo(sectionId);
                    this.closeSearchResults();
                    document.getElementById('help-search-input').value = '';
                });
            });
        }
        
        dropdown.classList.add('active');
    },
    
    // Close search results
    closeSearchResults: function() {
        const dropdown = document.querySelector('.help-search-results');
        if (dropdown) {
            dropdown.classList.remove('active');
        }
    },
    
    // Open help to specific section
    openToSection: function(sectionId) {
        const helpModal = document.getElementById('modal-help');
        if (helpModal) {
            helpModal.classList.add('active');
            this.navigateTo(sectionId);
        }
    },
    
    // Print current section
    printSection: function() {
        const content = document.querySelector('.help-main');
        if (!content) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>TechWriterReview Help - ${HelpDocs.content[this.currentSection]?.title || 'Help'}</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
                    h1 { color: #1a1a1a; }
                    h2 { color: #333; margin-top: 24px; }
                    table { border-collapse: collapse; width: 100%; margin: 16px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background: #f5f5f5; }
                    code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; }
                    kbd { background: #eee; padding: 2px 6px; border-radius: 3px; border: 1px solid #ccc; }
                    ul, ol { padding-left: 24px; }
                    .help-tip, .help-callout { background: #f0f7ff; border-left: 4px solid #3b82f6; padding: 12px; margin: 16px 0; }
                </style>
            </head>
            <body>
                ${content.innerHTML}
                <hr>
                <p style="color: #666; font-size: 12px;">Printed from TechWriterReview v${HelpDocs.version} Help</p>
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }
};

// Export format info (kept for compatibility)
HelpContent.exportFormats = {
    word: { title: 'Word Document (.docx)', description: 'Professional report with full formatting.' },
    csv: { title: 'CSV Spreadsheet', description: 'Tabular format for tracking and analysis.' },
    json: { title: 'JSON Data', description: 'Structured data for programmatic processing.' },
    xlsx: { title: 'Excel Report (.xlsx)', description: 'Professional formatted report.' }
};

// Severity info (kept for compatibility)
HelpContent.severityLevels = {
    Critical: { description: 'Must be fixed before release', color: '#DC3545' },
    High: { description: 'Should be fixed soon', color: '#FD7E14' },
    Medium: { description: 'Should be addressed', color: '#FFC107' },
    Low: { description: 'Minor improvements', color: '#28A745' },
    Info: { description: 'Informational only', color: '#17A2B8' }
};

// Initialize on DOM ready
if (typeof window !== 'undefined') {
    window.HelpContent = HelpContent;
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            // Wait for HelpDocs to load
            setTimeout(() => HelpContent.init(), 100);
        });
    } else {
        setTimeout(() => HelpContent.init(), 100);
    }
}

console.log('[HelpContent] Module loaded v2.9.6');
