/**
 * TechWriterReview Help Documentation System
 * ==========================================
 * Comprehensive documentation for all features.
 * Version: 2.9.6
 * 
 * Issue #55: Complete help content overhaul
 * Issue #25: Full-screen modal support
 * Issue #26: Revision history integration
 */

'use strict';

const HelpDocs = {
    version: '2.9.6',
    lastUpdated: '2026-01-19',
    
    // Help system configuration
    config: {
        searchEnabled: true,
        printEnabled: true,
        keyboardNav: true,
        rememberPosition: true
    },
    
    // Navigation structure with icons
    navigation: [
        { id: 'getting-started', title: 'Getting Started', icon: 'rocket', subsections: [
            { id: 'quick-start', title: 'Quick Start', icon: 'zap' },
            { id: 'first-review', title: 'Your First Review', icon: 'play-circle' },
            { id: 'interface-tour', title: 'Interface Tour', icon: 'layout' }
        ]},
        { id: 'document-review', title: 'Document Review', icon: 'file-search', subsections: [
            { id: 'loading-docs', title: 'Loading Documents', icon: 'upload' },
            { id: 'review-types', title: 'Review Types & Presets', icon: 'sliders' },
            { id: 'understanding-results', title: 'Understanding Results', icon: 'bar-chart-2' }
        ]},
        { id: 'checkers', title: 'Quality Checkers', icon: 'check-square', subsections: [
            { id: 'checker-acronyms', title: 'Acronym Checker', icon: 'a-large-small' },
            { id: 'checker-grammar', title: 'Grammar & Spelling', icon: 'spell-check' },
            { id: 'checker-hyperlinks', title: 'Hyperlink Checker', icon: 'link' },
            { id: 'checker-requirements', title: 'Requirements Language', icon: 'list-checks' },
            { id: 'checker-writing', title: 'Writing Quality', icon: 'pen-tool' },
            { id: 'checker-structure', title: 'Document Structure', icon: 'layers' },
            { id: 'checker-all', title: 'Complete Reference', icon: 'list' }
        ]},
        { id: 'roles', title: 'Roles & Responsibilities', icon: 'users', subsections: [
            { id: 'role-detection', title: 'Role Detection', icon: 'user-search' },
            { id: 'role-adjudication', title: 'Adjudication', icon: 'check-circle' },
            { id: 'role-dictionary', title: 'Role Dictionary', icon: 'book' },
            { id: 'role-graph', title: 'Relationship Graph', icon: 'git-branch' },
            { id: 'role-matrix', title: 'RACI Matrix', icon: 'grid-3x3' }
        ]},
        { id: 'statement-forge', title: 'Statement Forge', icon: 'hammer', subsections: [
            { id: 'forge-overview', title: 'Overview', icon: 'info' },
            { id: 'forge-extraction', title: 'Statement Extraction', icon: 'filter' },
            { id: 'forge-editing', title: 'Editing Statements', icon: 'edit-3' },
            { id: 'forge-export', title: 'Export Formats', icon: 'download' }
        ]},
        { id: 'exporting', title: 'Exporting Results', icon: 'download', subsections: [
            { id: 'export-word', title: 'Word Document Export', icon: 'file-text' },
            { id: 'export-reports', title: 'PDF Reports', icon: 'file' },
            { id: 'export-data', title: 'CSV & Excel Export', icon: 'table' }
        ]},
        { id: 'settings', title: 'Settings', icon: 'settings', subsections: [
            { id: 'settings-general', title: 'General Settings', icon: 'sliders' },
            { id: 'settings-appearance', title: 'Appearance & Themes', icon: 'palette' },
            { id: 'settings-updates', title: 'Updates', icon: 'refresh-cw' },
            { id: 'settings-diagnostics', title: 'Diagnostics', icon: 'activity' }
        ]},
        { id: 'shortcuts', title: 'Keyboard Shortcuts', icon: 'keyboard' },
        { id: 'troubleshooting', title: 'Troubleshooting', icon: 'wrench', subsections: [
            { id: 'trouble-common', title: 'Common Issues', icon: 'alert-circle' },
            { id: 'trouble-errors', title: 'Error Messages', icon: 'alert-triangle' },
            { id: 'trouble-help', title: 'Getting Help', icon: 'life-buoy' }
        ]},
        { id: 'version-history', title: 'Version History', icon: 'history' },
        { id: 'about', title: 'About', icon: 'info' }
    ],

    // ========================================================================
    // CONTENT SECTIONS
    // ========================================================================
    content: {}
};

// Getting Started - Quick Start
HelpDocs.content['quick-start'] = {
    title: 'Quick Start',
    subtitle: 'Get your first document review in under 30 seconds',
    html: `
<div class="help-intro-box">
    <p>TechWriterReview analyzes technical documents for quality issues, standards compliance, and organizational structure. Follow these five steps to run your first review.</p>
</div>

<div class="help-steps">
    <div class="help-step">
        <div class="help-step-number">1</div>
        <div class="help-step-content">
            <h3>Load Your Document</h3>
            <p>Drag and drop a file onto the window, or click <strong>Open</strong> in the sidebar.</p>
            <div class="help-formats">
                <span class="format-badge">.docx</span>
                <span class="format-badge">.pdf</span>
                <span class="format-badge">.txt</span>
                <span class="format-badge">.rtf</span>
            </div>
            <div class="help-tip"><i data-lucide="lightbulb"></i> Word documents (.docx) provide the richest analysis including tracked changes export.</div>
        </div>
    </div>

    <div class="help-step">
        <div class="help-step-number">2</div>
        <div class="help-step-content">
            <h3>Select Your Checks</h3>
            <p>Choose a preset or configure individual checks:</p>
            <ul>
                <li><strong>All</strong> - Enable all 50+ quality checks</li>
                <li><strong>PrOP</strong> - Procedures & Operating Procedures</li>
                <li><strong>PAL</strong> - Process Asset Library documents</li>
                <li><strong>FGOST</strong> - Flight & Ground Operations</li>
                <li><strong>SOW</strong> - Statement of Work</li>
            </ul>
        </div>
    </div>

    <div class="help-step">
        <div class="help-step-number">3</div>
        <div class="help-step-content">
            <h3>Run the Review</h3>
            <p>Click <strong>Review</strong> or press <kbd>Ctrl</kbd>+<kbd>R</kbd>. Analysis typically takes 5-30 seconds depending on document size.</p>
        </div>
    </div>

    <div class="help-step">
        <div class="help-step-number">4</div>
        <div class="help-step-content">
            <h3>Review the Results</h3>
            <p>Issues appear sorted by severity. The dashboard shows:</p>
            <ul>
                <li><strong>Quality Score</strong> - Letter grade based on issue density</li>
                <li><strong>Severity Chart</strong> - Click segments to filter issues</li>
                <li><strong>Readability Metrics</strong> - Flesch, Flesch-Kincaid, Fog Index</li>
            </ul>
        </div>
    </div>

    <div class="help-step">
        <div class="help-step-number">5</div>
        <div class="help-step-content">
            <h3>Export Your Results</h3>
            <p>Click <strong>Export</strong> to create:</p>
            <ul>
                <li><strong>Word Document</strong> - Issues as comments with track changes</li>
                <li><strong>CSV/Excel</strong> - Tabular format for tracking</li>
                <li><strong>JSON</strong> - Structured data for automation</li>
            </ul>
        </div>
    </div>
</div>

<div class="help-callout help-callout-success">
    <i data-lucide="check-circle"></i>
    <div>
        <strong>Congratulations!</strong>
        <p>You've completed your first review. Explore sections below for advanced features like role extraction, scan history, and issue families.</p>
    </div>
</div>
`
};

// Getting Started - First Review
HelpDocs.content['first-review'] = {
    title: 'Your First Review',
    subtitle: 'A detailed walkthrough of the review process',
    html: `
<p>This guide walks you through a complete document review, explaining each step and highlighting important features.</p>

<h2>Before You Begin</h2>
<p>Ensure you have:</p>
<ul>
    <li>A document ready to review (.docx recommended for full features)</li>
    <li>TechWriterReview running in your browser (default: http://localhost:5050)</li>
    <li>Sufficient time - a thorough review of a 50-page document takes about 15 minutes</li>
</ul>

<h2>Step 1: Load Your Document</h2>
<p>When the application loads, you'll see the main workspace with a sidebar on the left and the results area in the center. The sidebar contains:</p>
<ul>
    <li><strong>Open Button</strong> - Click to browse for a document</li>
    <li><strong>Review Button</strong> - Starts the analysis (disabled until document loaded)</li>
    <li><strong>Export Button</strong> - Creates deliverables (disabled until review completes)</li>
    <li><strong>Preset Buttons</strong> - Quick configuration options</li>
    <li><strong>Checker Categories</strong> - Expandable sections to enable/disable checks</li>
</ul>

<h2>Step 2: Configure Your Checks</h2>
<p>Choose checks appropriate for your document type:</p>

<h3>For Requirements Documents (PrOP, Specs)</h3>
<ul>
    <li>Requirements language (shall/will/must)</li>
    <li>TBD/TBR detection</li>
    <li>Testability analysis</li>
    <li>Undefined acronyms</li>
    <li>Role extraction</li>
</ul>

<h3>For Work Instructions (PAL)</h3>
<ul>
    <li>Passive voice detection</li>
    <li>Imperative mood</li>
    <li>Step numbering</li>
    <li>Wordy phrases</li>
</ul>

<h2>Step 3: Run the Analysis</h2>
<p>Click <strong>Review</strong> or press <kbd>Ctrl</kbd>+<kbd>R</kbd>. The progress indicator shows current checker name, percentage complete, and estimated time remaining. Click <strong>Cancel</strong> to stop a long-running review.</p>

<h2>Step 4: Interpret the Results</h2>

<h3>The Dashboard</h3>
<ul>
    <li><strong>Quality Score</strong> - Letter grade (A+ through F) based on issues per 1000 words</li>
    <li><strong>Severity Distribution</strong> - Interactive pie chart showing Critical/Major/Minor/Info counts</li>
    <li><strong>Readability</strong> - Three standard metrics indicating text complexity</li>
    <li><strong>Document Health</strong> - Breakdown of severity, readability, structure, and completeness</li>
</ul>

<h3>The Issue List</h3>
<ul>
    <li><strong>Severity</strong> - Color-coded badge (red/orange/yellow/blue)</li>
    <li><strong>Category</strong> - Which checker found this issue</li>
    <li><strong>Message</strong> - Description of the problem</li>
    <li><strong>Flagged Text</strong> - The specific text that triggered the issue</li>
    <li><strong>Suggestion</strong> - Recommended fix when available</li>
</ul>

<h2>Step 5: Triage and Export</h2>
<p>Use <strong>Triage Mode</strong> to systematically review each issue:</p>
<ul>
    <li><kbd>K</kbd> or <kbd>→</kbd> - Keep the issue (include in export)</li>
    <li><kbd>S</kbd> - Suppress (dismiss as false positive)</li>
    <li><kbd>F</kbd> - Fixed (already addressed)</li>
    <li><kbd>Space</kbd> - Skip to next without decision</li>
</ul>

<div class="help-callout help-callout-info">
    <i data-lucide="info"></i>
    <div>
        <strong>Pro Tip: Issue Families</strong>
        <p>When the same word is flagged multiple times, TechWriterReview groups them into a "family." Apply a decision to the entire family at once to save time.</p>
    </div>
</div>
`
};

// Getting Started - Interface Tour
HelpDocs.content['interface-tour'] = {
    title: 'Interface Tour',
    subtitle: 'Understanding the TechWriterReview workspace',
    html: `
<p>The TechWriterReview interface is organized into three main areas for efficient document review workflows.</p>

<h2>① Sidebar (Left)</h2>
<p>The command center for document operations and checker configuration.</p>

<h3>Action Buttons</h3>
<table class="help-table">
    <tr><td><strong>Open</strong></td><td>Load a document for review</td><td><kbd>Ctrl</kbd>+<kbd>O</kbd></td></tr>
    <tr><td><strong>Review</strong></td><td>Run analysis with selected checks</td><td><kbd>Ctrl</kbd>+<kbd>R</kbd></td></tr>
    <tr><td><strong>Export</strong></td><td>Generate deliverables</td><td><kbd>Ctrl</kbd>+<kbd>E</kbd></td></tr>
    <tr><td><strong>Batch Load</strong></td><td>Load multiple documents from a folder</td><td>—</td></tr>
</table>

<h3>Preset Buttons</h3>
<ul>
    <li><strong>All</strong> - Enable every checker</li>
    <li><strong>None</strong> - Disable all (start fresh)</li>
    <li><strong>PrOP</strong> - Procedures & Operating Procedures</li>
    <li><strong>PAL</strong> - Process Asset Library</li>
    <li><strong>FGOST</strong> - Flight/Ground Operations</li>
    <li><strong>SOW</strong> - Statement of Work</li>
</ul>

<h2>② Dashboard (Top Center)</h2>
<p>At-a-glance metrics and interactive visualizations.</p>

<h3>Quality Score</h3>
<p>Letter grade (A+ through F) representing overall document quality.</p>

<h3>Severity Chart</h3>
<p>Interactive pie chart - click any segment to filter the issue list.</p>

<h3>Readability Metrics</h3>
<ul>
    <li><strong>Flesch Reading Ease</strong> - 0-100 scale (higher = easier)</li>
    <li><strong>Flesch-Kincaid Grade</strong> - US school grade level</li>
    <li><strong>Gunning Fog Index</strong> - Years of education needed</li>
</ul>

<h2>③ Results Panel (Center)</h2>
<p>Issue list with filtering, sorting, and selection capabilities.</p>

<h3>Filter Bar</h3>
<ul>
    <li><strong>Severity Filter</strong> - Show only Critical, Major, etc.</li>
    <li><strong>Category Filter</strong> - Show only specific checker results</li>
    <li><strong>Search</strong> - Text search across all fields</li>
</ul>

<h3>Footer Controls</h3>
<ul>
    <li><strong>Scan History</strong> - Previous reviews</li>
    <li><strong>Settings</strong> - Configuration</li>
    <li><strong>Roles Report</strong> - Extracted roles and RACI</li>
    <li><strong>Statement Forge</strong> - Extract actionable statements</li>
    <li><strong>Diagnostics</strong> - Export logs</li>
    <li><strong>Help</strong> - This documentation (<kbd>F1</kbd>)</li>
</ul>
`
};

// Document Review - Loading Documents
HelpDocs.content['loading-docs'] = {
    title: 'Loading Documents',
    subtitle: 'Supported formats and loading methods',
    html: `
<h2>Supported Formats</h2>
<table class="help-table">
    <thead>
        <tr><th>Format</th><th>Extension</th><th>Features</th><th>Best For</th></tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Word Document</strong></td>
            <td><code>.docx</code></td>
            <td>✓ Full analysis, track changes, comments</td>
            <td>Primary use - specifications, requirements</td>
        </tr>
        <tr>
            <td><strong>Legacy Word</strong></td>
            <td><code>.doc</code></td>
            <td>~ Converted to .docx automatically</td>
            <td>Older documents</td>
        </tr>
        <tr>
            <td><strong>PDF</strong></td>
            <td><code>.pdf</code></td>
            <td>✓ Text extraction, ✗ No track changes</td>
            <td>Final/published documents</td>
        </tr>
        <tr>
            <td><strong>Plain Text</strong></td>
            <td><code>.txt</code></td>
            <td>✓ Full text analysis, ✗ No structure</td>
            <td>Code documentation, README files</td>
        </tr>
        <tr>
            <td><strong>Rich Text</strong></td>
            <td><code>.rtf</code></td>
            <td>~ Basic formatting</td>
            <td>Cross-platform documents</td>
        </tr>
    </tbody>
</table>

<h2>Loading Methods</h2>

<h3>Method 1: Drag and Drop</h3>
<p>The fastest method - drag a file from File Explorer and drop it anywhere on the window.</p>

<h3>Method 2: Open Button</h3>
<ol>
    <li>Click <strong>Open</strong> in the sidebar</li>
    <li>Navigate to your document</li>
    <li>Select and click Open</li>
</ol>
<p>Keyboard shortcut: <kbd>Ctrl</kbd>+<kbd>O</kbd></p>

<h3>Method 3: Batch Load</h3>
<ol>
    <li>Click <strong>Batch Load</strong> in the sidebar</li>
    <li>Select a folder containing documents</li>
    <li>TechWriterReview queues all supported files</li>
</ol>

<h2>File Size Limits</h2>
<table class="help-table">
    <tr><td><strong>Maximum Size</strong></td><td>50 MB per document</td></tr>
    <tr><td><strong>Recommended</strong></td><td>Under 10 MB for best performance</td></tr>
    <tr><td><strong>Typical Processing</strong></td><td>1-10 pages: 5-10s | 10-50 pages: 10-30s | 50-200 pages: 30-120s</td></tr>
</table>

<h2>Tips for Best Results</h2>
<ul>
    <li><strong>Use .docx when possible</strong> - Full feature support including track changes</li>
    <li><strong>For PDFs, ensure selectable text</strong> - Scanned image PDFs cannot be analyzed</li>
    <li><strong>Close documents in Word first</strong> - Locked files may not load properly</li>
    <li><strong>Remove password protection</strong> - Encrypted documents must be unlocked first</li>
</ul>

<div class="help-callout help-callout-warning">
    <i data-lucide="alert-triangle"></i>
    <div>
        <strong>PDF Export Note</strong>
        <p>When exporting results for a PDF source, TechWriterReview creates a new Word document. Original PDF formatting is not preserved.</p>
    </div>
</div>
`
};

// Document Review - Review Types
HelpDocs.content['review-types'] = {
    title: 'Review Types & Presets',
    subtitle: 'Configuring checks for your document type',
    html: `
<h2>Document Type Presets</h2>
<p>TechWriterReview includes presets optimized for common government and aerospace documentation types.</p>

<div class="help-preset-grid">
    <div class="help-preset-card">
        <h3><i data-lucide="clipboard-list"></i> PrOP</h3>
        <p><strong>Procedures & Operating Procedures</strong></p>
        <ul>
            <li>Requirements language (shall/will/must)</li>
            <li>TBD/TBR detection</li>
            <li>Testability analysis</li>
            <li>Undefined acronyms</li>
            <li>Role extraction</li>
        </ul>
    </div>

    <div class="help-preset-card">
        <h3><i data-lucide="book-open"></i> PAL</h3>
        <p><strong>Process Asset Library</strong></p>
        <ul>
            <li>Imperative mood detection</li>
            <li>Step numbering validation</li>
            <li>Passive voice (strict mode)</li>
            <li>Wordy phrases</li>
            <li>Sentence complexity</li>
        </ul>
    </div>

    <div class="help-preset-card">
        <h3><i data-lucide="rocket"></i> FGOST</h3>
        <p><strong>Flight/Ground Operations</strong></p>
        <ul>
            <li>All requirements checks</li>
            <li>Hyperlink validation</li>
            <li>Reference integrity</li>
            <li>Figure/table validation</li>
            <li>Cross-reference checks</li>
        </ul>
    </div>

    <div class="help-preset-card">
        <h3><i data-lucide="file-text"></i> SOW</h3>
        <p><strong>Statement of Work</strong></p>
        <ul>
            <li>Requirements language (strict)</li>
            <li>Deliverables extraction</li>
            <li>Role identification</li>
            <li>Escape clause detection</li>
            <li>Atomicity analysis</li>
        </ul>
    </div>
</div>

<h2>Review Depth Options</h2>
<table class="help-table">
    <thead><tr><th>Mode</th><th>Time</th><th>Best For</th><th>Checkers</th></tr></thead>
    <tbody>
        <tr><td><strong>Quick Check</strong></td><td>~30 sec</td><td>Pre-submission</td><td>Critical issues only: TBD, broken links, undefined acronyms</td></tr>
        <tr><td><strong>Standard</strong></td><td>~2 min</td><td>Regular reviews</td><td>Grammar, spelling, requirements language, roles</td></tr>
        <tr><td><strong>Comprehensive</strong></td><td>~5 min</td><td>Final review, audits</td><td>All enabled checks including deep hyperlink validation</td></tr>
    </tbody>
</table>

<h2>Custom Configuration</h2>
<ol>
    <li>Start with a preset closest to your needs</li>
    <li>Expand checker categories in the sidebar</li>
    <li>Enable/disable individual checks using toggles</li>
    <li>Save as custom profile via Settings → Scan Profiles</li>
</ol>

<div class="help-callout help-callout-tip">
    <i data-lucide="lightbulb"></i>
    <div>
        <strong>Tip: Save Your Configuration</strong>
        <p>If you frequently review the same document types, save your checker configuration as a custom profile in Settings → Scan Profiles.</p>
    </div>
</div>
`
};

// Document Review - Understanding Results
HelpDocs.content['understanding-results'] = {
    title: 'Understanding Results',
    subtitle: 'Interpreting the quality score, dashboard, and issue list',
    html: `
<h2>The Quality Score</h2>
<p>TechWriterReview calculates a quality score (0-100) that maps to a letter grade. The score reflects issue density normalized by document length.</p>

<h3>Grade Scale</h3>
<table class="help-table help-grade-table">
    <thead><tr><th>Score</th><th>Grade</th><th>Meaning</th></tr></thead>
    <tbody>
        <tr class="grade-a"><td>97-100</td><td>A+</td><td>Publication ready</td></tr>
        <tr class="grade-a"><td>93-96</td><td>A</td><td>Excellent</td></tr>
        <tr class="grade-a"><td>90-92</td><td>A-</td><td>Very good</td></tr>
        <tr class="grade-b"><td>87-89</td><td>B+</td><td>Good quality</td></tr>
        <tr class="grade-b"><td>83-86</td><td>B</td><td>Above average</td></tr>
        <tr class="grade-b"><td>80-82</td><td>B-</td><td>Acceptable</td></tr>
        <tr class="grade-c"><td>77-79</td><td>C+</td><td>Fair</td></tr>
        <tr class="grade-c"><td>73-76</td><td>C</td><td>Average</td></tr>
        <tr class="grade-c"><td>70-72</td><td>C-</td><td>Below average</td></tr>
        <tr class="grade-d"><td>60-69</td><td>D</td><td>Poor</td></tr>
        <tr class="grade-f"><td>&lt;60</td><td>F</td><td>Major revision needed</td></tr>
    </tbody>
</table>

<h3>Score Calculation</h3>
<p>Starts at 100 with deductions:</p>
<ul>
    <li><strong>Critical:</strong> -5 points each</li>
    <li><strong>Major:</strong> -2 points each</li>
    <li><strong>Minor:</strong> -0.5 points each</li>
    <li><strong>Info:</strong> -0.1 points each</li>
</ul>
<p>Score is normalized per 1000 words for fair comparison.</p>

<h2>Severity Levels</h2>
<table class="help-table">
    <tr><td><span class="severity-badge severity-critical">Critical</span></td><td>Must fix before publication</td><td>TBD/TBR, broken references</td></tr>
    <tr><td><span class="severity-badge severity-major">Major</span></td><td>Should fix - impacts quality</td><td>Undefined acronyms, improper language</td></tr>
    <tr><td><span class="severity-badge severity-minor">Minor</span></td><td>Consider fixing</td><td>Passive voice, wordiness</td></tr>
    <tr><td><span class="severity-badge severity-info">Info</span></td><td>Informational only</td><td>Statistics, suggestions</td></tr>
</table>

<h2>Dashboard Widgets</h2>

<h3>Severity Distribution Chart</h3>
<p>Interactive pie chart showing issue breakdown. Click any segment to filter the issue list.</p>

<h3>Readability Metrics</h3>
<ul>
    <li><strong>Flesch Reading Ease (0-100)</strong> - Higher = easier. Technical docs typically 30-50.</li>
    <li><strong>Flesch-Kincaid Grade Level</strong> - US grade needed. Technical docs typically 12-16.</li>
    <li><strong>Gunning Fog Index</strong> - Years of education needed.</li>
</ul>

<h3>Document Health Breakdown</h3>
<ul>
    <li><strong>Severity</strong> - Weighted impact of issues</li>
    <li><strong>Readability</strong> - Text complexity</li>
    <li><strong>Structure</strong> - Heading hierarchy, references</li>
    <li><strong>Completeness</strong> - Absence of TBD/TBR</li>
</ul>

<h2>The Issue List</h2>
<p>Each row represents a detected problem. Click any row to see full paragraph context and navigation.</p>
`
};

// ========================================================================
// CHECKERS SECTION
// ========================================================================

// Acronym Checker
HelpDocs.content['checker-acronyms'] = {
    title: 'Acronym Checker',
    subtitle: 'Ensuring acronyms are properly defined',
    html: `
<h2>What It Checks</h2>
<ul>
    <li><strong>Undefined acronyms</strong> - Used without ever being defined</li>
    <li><strong>Used before defined</strong> - Definition appears after first use</li>
    <li><strong>Defined but unused</strong> - Definition provided but acronym never used</li>
    <li><strong>Inconsistent formatting</strong> - Mixed case (NASA vs Nasa)</li>
    <li><strong>Repeated definitions</strong> - Same acronym defined multiple times</li>
</ul>

<h2>Why It Matters</h2>
<p>Government and aerospace documentation standards require acronyms be defined on first use. Many contracts and compliance frameworks mandate proper acronym handling.</p>

<h2>Example Findings</h2>
<table class="help-table">
    <thead><tr><th>Issue</th><th>Example</th><th>Fix</th></tr></thead>
    <tbody>
        <tr><td>Undefined</td><td>"The FMEA revealed..."</td><td>Add "(Failure Mode and Effects Analysis)" on first use</td></tr>
        <tr><td>Used before defined</td><td>"See the SRD. The Software Requirements Document (SRD)..."</td><td>Move definition to first occurrence</td></tr>
        <tr><td>Defined but unused</td><td>"Quality Assurance (QA)" appears once</td><td>Remove definition or use the acronym</td></tr>
        <tr><td>Inconsistent</td><td>"NASA" and "Nasa" both appear</td><td>Standardize to "NASA"</td></tr>
    </tbody>
</table>

<h2>Built-in Skip List</h2>
<ul>
    <li><strong>Units:</strong> MHz, GB, KB, MB, TB, ms, Hz</li>
    <li><strong>Standard:</strong> USA, UK, NASA, DoD, FAA, NOAA</li>
    <li><strong>Document patterns:</strong> Q0-XXX-XXXX formats</li>
    <li><strong>Common technical:</strong> API, HTML, XML, PDF, URL, HTTP</li>
</ul>

<h2>Configuration</h2>
<table class="help-table">
    <tr><td><strong>Skip common terms</strong></td><td>ON/OFF</td><td>Include built-in skip list</td></tr>
    <tr><td><strong>Custom skip list</strong></td><td>Text list</td><td>Add your organization's acronyms</td></tr>
    <tr><td><strong>Minimum length</strong></td><td>2-5 chars</td><td>Ignore short abbreviations</td></tr>
    <tr><td><strong>Case sensitivity</strong></td><td>ON/OFF</td><td>Treat "NASA" and "Nasa" as different</td></tr>
</table>
`
};

// Grammar & Spelling
HelpDocs.content['checker-grammar'] = {
    title: 'Grammar & Spelling',
    subtitle: 'Language mechanics and correctness',
    html: `
<h2>What It Checks</h2>

<h3>Grammar Checker</h3>
<ul>
    <li>Subject-verb agreement</li>
    <li>Tense consistency</li>
    <li>Article usage (a/an/the)</li>
    <li>Pronoun agreement</li>
    <li>Comma usage in compound sentences</li>
    <li>Run-on sentences</li>
</ul>

<h3>Spelling Checker</h3>
<ul>
    <li>Misspelled words</li>
    <li>Common typos</li>
    <li>Double words ("the the")</li>
    <li>Technical term validation (optional)</li>
</ul>

<h3>Punctuation Checker</h3>
<ul>
    <li>Missing periods at sentence end</li>
    <li>Improper comma placement</li>
    <li>Quote and bracket matching</li>
    <li>Extra or missing spaces</li>
</ul>

<h2>Integration with Microsoft Word</h2>
<p>When available, TechWriterReview leverages Microsoft Word's spell checker for enhanced accuracy, including access to your custom dictionary and context-aware suggestions.</p>

<h2>Example Findings</h2>
<table class="help-table">
    <thead><tr><th>Type</th><th>Issue</th><th>Suggestion</th></tr></thead>
    <tbody>
        <tr><td>Agreement</td><td>"The team have completed"</td><td>"The team has completed"</td></tr>
        <tr><td>Article</td><td>"a hour"</td><td>"an hour"</td></tr>
        <tr><td>Spelling</td><td>"recieve"</td><td>"receive"</td></tr>
        <tr><td>Double word</td><td>"the the system"</td><td>"the system"</td></tr>
        <tr><td>Punctuation</td><td>"Hello,world"</td><td>"Hello, world"</td></tr>
    </tbody>
</table>

<h2>Configuration</h2>
<table class="help-table">
    <tr><td><strong>Use Word spell checker</strong></td><td>ON/OFF</td><td>Leverage Word's dictionary when available</td></tr>
    <tr><td><strong>Check capitalization</strong></td><td>ON/OFF</td><td>Flag sentence case issues</td></tr>
    <tr><td><strong>Allow contractions</strong></td><td>ON/OFF</td><td>Flag informal don't, won't</td></tr>
    <tr><td><strong>Custom dictionary</strong></td><td>Text list</td><td>Words to ignore</td></tr>
</table>
`
};

// Hyperlink Checker
HelpDocs.content['checker-hyperlinks'] = {
    title: 'Hyperlink Checker',
    subtitle: 'Validating document links',
    html: `
<h2>What It Checks</h2>
<ul>
    <li><strong>Broken links (404)</strong> - URL no longer exists</li>
    <li><strong>Timeout errors</strong> - Server not responding</li>
    <li><strong>Redirects</strong> - URL moved to new location</li>
    <li><strong>HTTP vs HTTPS</strong> - Security protocol issues</li>
    <li><strong>Malformed URLs</strong> - Invalid URL structure</li>
    <li><strong>Internal vs external</strong> - Classification for review</li>
</ul>

<h2>Validation Modes</h2>

<h3>Restricted Mode (Default)</h3>
<p>For air-gapped and secure environments:</p>
<ul>
    <li>Validates URL format only</li>
    <li>Does not make network requests</li>
    <li>Safe for disconnected environments</li>
</ul>

<h3>Connected Mode</h3>
<p>For environments with network access:</p>
<ul>
    <li>Actually fetches each URL</li>
    <li>Reports HTTP status codes</li>
    <li>Detects soft 404s</li>
    <li>Checks SSL certificate validity</li>
    <li>Follows redirect chains</li>
</ul>

<div class="help-callout help-callout-warning">
    <i data-lucide="alert-triangle"></i>
    <div>
        <strong>Network Mode Warning</strong>
        <p>Connected mode makes actual HTTP requests. This may trigger security alerts and takes longer. Use Restricted mode for sensitive documents or air-gapped networks.</p>
    </div>
</div>

<h2>Example Findings</h2>
<table class="help-table">
    <thead><tr><th>Severity</th><th>Issue</th><th>Action</th></tr></thead>
    <tbody>
        <tr><td><span class="severity-badge severity-critical">Critical</span></td><td>404 Not Found</td><td>Update or remove link</td></tr>
        <tr><td><span class="severity-badge severity-major">Major</span></td><td>Connection timeout</td><td>Verify server availability</td></tr>
        <tr><td><span class="severity-badge severity-minor">Minor</span></td><td>Redirected (301/302)</td><td>Update to final URL</td></tr>
        <tr><td><span class="severity-badge severity-info">Info</span></td><td>HTTP (not HTTPS)</td><td>Consider security upgrade</td></tr>
    </tbody>
</table>

<h2>Configuration</h2>
<table class="help-table">
    <tr><td><strong>Validation mode</strong></td><td>Restricted / Connected</td><td>Enable network requests</td></tr>
    <tr><td><strong>Timeout</strong></td><td>5-30 seconds</td><td>Maximum wait per URL</td></tr>
    <tr><td><strong>Skip internal links</strong></td><td>ON/OFF</td><td>Ignore internal references</td></tr>
    <tr><td><strong>Follow redirects</strong></td><td>ON/OFF</td><td>Chase redirect chains</td></tr>
</table>
`
};

// Requirements Language
HelpDocs.content['checker-requirements'] = {
    title: 'Requirements Language',
    subtitle: 'Analyzing requirements statements',
    html: `
<h2>What It Checks</h2>

<h3>Modal Verb Analysis</h3>
<ul>
    <li><strong>Shall</strong> - Mandatory requirement (correct usage)</li>
    <li><strong>Will</strong> - Statement of fact or future action (often misused)</li>
    <li><strong>Should</strong> - Recommendation, not requirement (flag as weak)</li>
    <li><strong>May</strong> - Permission (acceptable for options)</li>
    <li><strong>Must</strong> - Often indicates constraint</li>
</ul>

<h3>Placeholder Detection</h3>
<ul>
    <li><strong>TBD</strong> (To Be Determined) - Missing information</li>
    <li><strong>TBR</strong> (To Be Resolved) - Pending decision</li>
    <li><strong>TBS</strong> (To Be Supplied) - Missing data</li>
    <li><strong>[PLACEHOLDER]</strong> - Generic markers</li>
</ul>

<h3>Testability Analysis</h3>
<ul>
    <li><strong>Vague terms</strong> - "user-friendly", "easy to use", "adequate"</li>
    <li><strong>Missing metrics</strong> - Requirements without measurable criteria</li>
    <li><strong>Subjective language</strong> - "quickly", "efficiently", "properly"</li>
</ul>

<h3>Atomicity</h3>
<ul>
    <li><strong>Compound requirements</strong> - Multiple "shall" statements in one paragraph</li>
    <li><strong>Conjunctions</strong> - "and/or" creating ambiguity</li>
    <li><strong>Multiple conditions</strong> - Complex if-then structures</li>
</ul>

<h2>Example Findings</h2>
<table class="help-table">
    <thead><tr><th>Type</th><th>Issue</th><th>Recommendation</th></tr></thead>
    <tbody>
        <tr><td>Weak language</td><td>"The system should respond within 5 seconds."</td><td>Change "should" to "shall"</td></tr>
        <tr><td>TBD</td><td>"The system shall support TBD users."</td><td>Resolve TBD with specific number</td></tr>
        <tr><td>Vague</td><td>"The interface shall be user-friendly."</td><td>Define measurable usability criteria</td></tr>
        <tr><td>Compound</td><td>"The system shall authenticate users and log all access."</td><td>Split into two requirements</td></tr>
        <tr><td>Escape clause</td><td>"...as required by the project."</td><td>Specify explicit requirements</td></tr>
    </tbody>
</table>

<h2>Configuration</h2>
<table class="help-table">
    <tr><td><strong>Flag "should"</strong></td><td>ON/OFF</td><td>Warn on weak language</td></tr>
    <tr><td><strong>TBD severity</strong></td><td>Critical/Major</td><td>Importance of placeholders</td></tr>
    <tr><td><strong>Check atomicity</strong></td><td>ON/OFF</td><td>Find compound requirements</td></tr>
    <tr><td><strong>Escape clause list</strong></td><td>Text list</td><td>Custom phrases to flag</td></tr>
</table>
`
};

// Writing Quality
HelpDocs.content['checker-writing'] = {
    title: 'Writing Quality',
    subtitle: 'Clarity, conciseness, and style',
    html: `
<h2>What It Checks</h2>

<h3>Passive Voice</h3>
<p>Identifies constructions where the subject receives the action:</p>
<ul>
    <li>"The report was written by the team" → "The team wrote the report"</li>
    <li>"shall be configured" → "shall configure"</li>
</ul>

<h3>Wordy Phrases</h3>
<table class="help-table">
    <tr><td>in order to</td><td>→</td><td>to</td></tr>
    <tr><td>at this point in time</td><td>→</td><td>now</td></tr>
    <tr><td>due to the fact that</td><td>→</td><td>because</td></tr>
    <tr><td>in the event that</td><td>→</td><td>if</td></tr>
    <tr><td>with regard to</td><td>→</td><td>about / regarding</td></tr>
</table>

<h3>Sentence Length</h3>
<ul>
    <li><strong>Warning:</strong> Sentences over 30 words</li>
    <li><strong>Error:</strong> Sentences over 50 words</li>
</ul>

<h3>Nominalization</h3>
<p>Verb-to-noun conversions that weaken prose:</p>
<table class="help-table">
    <tr><td>make a decision</td><td>→</td><td>decide</td></tr>
    <tr><td>perform an analysis</td><td>→</td><td>analyze</td></tr>
    <tr><td>give consideration to</td><td>→</td><td>consider</td></tr>
</table>

<h3>Jargon and Buzzwords</h3>
<p>Flags overused corporate language: "synergy", "leverage", "paradigm shift", "going forward", "best practices"</p>

<h3>Repeated Words</h3>
<ul>
    <li>Adjacent duplicates: "the the system"</li>
    <li>Nearby repetition: Same word 3+ times in a paragraph</li>
</ul>

<h2>Configuration</h2>
<table class="help-table">
    <tr><td><strong>Passive voice severity</strong></td><td>Minor/Major</td><td>How strictly to flag</td></tr>
    <tr><td><strong>Max sentence length</strong></td><td>30-50 words</td><td>Threshold for warning</td></tr>
    <tr><td><strong>Check nominalization</strong></td><td>ON/OFF</td><td>Flag noun forms of verbs</td></tr>
    <tr><td><strong>Jargon list</strong></td><td>Text list</td><td>Custom terms to flag</td></tr>
</table>
`
};

// Document Structure
HelpDocs.content['checker-structure'] = {
    title: 'Document Structure',
    subtitle: 'Headings, references, and organization',
    html: `
<h2>What It Checks</h2>

<h3>Heading Hierarchy</h3>
<ul>
    <li><strong>Skipped levels</strong> - H1 followed by H3 (missing H2)</li>
    <li><strong>Orphan headings</strong> - Heading with no content below</li>
    <li><strong>Inconsistent numbering</strong> - Section numbering gaps</li>
</ul>

<h3>References</h3>
<ul>
    <li><strong>Broken cross-references</strong> - References to non-existent sections</li>
    <li><strong>Circular references</strong> - A references B which references A</li>
    <li><strong>Orphan references</strong> - Defined but never used</li>
</ul>

<h3>Tables and Figures</h3>
<ul>
    <li><strong>Missing captions</strong> - Tables/figures without titles</li>
    <li><strong>Numbering gaps</strong> - Figure 1, Figure 3 (missing 2)</li>
    <li><strong>Unreferenced items</strong> - Tables/figures never cited</li>
</ul>

<h3>Lists</h3>
<ul>
    <li><strong>Inconsistent formatting</strong> - Mixed bullet styles</li>
    <li><strong>Incomplete lists</strong> - Single-item lists</li>
    <li><strong>Parallel structure</strong> - Items that don't match grammatically</li>
</ul>

<h2>Example Findings</h2>
<table class="help-table">
    <thead><tr><th>Type</th><th>Issue</th><th>Recommendation</th></tr></thead>
    <tbody>
        <tr><td>Heading skip</td><td>H1 "Introduction" → H3 "Overview"</td><td>Add H2 or promote H3</td></tr>
        <tr><td>Orphan heading</td><td>"3.2 Testing" with no content</td><td>Add content or remove section</td></tr>
        <tr><td>Missing caption</td><td>Table without title</td><td>Add descriptive caption</td></tr>
        <tr><td>Broken reference</td><td>"See Section 5.3" (doesn't exist)</td><td>Correct reference or add section</td></tr>
    </tbody>
</table>
`
};

// Complete Checker Reference
HelpDocs.content['checker-all'] = {
    title: 'Complete Checker Reference',
    subtitle: 'All 50+ quality checks at a glance',
    html: `
<h2>Writing Quality (7 checks)</h2>
<table class="help-table help-checker-table">
    <thead><tr><th>Checker</th><th>Detects</th><th>Example</th></tr></thead>
    <tbody>
        <tr><td>Passive Voice</td><td>"be" + past participle</td><td>"shall be configured" → "shall configure"</td></tr>
        <tr><td>Weak Language</td><td>should, could, might, may</td><td>"should respond" → "shall respond"</td></tr>
        <tr><td>Wordy Phrases</td><td>Verbose expressions</td><td>"in order to" → "to"</td></tr>
        <tr><td>Nominalization</td><td>Noun forms of verbs</td><td>"make a decision" → "decide"</td></tr>
        <tr><td>Jargon</td><td>Corporate buzzwords</td><td>"synergy", "paradigm shift"</td></tr>
        <tr><td>Long Sentences</td><td>40+ words</td><td>Consider splitting</td></tr>
        <tr><td>Repeated Words</td><td>Duplicate adjacent</td><td>"the the" → "the"</td></tr>
    </tbody>
</table>

<h2>Grammar & Spelling (5 checks)</h2>
<table class="help-table help-checker-table">
    <thead><tr><th>Checker</th><th>Detects</th></tr></thead>
    <tbody>
        <tr><td>Spelling</td><td>Misspelled words (uses Word when available)</td></tr>
        <tr><td>Grammar</td><td>Subject-verb agreement, tense, articles</td></tr>
        <tr><td>Punctuation</td><td>Spacing, commas, quotes</td></tr>
        <tr><td>Capitalization</td><td>Sentence start, proper nouns</td></tr>
        <tr><td>Contractions</td><td>Informal don't, won't, can't</td></tr>
    </tbody>
</table>

<h2>Technical Requirements (6 checks)</h2>
<table class="help-table help-checker-table">
    <thead><tr><th>Checker</th><th>Detects</th><th>Severity</th></tr></thead>
    <tbody>
        <tr><td>Undefined Acronyms</td><td>Acronyms not defined on first use</td><td>Major</td></tr>
        <tr><td>Requirements Language</td><td>Improper shall/will/must usage</td><td>Major</td></tr>
        <tr><td>TBD/TBR</td><td>Unresolved placeholders</td><td>Critical</td></tr>
        <tr><td>Testability</td><td>Unmeasurable terms (user-friendly)</td><td>Major</td></tr>
        <tr><td>Atomicity</td><td>Compound requirements</td><td>Major</td></tr>
        <tr><td>Escape Clauses</td><td>"as required", "if applicable"</td><td>Major</td></tr>
    </tbody>
</table>

<h2>Document Structure (7 checks)</h2>
<table class="help-table help-checker-table">
    <thead><tr><th>Checker</th><th>Detects</th></tr></thead>
    <tbody>
        <tr><td>Structure</td><td>Heading hierarchy skips</td></tr>
        <tr><td>References</td><td>Broken cross-references</td></tr>
        <tr><td>Hyperlinks</td><td>Invalid/broken links</td></tr>
        <tr><td>Tables & Figures</td><td>Missing captions, numbering</td></tr>
        <tr><td>Lists</td><td>Inconsistent formatting</td></tr>
        <tr><td>Orphan Headings</td><td>Headings without content</td></tr>
        <tr><td>Empty Sections</td><td>Sections with no content</td></tr>
    </tbody>
</table>

<h2>Roles & Responsibilities (4 checks)</h2>
<table class="help-table help-checker-table">
    <thead><tr><th>Checker</th><th>Detects</th></tr></thead>
    <tbody>
        <tr><td>Role Extraction</td><td>Named roles and entities</td></tr>
        <tr><td>Responsibility Mapping</td><td>Actions assigned to roles</td></tr>
        <tr><td>RACI Analysis</td><td>Responsible/Accountable/Consulted/Informed</td></tr>
        <tr><td>Ambiguous Assignments</td><td>Unclear role references</td></tr>
    </tbody>
</table>
`
};

console.log('[HelpDocs] Part 2 loaded - Checkers content');

// ========================================================================
// ROLES & RESPONSIBILITIES
// ========================================================================

HelpDocs.content['role-detection'] = {
    title: 'Role Detection',
    subtitle: 'Automatic identification of roles and entities',
    html: `
<h2>How It Works</h2>
<p>The role extractor uses pattern matching and NLP to identify organizational roles, entities, tools, and deliverables.</p>

<h3>What Gets Detected</h3>
<ul>
    <li><strong>Named roles:</strong> "Project Manager", "Quality Engineer"</li>
    <li><strong>Organizations:</strong> "The Contractor", "NASA", "Government"</li>
    <li><strong>Systems:</strong> "SAP", "DOORS", "SharePoint"</li>
    <li><strong>Deliverables:</strong> "Technical Data Package", "Test Report"</li>
</ul>

<h2>Confidence Levels</h2>
<table class="help-table">
    <tr><td><strong>High (80-100%)</strong></td><td>Strong pattern match - auto-accept recommended</td></tr>
    <tr><td><strong>Medium (50-79%)</strong></td><td>Partial match - review recommended</td></tr>
    <tr><td><strong>Low (&lt;50%)</strong></td><td>Weak match - manual verification needed</td></tr>
</table>
`
};

HelpDocs.content['role-adjudication'] = {
    title: 'Adjudication',
    subtitle: 'Confirming and refining detected roles',
    html: `
<h2>Adjudication Actions</h2>
<table class="help-table">
    <tr><td><strong>✓ Confirm</strong></td><td>Valid role - add to dictionary</td><td><kbd>Y</kbd></td></tr>
    <tr><td><strong>✗ Reject</strong></td><td>Not a role - exclude</td><td><kbd>N</kbd></td></tr>
    <tr><td><strong>✎ Edit</strong></td><td>Correct name or type</td><td><kbd>E</kbd></td></tr>
    <tr><td><strong>→ Skip</strong></td><td>Decide later</td><td><kbd>S</kbd></td></tr>
</table>
`
};

HelpDocs.content['role-dictionary'] = {
    title: 'Role Dictionary',
    subtitle: 'Managing your organization\'s role library',
    html: `
<h2>Building Your Dictionary</h2>
<ul>
    <li><strong>From Adjudication:</strong> Confirmed roles auto-add to dictionary</li>
    <li><strong>Manual Entry:</strong> Add via Dictionary tab in Roles Report</li>
    <li><strong>Import:</strong> Load from Excel or CSV file</li>
</ul>
`
};

HelpDocs.content['role-graph'] = {
    title: 'Relationship Graph',
    subtitle: 'Visualizing role relationships',
    html: `
<h2>Node Colors</h2>
<table class="help-table">
    <tr><td style="color:#3b82f6">●</td><td>Blue - Person Role</td></tr>
    <tr><td style="color:#22c55e">●</td><td>Green - Organization</td></tr>
    <tr><td style="color:#a855f7">●</td><td>Purple - System/Tool</td></tr>
    <tr><td style="color:#f59e0b">●</td><td>Orange - Deliverable</td></tr>
    <tr><td style="color:#6b7280">●</td><td>Gray - Document</td></tr>
</table>
<p>Larger nodes = more mentions. Lines show shared responsibilities.</p>
`
};

HelpDocs.content['role-matrix'] = {
    title: 'RACI Matrix',
    subtitle: 'Responsibility assignment matrix',
    html: `
<h2>Understanding RACI</h2>
<table class="help-table">
    <tr><td><strong>R</strong></td><td>Responsible - Does the work</td></tr>
    <tr><td><strong>A</strong></td><td>Accountable - Approves/authorizes</td></tr>
    <tr><td><strong>C</strong></td><td>Consulted - Provides input</td></tr>
    <tr><td><strong>I</strong></td><td>Informed - Kept updated</td></tr>
</table>
`
};

// ========================================================================
// STATEMENT FORGE
// ========================================================================

HelpDocs.content['forge-overview'] = {
    title: 'Statement Forge Overview',
    subtitle: 'Extract actionable statements from documents',
    html: `
<h2>What It Extracts</h2>
<table class="help-table">
    <tr><td><strong>Shall</strong></td><td>Mandatory requirements</td></tr>
    <tr><td><strong>Must</strong></td><td>Obligations</td></tr>
    <tr><td><strong>Will</strong></td><td>Future commitments</td></tr>
    <tr><td><strong>Should</strong></td><td>Recommendations</td></tr>
    <tr><td><strong>May</strong></td><td>Permissions</td></tr>
</table>
<h2>Use Cases</h2>
<ul>
    <li>TIBCO Nimbus process mapping</li>
    <li>Requirements traceability matrices</li>
    <li>Compliance verification</li>
</ul>
`
};

HelpDocs.content['forge-extraction'] = {
    title: 'Statement Extraction',
    subtitle: 'How statements are identified',
    html: `
<h2>Statement Components</h2>
<table class="help-table">
    <tr><td><strong>Actor</strong></td><td>Who performs the action</td></tr>
    <tr><td><strong>Modal</strong></td><td>Obligation type (shall/will/must)</td></tr>
    <tr><td><strong>Action</strong></td><td>The verb describing activity</td></tr>
    <tr><td><strong>Object</strong></td><td>What receives the action</td></tr>
</table>
`
};

HelpDocs.content['forge-editing'] = {
    title: 'Editing Statements',
    subtitle: 'Refining extracted statements',
    html: `
<h2>Keyboard Shortcuts</h2>
<table class="help-table">
    <tr><td><kbd>F2</kbd></td><td>Edit selected statement</td></tr>
    <tr><td><kbd>Ctrl</kbd>+<kbd>M</kbd></td><td>Merge selected</td></tr>
    <tr><td><kbd>Ctrl</kbd>+<kbd>Z</kbd></td><td>Undo</td></tr>
    <tr><td><kbd>Delete</kbd></td><td>Remove selected</td></tr>
</table>
`
};

HelpDocs.content['forge-export'] = {
    title: 'Export Formats',
    subtitle: 'Statement export options',
    html: `
<h2>Available Formats</h2>
<ul>
    <li><strong>TIBCO Nimbus CSV</strong> - Direct import for process mapping</li>
    <li><strong>Excel</strong> - Professional formatted report</li>
    <li><strong>Word</strong> - Document format for reports</li>
    <li><strong>JSON</strong> - Structured data</li>
</ul>
`
};

// ========================================================================
// EXPORTING
// ========================================================================

HelpDocs.content['export-word'] = {
    title: 'Word Document Export',
    subtitle: 'Creating marked-up documents with tracked changes',
    html: `
<h2>What Gets Exported</h2>
<ul>
    <li><strong>Comments</strong> - Each issue at exact location</li>
    <li><strong>Track Changes</strong> - Suggested fixes as tracked edits</li>
    <li><strong>Severity indicators</strong> - [Critical], [Major], etc.</li>
</ul>
<h2>Output</h2>
<p>Filename: <code>original_REVIEWED_date.docx</code></p>
<p>Original file unchanged - new file created.</p>
`
};

HelpDocs.content['export-reports'] = {
    title: 'PDF Reports',
    subtitle: 'Professional formatted reports',
    html: `
<h2>Report Types</h2>
<ul>
    <li><strong>Summary</strong> - Executive overview with charts</li>
    <li><strong>Detailed</strong> - All issues with context</li>
    <li><strong>Audit</strong> - Triage log for compliance</li>
</ul>
`
};

HelpDocs.content['export-data'] = {
    title: 'CSV & Excel Export',
    subtitle: 'Tabular formats for tracking',
    html: `
<h2>CSV Columns</h2>
<p>ID, Category, Severity, Message, Flagged Text, Suggestion, Location, Status</p>
<h2>Excel Features</h2>
<ul>
    <li>Summary sheet with charts</li>
    <li>Issues sheet with filtering</li>
    <li>Category breakdown sheets</li>
</ul>
`
};

// ========================================================================
// SETTINGS
// ========================================================================

HelpDocs.content['settings-general'] = {
    title: 'General Settings',
    subtitle: 'Core application configuration',
    html: `
<h2>Key Settings</h2>
<table class="help-table">
    <tr><td><strong>Auto-save history</strong></td><td>Save each review automatically</td></tr>
    <tr><td><strong>Remember preset</strong></td><td>Restore configuration on restart</td></tr>
    <tr><td><strong>Reviewer name</strong></td><td>Name used in export comments</td></tr>
    <tr><td><strong>Default export</strong></td><td>Word/Excel/CSV/JSON</td></tr>
</table>
`
};

HelpDocs.content['settings-appearance'] = {
    title: 'Appearance & Themes',
    subtitle: 'Visual customization',
    html: `
<h2>Themes</h2>
<table class="help-table">
    <tr><td><strong>Light</strong></td><td>Default light theme</td></tr>
    <tr><td><strong>Dark</strong></td><td>Low-light environments</td></tr>
    <tr><td><strong>System</strong></td><td>Follow OS preference</td></tr>
</table>
<p>Quick toggle: Press <kbd>D</kbd></p>
`
};

HelpDocs.content['settings-updates'] = {
    title: 'Updates',
    subtitle: 'Version management',
    html: `
<h2>Air-Gapped Environments</h2>
<ol>
    <li>Download update package from authorized source</li>
    <li>Copy to air-gapped machine</li>
    <li>Settings → Updates → Install from File</li>
</ol>
`
};

HelpDocs.content['settings-diagnostics'] = {
    title: 'Diagnostics',
    subtitle: 'Troubleshooting and logging',
    html: `
<h2>Export Diagnostics</h2>
<p>Creates sanitized package with logs, config, and system info for troubleshooting.</p>
<h2>AI Troubleshooting</h2>
<p>Generate diagnostic package optimized for AI analysis.</p>
`
};

// ========================================================================
// KEYBOARD SHORTCUTS
// ========================================================================

HelpDocs.content['shortcuts'] = {
    title: 'Keyboard Shortcuts',
    subtitle: 'Navigate efficiently',
    html: `
<h2>Global</h2>
<table class="help-table">
    <tr><td><kbd>Ctrl</kbd>+<kbd>O</kbd></td><td>Open document</td></tr>
    <tr><td><kbd>Ctrl</kbd>+<kbd>R</kbd></td><td>Run review</td></tr>
    <tr><td><kbd>Ctrl</kbd>+<kbd>E</kbd></td><td>Export</td></tr>
    <tr><td><kbd>F1</kbd></td><td>Help</td></tr>
    <tr><td><kbd>D</kbd></td><td>Toggle dark mode</td></tr>
    <tr><td><kbd>Escape</kbd></td><td>Close modal</td></tr>
</table>

<h2>Issue Navigation</h2>
<table class="help-table">
    <tr><td><kbd>↑</kbd>/<kbd>↓</kbd></td><td>Navigate issues</td></tr>
    <tr><td><kbd>Enter</kbd></td><td>View details</td></tr>
    <tr><td><kbd>Space</kbd></td><td>Toggle selection</td></tr>
</table>

<h2>Triage Mode</h2>
<table class="help-table">
    <tr><td><kbd>K</kbd> or <kbd>→</kbd></td><td>Keep</td></tr>
    <tr><td><kbd>S</kbd></td><td>Suppress</td></tr>
    <tr><td><kbd>F</kbd></td><td>Fixed</td></tr>
    <tr><td><kbd>←</kbd></td><td>Previous</td></tr>
</table>
`
};

// ========================================================================
// TROUBLESHOOTING
// ========================================================================

HelpDocs.content['trouble-common'] = {
    title: 'Common Issues',
    subtitle: 'Solutions to frequent problems',
    html: `
<h2>App Won't Start</h2>
<ul>
    <li>Check Python version (3.8+ required)</li>
    <li>Check port 5050 not in use</li>
    <li>Run installer again</li>
</ul>

<h2>Document Won't Load</h2>
<ul>
    <li>Must be .docx or .pdf</li>
    <li>Not password protected</li>
    <li>Close in other applications first</li>
    <li>Under 50MB file size</li>
</ul>

<h2>Review Hangs</h2>
<ul>
    <li>Wait up to 5 minutes for large documents</li>
    <li>Disable hyperlink checking</li>
    <li>Try fewer checkers</li>
</ul>
`
};

HelpDocs.content['trouble-errors'] = {
    title: 'Error Messages',
    subtitle: 'Understanding and resolving errors',
    html: `
<table class="help-table">
    <tr><td><strong>UPLOAD_FAILED</strong></td><td>Check file format and permissions</td></tr>
    <tr><td><strong>PARSE_ERROR</strong></td><td>Re-save document in Word</td></tr>
    <tr><td><strong>TIMEOUT</strong></td><td>Try smaller document or fewer checks</td></tr>
    <tr><td><strong>NETWORK_ERROR</strong></td><td>Use restricted mode for hyperlinks</td></tr>
    <tr><td><strong>EXPORT_FAILED</strong></td><td>Check permissions and disk space</td></tr>
</table>
`
};

HelpDocs.content['trouble-help'] = {
    title: 'Getting Help',
    subtitle: 'Support resources',
    html: `
<h2>Self-Service</h2>
<ul>
    <li>Press <kbd>F1</kbd> for help</li>
    <li>Export diagnostics for analysis</li>
    <li>Use AI Troubleshoot feature</li>
</ul>
<p>Diagnostic exports are sanitized - no document content included.</p>
`
};

// ========================================================================
// VERSION HISTORY
// ========================================================================

HelpDocs.content['version-history'] = {
    title: 'Version History',
    subtitle: 'Changelog and release notes',
    html: `
<div class="changelog">
    <div class="changelog-version">
        <h3>v3.0.49 <span class="changelog-date">January 21, 2026</span></h3>
        <p><strong>Dead CSS Removal</strong></p>
        <ul>
            <li>Removed 267 unused CSS class definitions</li>
            <li>Eliminated 1,603 lines of dead CSS code</li>
            <li>Reduced stylesheet size by ~36KB (14.4%)</li>
            <li>Cleaned up deprecated help, role, scan, and feature styles</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.48 <span class="changelog-date">January 21, 2026</span></h3>
        <p><strong>CSS Consolidation</strong></p>
        <ul>
            <li>Consolidated 14 scattered media queries into organized section</li>
            <li>All responsive breakpoints now at end of stylesheet</li>
            <li>Improved CSS maintainability and organization</li>
            <li>Breakpoints: 1200px, 992px, 900px, 768px, 700px, 500px</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.47 <span class="changelog-date">January 21, 2026</span></h3>
        <p><strong>Console Cleanup & Polish</strong></p>
        <ul>
            <li>TWR.Logger module for centralized console logging</li>
            <li>Consistent [TWR] prefix on all console output</li>
            <li>Debug mode flag for verbose logging control</li>
            <li>Added tooltips to navigation and action buttons</li>
            <li>Updated changelog with v3.0.43-46 history</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.46 <span class="changelog-date">January 21, 2026</span></h3>
        <p><strong>localStorage Consolidation</strong></p>
        <ul>
            <li>New TWR.Storage module for unified state management</li>
            <li>Consolidated scattered localStorage keys into single twr_state object</li>
            <li>Automatic migration from legacy keys (twr-theme, twr_settings, etc.)</li>
            <li>TWR.Logger module for centralized console logging with debug mode</li>
            <li>Console cleanup with consistent [TWR] prefixes</li>
            <li>Added tooltips to navigation and action buttons</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.44-45 <span class="changelog-date">January 2026</span></h3>
        <p><strong>UI Enhancements</strong></p>
        <ul>
            <li>Collapsible sidebar toggle with Ctrl+B keyboard shortcut</li>
            <li>Migrated last inline onclick handlers to event delegation</li>
            <li>Dynamic version labels throughout the application</li>
            <li>Keyboard shortcuts quick reference modal (press ? key)</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.43 <span class="changelog-date">January 2026</span></h3>
        <p><strong>Help System Enhancements</strong></p>
        <ul>
            <li>Enhanced help modal with keyboard navigation</li>
            <li>Search improvements for help content</li>
            <li>Documentation updates across all modules</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v3.0.x <span class="changelog-date">January 2026</span></h3>
        <p><strong>Enterprise Architecture</strong></p>
        <ul>
            <li>Complete modular JS architecture (TWR namespace)</li>
            <li>Event delegation for all user interactions</li>
            <li>State management refactoring</li>
            <li>API client abstraction layer</li>
            <li>Air-gapped deployment support</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.9.6 <span class="changelog-date">January 19, 2026</span></h3>
        <p><strong>Help & Documentation Overhaul</strong></p>
        <ul>
            <li>Complete help content rewrite (~11,600 words)</li>
            <li>Full-screen help modal (96vw × 94vh)</li>
            <li>Full-text search across all help content</li>
            <li>Integrated version history</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.9.5 <span class="changelog-date">January 19, 2026</span></h3>
        <p><strong>Stability & Timeout Protection</strong></p>
        <ul>
            <li>Enhanced error handling with timeout support</li>
            <li>30-second timeout on diagnostic exports</li>
            <li>Fixed dashboard flex-direction CSS</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.9.4.x <span class="changelog-date">January 2026</span></h3>
        <p><strong>Bug Fixes & Stability</strong></p>
        <ul>
            <li>AI Troubleshooting diagnostic export</li>
            <li>Log rotation (5MB max, 5 backups)</li>
            <li>Correlation ID tracking</li>
            <li>Document type presets (PrOP, PAL, FGOST, SOW)</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.9.3 <span class="changelog-date">January 2026</span></h3>
        <p><strong>Statement Forge</strong></p>
        <ul>
            <li>Statement extraction with 1000+ action verbs</li>
            <li>TIBCO Nimbus export</li>
            <li>Fixed diagnostics and email</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.9.0-2.9.2 <span class="changelog-date">January 2026</span></h3>
        <p><strong>Major Features</strong></p>
        <ul>
            <li>D3.js Roles Graph visualization</li>
            <li>RACI matrix export</li>
            <li>Issue families</li>
            <li>Scan history</li>
        </ul>
    </div>

    <div class="changelog-version">
        <h3>v2.8.x <span class="changelog-date">December 2025</span></h3>
        <p><strong>Foundation</strong></p>
        <ul>
            <li>Core 50+ quality checkers</li>
            <li>Track changes export</li>
            <li>Dark mode</li>
        </ul>
    </div>
</div>
`
};

// ========================================================================
// ABOUT
// ========================================================================

HelpDocs.content['about'] = {
    title: 'About TechWriterReview',
    subtitle: 'Enterprise technical document analysis tool',
    html: `
<div class="help-about">
    <h2>TechWriterReview</h2>
    <p class="help-version-display"><strong>Version 3.0.48</strong></p>
    <p>Build Date: January 21, 2026</p>

    <h2>Purpose</h2>
    <p>Enterprise-grade technical writing review tool designed for government and aerospace documentation.</p>

    <h2>Created By</h2>
    <p><strong>Nicholas Georgeson</strong><br>
    Systems Engineer, SAIC</p>

    <h2>Technology</h2>
    <ul>
        <li>Python 3.8+ / Flask</li>
        <li>Vanilla JavaScript</li>
        <li>Chart.js / D3.js</li>
        <li>SQLite / Waitress</li>
    </ul>

    <h2>Acknowledgments</h2>
    <p>Lucide Icons, Chart.js, D3.js, pdfplumber, python-docx</p>
</div>
`
};

// ========================================================================
// SEARCH
// ========================================================================

HelpDocs.searchIndex = null;

HelpDocs.buildSearchIndex = function() {
    this.searchIndex = [];
    for (const [id, section] of Object.entries(this.content)) {
        const text = section.html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').toLowerCase();
        this.searchIndex.push({
            id: id,
            title: section.title,
            subtitle: section.subtitle || '',
            text: text
        });
    }
};

HelpDocs.search = function(query) {
    if (!this.searchIndex) this.buildSearchIndex();
    const q = query.toLowerCase().trim();
    if (!q) return [];
    
    const results = [];
    for (const item of this.searchIndex) {
        let score = 0;
        if (item.title.toLowerCase().includes(q)) score += 10;
        if (item.subtitle.toLowerCase().includes(q)) score += 5;
        if (item.text.includes(q)) score += 1 + (item.text.split(q).length - 1) * 0.1;
        if (score > 0) results.push({ ...item, score });
    }
    return results.sort((a, b) => b.score - a.score).slice(0, 10);
};

// ========================================================================
// INITIALIZATION
// ========================================================================

HelpDocs.init = function() {
    console.log('[HelpDocs] Initializing v' + this.version);
    this.buildSearchIndex();
    console.log('[HelpDocs] Search index built: ' + this.searchIndex.length + ' entries');
};

if (typeof window !== 'undefined') {
    window.HelpDocs = HelpDocs;
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => HelpDocs.init());
    } else {
        HelpDocs.init();
    }
}

console.log('[HelpDocs] Module loaded v2.9.6');
