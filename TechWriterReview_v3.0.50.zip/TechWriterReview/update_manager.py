"""
TechWriterReview Update Manager v1.0
====================================
Backend module for managing application updates from the UI.

Features:
- Monitors "updates" folder for new files
- Creates backups before applying updates
- Applies updates with verification
- Supports rollback to previous versions
- Provides API endpoints for UI integration
"""

import os
import sys
import json
import shutil
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from enum import Enum

# Setup logging
logger = logging.getLogger('update_manager')

# ============================================================
# CONFIGURATION
# ============================================================

class UpdateConfig:
    """Update system configuration."""
    
    def __init__(self, base_dir: Optional[Path] = None):
        # Determine base directory (install root, parent of app folder)
        if base_dir:
            self.base_dir = Path(base_dir)
        else:
            # Assume we're in the app folder, go up one level
            self.base_dir = Path(__file__).parent.parent
        
        self.app_dir = self.base_dir / "app"
        self.updates_dir = self.base_dir / "updates"
        self.backups_dir = self.base_dir / "backups"
        self.logs_dir = self.base_dir / "logs"
        self.manifest_file = self.updates_dir / "manifest.json"
        
        # Ensure directories exist
        for directory in [self.updates_dir, self.backups_dir, self.logs_dir]:
            directory.mkdir(parents=True, exist_ok=True)
    
    def to_dict(self) -> Dict:
        return {
            'base_dir': str(self.base_dir),
            'app_dir': str(self.app_dir),
            'updates_dir': str(self.updates_dir),
            'backups_dir': str(self.backups_dir),
            'logs_dir': str(self.logs_dir)
        }


# ============================================================
# DATA CLASSES
# ============================================================

class UpdateStatus(Enum):
    PENDING = "pending"
    APPLIED = "applied"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class UpdateFile:
    """Represents a single update file."""
    source_name: str
    source_path: str
    dest_path: str
    dest_name: str
    category: str
    is_new: bool
    size: int
    old_size: int = 0
    hash: str = ""
    status: str = "pending"
    error: str = ""
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class BackupInfo:
    """Information about a backup."""
    name: str
    path: str
    created_at: str
    file_count: int
    size_bytes: int
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class UpdateResult:
    """Result of an update operation."""
    success: bool
    applied: int = 0
    failed: int = 0
    skipped: int = 0
    backup_path: str = ""
    errors: List[str] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
    
    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================
# FILE ROUTING
# ============================================================

class FileRouter:
    """Determines destination paths for update files."""
    
    def __init__(self, app_dir: Path):
        self.app_dir = app_dir
    
    def get_destination(self, filename: str, relative_path: str = None) -> Optional[Dict]:
        """
        Determine destination path for an update file.
        
        Supports two modes:
        1. Flat files with prefix naming (e.g., "static_js_help-docs.js.txt")
        2. Directory-structured paths (e.g., "static/js/ui/renderers.js.txt")
        
        Args:
            filename: Name of the update file (e.g., "app.py.txt")
            relative_path: Optional relative path from zip (e.g., "static/js/ui/renderers.js.txt")
            
        Returns:
            Dict with path, category, and original name, or None if invalid
        """
        # Must end with .txt
        if not filename.endswith('.txt'):
            return None
        
        # Remove .txt extension
        base_name = filename[:-4]
        
        # Skip installer/utility files
        skip_patterns = ['.ps1', '.bat', 'INSTALL.py', 'README']
        if any(pattern in base_name for pattern in skip_patterns):
            return None
        
        # Check if this is a directory-structured path (has path separators)
        # Use relative_path if provided, otherwise check filename for embedded paths
        path_to_check = relative_path if relative_path else filename
        
        if '/' in path_to_check or '\\' in path_to_check:
            # Directory-structured mode: path preserves directory structure
            return self._route_directory_path(path_to_check)
        
        # Flat file mode: use prefix-based routing
        return self._route_flat_file(base_name)
    
    def _route_directory_path(self, path: str) -> Optional[Dict]:
        """Route a file that has directory structure in its path."""
        # Remove .txt extension if present
        if path.endswith('.txt'):
            path = path[:-4]
        
        # Normalize path separators
        path = path.replace('\\', '/')
        
        # Determine category from path
        parts = path.split('/')
        
        if path.startswith('static/js/'):
            # Modular JS: static/js/ui/renderers.js -> app/static/js/ui/renderers.js
            category = '/'.join(parts[:-1])  # e.g., "static/js/ui"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('static/css/'):
            category = "static/css"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('static/vendor/'):
            category = "static/vendor"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('vendor/'):
            category = "vendor"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('statement_forge/'):
            category = "statement_forge"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('templates/'):
            category = "templates"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        elif path.startswith('images/'):
            category = "images"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        else:
            # Unknown directory structure - keep as-is
            category = parts[0] if len(parts) > 1 else "app"
            original_name = parts[-1]
            dest_path = self.app_dir / path
        
        return {
            'path': str(dest_path),
            'category': category,
            'original_name': original_name
        }
    
    def _route_flat_file(self, base_name: str) -> Optional[Dict]:
        """Route a flat file using prefix-based naming conventions."""
        dest_path = None
        category = "app"
        original_name = base_name
        
        if base_name.startswith('vendor_'):
            # vendor_chart.min.js -> vendor/chart.min.js
            real_name = base_name[7:]  # Remove 'vendor_'
            dest_path = self.app_dir / "vendor" / real_name
            category = "vendor"
            original_name = real_name
        
        # v3.0.30: static_js_vendor routing for offline-first vendor JS
        elif base_name.startswith('static_js_vendor_'):
            # static_js_vendor_lucide.min.js -> static/js/vendor/lucide.min.js
            real_name = base_name[17:]  # Remove 'static_js_vendor_'
            dest_path = self.app_dir / "static" / "js" / "vendor" / real_name
            category = "static/js/vendor"
            original_name = real_name
            
        elif base_name.startswith('static_js_'):
            # static_js_help-docs.js -> static/js/help-docs.js
            real_name = base_name[10:]  # Remove 'static_js_'
            dest_path = self.app_dir / "static" / "js" / real_name
            category = "static/js"
            original_name = real_name
            
        elif base_name.startswith('static_css_'):
            # static_css_style.css -> static/css/style.css
            real_name = base_name[11:]  # Remove 'static_css_'
            dest_path = self.app_dir / "static" / "css" / real_name
            category = "static/css"
            original_name = real_name
            
        elif base_name.startswith('static_vendor_'):
            # static_vendor_chart.min.js -> static/vendor/chart.min.js
            real_name = base_name[14:]  # Remove 'static_vendor_'
            dest_path = self.app_dir / "static" / "vendor" / real_name
            category = "static/vendor"
            original_name = real_name
            
        elif base_name.startswith('static_images_'):
            # static_images_logo.png -> images/logo.png
            real_name = base_name[14:]  # Remove 'static_images_'
            dest_path = self.app_dir / "images" / real_name
            category = "images"
            original_name = real_name
        
        elif base_name.startswith('statement_forge__'):
            # v3.0.30: Flat mode - keep as flat file in app root
            # statement_forge__export.py -> app/statement_forge__export.py
            dest_path = self.app_dir / base_name
            category = "statement_forge"
            original_name = base_name
        
        elif base_name == 'style.css':
            # style.css -> app root (installer puts it there, Flask serves from root)
            dest_path = self.app_dir / "style.css"
            category = "app"
            original_name = "style.css"
        
        elif base_name == 'index.html':
            # index.html -> app root (installer puts it there, Flask serves from root)
            dest_path = self.app_dir / "index.html"
            category = "app"
            original_name = "index.html"
            
        else:
            # Regular file - goes to app root
            dest_path = self.app_dir / base_name
            category = "app"
            original_name = base_name
        
        return {
            'path': str(dest_path),
            'category': category,
            'original_name': original_name
        }


# ============================================================
# UPDATE MANAGER
# ============================================================

class UpdateManager:
    """
    Manages application updates from the UI.
    
    Usage:
        manager = UpdateManager()
        
        # Check for updates
        updates = manager.check_for_updates()
        
        # Apply updates
        result = manager.apply_updates()
        
        # Rollback if needed
        manager.rollback()
    """
    
    def __init__(self, base_dir: Optional[Path] = None):
        self.config = UpdateConfig(base_dir)
        self.router = FileRouter(self.config.app_dir)
        self._pending_updates: List[UpdateFile] = []
        
        logger.info(f"UpdateManager initialized: {self.config.to_dict()}")
    
    # --------------------------------------------------------
    # CHECK FOR UPDATES
    # --------------------------------------------------------
    
    def check_for_updates(self) -> Dict[str, Any]:
        """
        Check the updates folder for pending updates.
        
        Supports both:
        - Flat .txt files in updates folder root
        - Directory-structured files (e.g., static/js/ui/renderers.js.txt)
        
        Returns:
            Dict with update information:
            {
                'has_updates': bool,
                'count': int,
                'updates': List[UpdateFile],
                'by_category': Dict[str, int],
                'total_size': int
            }
        """
        self._pending_updates = []
        
        if not self.config.updates_dir.exists():
            return {
                'has_updates': False,
                'count': 0,
                'updates': [],
                'by_category': {},
                'total_size': 0
            }
        
        # Scan for .txt files recursively (supports directory structure)
        update_files = list(self.config.updates_dir.rglob('*.txt'))
        
        # Filter out README and other non-update files
        skip_names = ['README.txt', 'manifest.json']
        update_files = [f for f in update_files if f.name not in skip_names]
        
        by_category = {}
        total_size = 0
        
        for file_path in update_files:
            # Get relative path from updates dir for directory-structured routing
            try:
                relative_path = str(file_path.relative_to(self.config.updates_dir))
            except ValueError:
                relative_path = file_path.name
            
            # Pass relative path for proper routing of directory-structured files
            routing = self.router.get_destination(file_path.name, relative_path)
            
            if not routing:
                continue
            
            dest_path = Path(routing['path'])
            is_new = not dest_path.exists()
            old_size = dest_path.stat().st_size if dest_path.exists() else 0
            new_size = file_path.stat().st_size
            
            # Calculate hash
            file_hash = self._calculate_hash(file_path)
            
            update = UpdateFile(
                source_name=file_path.name,
                source_path=str(file_path),
                dest_path=routing['path'],
                dest_name=routing['original_name'],
                category=routing['category'],
                is_new=is_new,
                size=new_size,
                old_size=old_size,
                hash=file_hash
            )
            
            self._pending_updates.append(update)
            
            # Track by category
            cat = routing['category']
            by_category[cat] = by_category.get(cat, 0) + 1
            total_size += new_size
        
        return {
            'has_updates': len(self._pending_updates) > 0,
            'count': len(self._pending_updates),
            'updates': [u.to_dict() for u in self._pending_updates],
            'by_category': by_category,
            'total_size': total_size
        }
    
    def _calculate_hash(self, file_path: Path) -> str:
        """Calculate MD5 hash of a file."""
        hash_md5 = hashlib.md5()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    # --------------------------------------------------------
    # CREATE BACKUP
    # --------------------------------------------------------
    
    def create_backup(self, files_to_backup: List[str] = None) -> Optional[str]:
        """
        Create a backup of files that will be updated.
        
        Args:
            files_to_backup: Optional list of specific files to backup.
                           If None, backs up all files that will be updated.
        
        Returns:
            Path to backup folder, or None if backup failed
        """
        if files_to_backup is None:
            # Backup files that exist and will be updated
            files_to_backup = [
                u.dest_path for u in self._pending_updates 
                if not u.is_new and Path(u.dest_path).exists()
            ]
        
        if not files_to_backup:
            logger.info("No files to backup (all updates are new files)")
            return None
        
        # Create backup folder
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        backup_name = f"backup_{timestamp}"
        backup_path = self.config.backups_dir / backup_name
        backup_path.mkdir(parents=True, exist_ok=True)
        
        manifest = []
        
        for file_path in files_to_backup:
            src = Path(file_path)
            if not src.exists():
                continue
            
            # Preserve relative path structure
            try:
                rel_path = src.relative_to(self.config.app_dir)
            except ValueError:
                rel_path = src.name
            
            dest = backup_path / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            
            shutil.copy2(src, dest)
            
            manifest.append({
                'relative_path': str(rel_path),
                'original_path': str(src),
                'hash': self._calculate_hash(src),
                'size': src.stat().st_size,
                'backed_up_at': datetime.now().isoformat()
            })
        
        # Save manifest
        manifest_path = backup_path / 'manifest.json'
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        logger.info(f"Created backup: {backup_name} ({len(manifest)} files)")
        
        return str(backup_path)
    
    # --------------------------------------------------------
    # APPLY UPDATES
    # --------------------------------------------------------
    
    def apply_updates(self, create_backup: bool = True) -> UpdateResult:
        """
        Apply all pending updates.
        
        Args:
            create_backup: Whether to create a backup first (default: True)
        
        Returns:
            UpdateResult with success status and details
        """
        if not self._pending_updates:
            # Re-check for updates
            self.check_for_updates()
        
        if not self._pending_updates:
            return UpdateResult(success=True, applied=0)
        
        result = UpdateResult(success=True)
        
        # Create backup first
        if create_backup:
            try:
                backup_path = self.create_backup()
                result.backup_path = backup_path or ""
            except Exception as e:
                logger.error(f"Backup failed: {e}")
                result.errors.append(f"Backup failed: {e}")
                # Continue anyway - user can choose to abort
        
        # Apply each update
        for update in self._pending_updates:
            try:
                success = self._apply_single_update(update)
                if success:
                    update.status = UpdateStatus.APPLIED.value
                    result.applied += 1
                else:
                    update.status = UpdateStatus.FAILED.value
                    result.failed += 1
            except Exception as e:
                update.status = UpdateStatus.FAILED.value
                update.error = str(e)
                result.failed += 1
                result.errors.append(f"{update.dest_name}: {e}")
                logger.error(f"Failed to apply {update.source_name}: {e}")
        
        # Clear updates folder on success
        if result.failed == 0:
            self._clear_updates_folder()
        
        result.success = result.failed == 0
        
        logger.info(f"Update complete: {result.applied} applied, {result.failed} failed")
        
        return result
    
    def _apply_single_update(self, update: UpdateFile) -> bool:
        """Apply a single update file."""
        src = Path(update.source_path)
        dest = Path(update.dest_path)
        
        if not src.exists():
            raise FileNotFoundError(f"Source file not found: {src}")
        
        # Create destination directory if needed
        dest.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy file
        shutil.copy2(src, dest)
        
        # Verify copy
        if not dest.exists():
            raise IOError(f"Failed to copy file to {dest}")
        
        # Verify hash
        new_hash = self._calculate_hash(dest)
        if new_hash != update.hash:
            raise IOError("Hash mismatch after copy")
        
        logger.info(f"Applied: {update.dest_name}")
        return True
    
    def _clear_updates_folder(self):
        """Remove applied update files from the updates folder."""
        for update in self._pending_updates:
            if update.status == UpdateStatus.APPLIED.value:
                try:
                    Path(update.source_path).unlink()
                except Exception as e:
                    logger.warning(f"Could not remove {update.source_name}: {e}")
        
        self._pending_updates = []
        logger.info("Cleared updates folder")
    
    # --------------------------------------------------------
    # ROLLBACK
    # --------------------------------------------------------
    
    def get_backups(self) -> List[BackupInfo]:
        """Get list of available backups."""
        backups = []
        
        if not self.config.backups_dir.exists():
            return backups
        
        for backup_dir in sorted(self.config.backups_dir.iterdir(), reverse=True):
            if not backup_dir.is_dir() or not backup_dir.name.startswith('backup_'):
                continue
            
            manifest_path = backup_dir / 'manifest.json'
            file_count = 0
            
            if manifest_path.exists():
                with open(manifest_path) as f:
                    manifest = json.load(f)
                    file_count = len(manifest)
            
            # Calculate total size
            total_size = sum(
                f.stat().st_size for f in backup_dir.rglob('*') if f.is_file()
            )
            
            backups.append(BackupInfo(
                name=backup_dir.name,
                path=str(backup_dir),
                created_at=datetime.fromtimestamp(
                    backup_dir.stat().st_mtime
                ).isoformat(),
                file_count=file_count,
                size_bytes=total_size
            ))
        
        return backups
    
    def rollback(self, backup_name: str = None) -> UpdateResult:
        """
        Rollback to a previous backup.
        
        Args:
            backup_name: Name of backup to restore. If None, uses latest.
        
        Returns:
            UpdateResult with success status
        """
        backups = self.get_backups()
        
        if not backups:
            return UpdateResult(
                success=False,
                errors=["No backups available"]
            )
        
        # Find the requested backup
        if backup_name:
            backup = next((b for b in backups if b.name == backup_name), None)
            if not backup:
                return UpdateResult(
                    success=False,
                    errors=[f"Backup not found: {backup_name}"]
                )
        else:
            backup = backups[0]  # Latest
        
        backup_path = Path(backup.path)
        manifest_path = backup_path / 'manifest.json'
        
        if not manifest_path.exists():
            return UpdateResult(
                success=False,
                errors=["Backup manifest not found"]
            )
        
        with open(manifest_path) as f:
            manifest = json.load(f)
        
        result = UpdateResult(success=True)
        
        for entry in manifest:
            try:
                src = backup_path / entry['relative_path']
                dest = Path(entry['original_path'])
                
                if not src.exists():
                    result.skipped += 1
                    continue
                
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)
                
                # Verify hash
                new_hash = self._calculate_hash(dest)
                if new_hash != entry['hash']:
                    raise IOError("Hash mismatch after restore")
                
                result.applied += 1
                
            except Exception as e:
                result.failed += 1
                result.errors.append(f"{entry['relative_path']}: {e}")
        
        result.success = result.failed == 0
        logger.info(f"Rollback complete: {result.applied} restored, {result.failed} failed")
        
        return result
    
    def delete_backup(self, backup_name: str) -> bool:
        """Delete a specific backup."""
        backup_path = self.config.backups_dir / backup_name
        
        if backup_path.exists() and backup_path.is_dir():
            shutil.rmtree(backup_path)
            logger.info(f"Deleted backup: {backup_name}")
            return True
        
        return False
    
    # --------------------------------------------------------
    # STATUS INFO
    # --------------------------------------------------------
    
    def get_status(self) -> Dict[str, Any]:
        """Get current update system status."""
        updates = self.check_for_updates()
        backups = self.get_backups()
        
        return {
            'updates_available': updates['has_updates'],
            'update_count': updates['count'],
            'updates': updates['updates'],
            'by_category': updates['by_category'],
            'backup_count': len(backups),
            'backups': [b.to_dict() for b in backups[:5]],  # Last 5
            'config': self.config.to_dict()
        }


# ============================================================
# API ROUTES (Flask Blueprint)
# ============================================================

def register_update_routes(app, manager: UpdateManager = None):
    """
    Register update management API routes with a Flask app.
    
    Usage:
        from update_manager import UpdateManager, register_update_routes
        
        manager = UpdateManager()
        register_update_routes(app, manager)
    """
    from flask import Blueprint, jsonify, request
    
    update_bp = Blueprint('updates', __name__, url_prefix='/api/updates')
    
    if manager is None:
        manager = UpdateManager()
    
    @update_bp.route('/status', methods=['GET'])
    def get_status():
        """Get update system status."""
        try:
            status = manager.get_status()
            return jsonify({'success': True, 'data': status})
        except Exception as e:
            logger.error(f"Status check failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @update_bp.route('/check', methods=['GET'])
    def check_updates():
        """Check for available updates."""
        try:
            updates = manager.check_for_updates()
            return jsonify({'success': True, 'data': updates})
        except Exception as e:
            logger.error(f"Update check failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @update_bp.route('/apply', methods=['POST'])
    def apply_updates():
        """Apply pending updates."""
        try:
            data = request.get_json() or {}
            create_backup = data.get('create_backup', True)
            
            result = manager.apply_updates(create_backup=create_backup)
            
            return jsonify({
                'success': result.success,
                'data': result.to_dict()
            })
        except Exception as e:
            logger.error(f"Update application failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @update_bp.route('/backups', methods=['GET'])
    def list_backups():
        """List available backups."""
        try:
            backups = manager.get_backups()
            return jsonify({
                'success': True,
                'data': [b.to_dict() for b in backups]
            })
        except Exception as e:
            logger.error(f"Backup listing failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @update_bp.route('/rollback', methods=['POST'])
    def rollback():
        """Rollback to a previous backup."""
        try:
            data = request.get_json() or {}
            backup_name = data.get('backup_name')
            
            result = manager.rollback(backup_name=backup_name)
            
            return jsonify({
                'success': result.success,
                'data': result.to_dict()
            })
        except Exception as e:
            logger.error(f"Rollback failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @update_bp.route('/backups/<backup_name>', methods=['DELETE'])
    def delete_backup(backup_name):
        """Delete a specific backup."""
        try:
            success = manager.delete_backup(backup_name)
            return jsonify({'success': success})
        except Exception as e:
            logger.error(f"Backup deletion failed: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    app.register_blueprint(update_bp)
    logger.info("Update API routes registered")


# ============================================================
# CLI INTERFACE
# ============================================================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='TechWriterReview Update Manager')
    parser.add_argument('--check', action='store_true', help='Check for updates')
    parser.add_argument('--apply', action='store_true', help='Apply updates')
    parser.add_argument('--rollback', action='store_true', help='Rollback to latest backup')
    parser.add_argument('--backups', action='store_true', help='List backups')
    parser.add_argument('--status', action='store_true', help='Show status')
    parser.add_argument('--base-dir', type=str, help='Base directory path')
    
    args = parser.parse_args()
    
    # Setup logging for CLI
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    manager = UpdateManager(Path(args.base_dir) if args.base_dir else None)
    
    if args.check:
        result = manager.check_for_updates()
        print(json.dumps(result, indent=2))
    
    elif args.apply:
        result = manager.apply_updates()
        print(json.dumps(result.to_dict(), indent=2))
    
    elif args.rollback:
        result = manager.rollback()
        print(json.dumps(result.to_dict(), indent=2))
    
    elif args.backups:
        backups = manager.get_backups()
        for b in backups:
            print(f"{b.name} - {b.file_count} files - {b.created_at}")
    
    elif args.status:
        status = manager.get_status()
        print(json.dumps(status, indent=2))
    
    else:
        parser.print_help()
