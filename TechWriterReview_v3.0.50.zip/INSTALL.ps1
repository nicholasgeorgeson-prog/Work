<#
.SYNOPSIS
    TechWriterReview Installer v3.0.50
    
.DESCRIPTION
    Installs TechWriterReview to the specified directory, creates Python virtual
    environment, installs dependencies, and sets up Run/Stop scripts.
    
    Designed for air-gapped Windows environments. No internet required if
    Python 3.8+ is already installed.

.PARAMETER InstallPath
    Target installation directory. Default: C:\TWR

.PARAMETER SkipCleanup
    If specified, keeps installer files after installation.

.EXAMPLE
    .\INSTALL.ps1
    .\INSTALL.ps1 -InstallPath "D:\Tools\TWR"
    .\INSTALL.ps1 -SkipCleanup
#>

param(
    [string]$InstallPath = "C:\TWR",
    [switch]$SkipCleanup
)

$ErrorActionPreference = "Stop"
$Version = "3.0.50"

# ============================================================
# HELPER FUNCTIONS
# ============================================================

function Write-Banner {
    param([string]$Text, [string]$Color = "Cyan")
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor $Color
    Write-Host "  $Text" -ForegroundColor $Color
    Write-Host ("=" * 60) -ForegroundColor $Color
}

function Write-Step {
    param([int]$Num, [string]$Text)
    Write-Host ""
    Write-Host "[$Num] $Text" -ForegroundColor Yellow
}

function Write-Success {
    param([string]$Text)
    Write-Host "    [OK] $Text" -ForegroundColor Green
}

function Write-Fail {
    param([string]$Text)
    Write-Host "    [FAIL] $Text" -ForegroundColor Red
}

function Write-Info {
    param([string]$Text)
    Write-Host "    $Text" -ForegroundColor Gray
}

function Test-PythonVersion {
    try {
        $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
        if (-not $pythonCmd) {
            $pythonCmd = Get-Command python3 -ErrorAction SilentlyContinue
        }
        if (-not $pythonCmd) {
            return $null
        }
        
        $versionOutput = & $pythonCmd.Source --version 2>&1
        if ($versionOutput -match "Python (\d+)\.(\d+)\.(\d+)") {
            $major = [int]$matches[1]
            $minor = [int]$matches[2]
            if ($major -ge 3 -and $minor -ge 8) {
                return $pythonCmd.Source
            }
        }
        return $null
    }
    catch {
        return $null
    }
}

# ============================================================
# MAIN INSTALLATION
# ============================================================

Write-Banner "TechWriterReview Installer v$Version"
Write-Host ""
Write-Host "  Target: $InstallPath" -ForegroundColor White
Write-Host ""

# Determine script location (where the zip was extracted)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceApp = Join-Path $ScriptDir "TechWriterReview"

if (-not (Test-Path $SourceApp)) {
    Write-Fail "Cannot find TechWriterReview folder in $ScriptDir"
    Write-Info "Make sure you extracted the entire ZIP file first."
    exit 1
}

# ============================================================
# STEP 1: Check Python
# ============================================================
Write-Step 1 "Checking Python installation..."

$PythonPath = Test-PythonVersion
if (-not $PythonPath) {
    Write-Fail "Python 3.8+ not found"
    Write-Info ""
    Write-Info "Please install Python 3.8 or later from:"
    Write-Info "  https://www.python.org/downloads/"
    Write-Info ""
    Write-Info "Make sure to check 'Add Python to PATH' during installation."
    exit 1
}

$PythonVersion = & $PythonPath --version 2>&1
Write-Success "Found $PythonVersion at $PythonPath"

# ============================================================
# STEP 2: Create installation directory
# ============================================================
Write-Step 2 "Creating installation directory..."

if (Test-Path $InstallPath) {
    Write-Info "Directory exists, checking for existing installation..."
    $existingApp = Join-Path $InstallPath "app"
    if (Test-Path $existingApp) {
        Write-Host ""
        Write-Host "    WARNING: Existing installation found!" -ForegroundColor Yellow
        $confirm = Read-Host "    Overwrite? (y/N)"
        if ($confirm -ne 'y' -and $confirm -ne 'Y') {
            Write-Info "Installation cancelled."
            exit 0
        }
        Remove-Item -Path $existingApp -Recurse -Force
    }
}
else {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
}

Write-Success "Installation directory ready: $InstallPath"

# ============================================================
# STEP 3: Copy application files
# ============================================================
Write-Step 3 "Copying application files..."

$AppDir = Join-Path $InstallPath "app"
Copy-Item -Path $SourceApp -Destination $AppDir -Recurse -Force

# Verify critical files
$criticalFiles = @(
    "app.py",
    "core.py",
    "requirements.txt",
    "config.json",
    "templates/index.html",
    "static/js/app.js",
    "static/css/style.css",
    "statement_forge/__init__.py"
)

$missingFiles = @()
foreach ($file in $criticalFiles) {
    $fullPath = Join-Path $AppDir $file
    if (-not (Test-Path $fullPath)) {
        $missingFiles += $file
    }
}

if ($missingFiles.Count -gt 0) {
    Write-Fail "Missing critical files:"
    foreach ($f in $missingFiles) {
        Write-Info "  - $f"
    }
    exit 1
}

$fileCount = (Get-ChildItem -Path $AppDir -Recurse -File).Count
Write-Success "Copied $fileCount files to $AppDir"

# ============================================================
# STEP 4: Create virtual environment
# ============================================================
Write-Step 4 "Creating Python virtual environment..."

$VenvDir = Join-Path $InstallPath ".venv"
if (Test-Path $VenvDir) {
    Write-Info "Removing existing virtual environment..."
    Remove-Item -Path $VenvDir -Recurse -Force
}

& $PythonPath -m venv $VenvDir 2>&1 | Out-Null

if (-not (Test-Path (Join-Path $VenvDir "Scripts\python.exe"))) {
    Write-Fail "Failed to create virtual environment"
    exit 1
}

Write-Success "Virtual environment created at $VenvDir"

# ============================================================
# STEP 5: Install dependencies
# ============================================================
Write-Step 5 "Installing Python dependencies..."

$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
$VenvPip = Join-Path $VenvDir "Scripts\pip.exe"
$RequirementsFile = Join-Path $AppDir "requirements.txt"

Write-Info "This may take a minute..."

# Upgrade pip first (suppress warnings)
& $VenvPython -m pip install --upgrade pip --quiet 2>&1 | Out-Null

# Install requirements
$pipOutput = & $VenvPip install -r $RequirementsFile --quiet 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Fail "Failed to install dependencies"
    Write-Info "Error: $pipOutput"
    Write-Info ""
    Write-Info "If you're in an air-gapped environment, you may need to"
    Write-Info "pre-download wheel files and use: pip install --no-index --find-links=<wheels_dir>"
    exit 1
}

# Verify key packages
$testImport = & $VenvPython -c "import flask, waitress; print('OK')" 2>&1
if ($testImport -ne "OK") {
    Write-Fail "Package verification failed"
    exit 1
}

Write-Success "Dependencies installed successfully"

# ============================================================
# STEP 6: Create Run/Stop scripts
# ============================================================
Write-Step 6 "Creating launcher scripts..."

# Run_TWR.bat
$RunScript = @"
@echo off
title TechWriterReview Server
cd /d "$AppDir"

echo.
echo  Starting TechWriterReview...
echo  Server will be at http://127.0.0.1:5050
echo.
echo  Keep this window open while using the tool.
echo  Press Ctrl+C or close this window to stop.
echo.

"$VenvPython" app.py

if errorlevel 1 (
    echo.
    echo  ERROR: Server failed to start
    echo  Check the logs folder for details.
    pause
)
"@

$RunScriptPath = Join-Path $InstallPath "Run_TWR.bat"
Set-Content -Path $RunScriptPath -Value $RunScript -Encoding ASCII
Write-Success "Created $RunScriptPath"

# Stop_TWR.bat
$StopScript = @"
@echo off
echo Stopping TechWriterReview...
taskkill /f /im python.exe /fi "WINDOWTITLE eq TechWriterReview*" 2>nul
if errorlevel 1 (
    echo No running instance found, or already stopped.
) else (
    echo Server stopped.
)
timeout /t 2 /nobreak >nul
"@

$StopScriptPath = Join-Path $InstallPath "Stop_TWR.bat"
Set-Content -Path $StopScriptPath -Value $StopScript -Encoding ASCII
Write-Success "Created $StopScriptPath"

# ============================================================
# STEP 7: Verify installation
# ============================================================
Write-Step 7 "Verifying installation..."

# Test import of main module
$verifyCmd = "import sys; sys.path.insert(0, '$($AppDir -replace '\\','/')'); import app; print('OK')"
$verifyResult = & $VenvPython -c $verifyCmd 2>&1

if ($verifyResult -match "OK") {
    Write-Success "Application modules load correctly"
}
else {
    Write-Fail "Module verification failed: $verifyResult"
    exit 1
}

# ============================================================
# STEP 8: Cleanup (optional)
# ============================================================
if (-not $SkipCleanup) {
    Write-Step 8 "Cleaning up installer files..."
    
    # Remove the source TechWriterReview folder (we copied it)
    if (Test-Path $SourceApp) {
        Remove-Item -Path $SourceApp -Recurse -Force -ErrorAction SilentlyContinue
        Write-Info "Removed source folder"
    }
    
    # Note: We don't delete INSTALL.ps1 since we're running from it
    # User can delete the extracted folder manually
    
    Write-Success "Cleanup complete"
    Write-Info "You can delete this folder after installation."
}
else {
    Write-Step 8 "Skipping cleanup (--SkipCleanup specified)"
}

# ============================================================
# DONE
# ============================================================
Write-Banner "Installation Complete!" "Green"

Write-Host ""
Write-Host "  Installation Location: $InstallPath" -ForegroundColor White
Write-Host ""
Write-Host "  To start TechWriterReview:" -ForegroundColor Cyan
Write-Host "    1. Double-click: $RunScriptPath" -ForegroundColor White
Write-Host "    2. Open browser to: http://127.0.0.1:5050" -ForegroundColor White
Write-Host ""
Write-Host "  To stop:" -ForegroundColor Cyan
Write-Host "    Close the server window or run: $StopScriptPath" -ForegroundColor White
Write-Host ""

# Create desktop shortcut option
Write-Host "  Create desktop shortcut? (y/N): " -ForegroundColor Yellow -NoNewline
$createShortcut = Read-Host

if ($createShortcut -eq 'y' -or $createShortcut -eq 'Y') {
    try {
        $WshShell = New-Object -ComObject WScript.Shell
        $Desktop = [Environment]::GetFolderPath("Desktop")
        $Shortcut = $WshShell.CreateShortcut("$Desktop\TechWriterReview.lnk")
        $Shortcut.TargetPath = $RunScriptPath
        $Shortcut.WorkingDirectory = $InstallPath
        $Shortcut.Description = "TechWriterReview Document Analysis Tool"
        $Shortcut.Save()
        Write-Success "Desktop shortcut created!"
    }
    catch {
        Write-Info "Could not create shortcut: $_"
    }
}

Write-Host ""
Write-Host "  Press Enter to exit..." -ForegroundColor Gray
Read-Host
