<# 
    TechWriterReview v3.0.72 Patch
    Full-Height Content Fix for Tab Panels
    
    WHAT THIS FIXES:
    - Graph, Adjudication, RACI Matrix now fill available vertical space
    - No more white space at bottom of modal
    - Content areas expand properly
    
    USAGE:
    1. Extract this ZIP to a temporary folder
    2. Right-click UPDATE.ps1 and select "Run with PowerShell"
    3. Enter your TWR install path when prompted
#>

param(
    [string]$InstallPath = ""
)

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host "   TechWriterReview v3.0.72 Patch" -ForegroundColor Cyan
Write-Host "   Full-Height Content Fix" -ForegroundColor Cyan
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host ""

# Get install path
if (-not $InstallPath) {
    Write-Host "  Enter your TWR install path" -ForegroundColor Yellow
    Write-Host "  (e.g., C:\TWR or C:\Users\You\Desktop\Doc Review)" -ForegroundColor Gray
    Write-Host ""
    $InstallPath = Read-Host "  Path"
}

# Validate path
$AppDir = Join-Path $InstallPath "app"
if (-not (Test-Path $AppDir)) {
    Write-Host ""
    Write-Host "  [ERROR] app folder not found at: $AppDir" -ForegroundColor Red
    pause
    exit 1
}

# Find the CSS file to patch
$TargetCSS = Join-Path $AppDir "static\css\style.css"
if (-not (Test-Path $TargetCSS)) {
    $TargetCSS = Join-Path $AppDir "TechWriterReview\static\css\style.css"
}

if (-not (Test-Path $TargetCSS)) {
    Write-Host ""
    Write-Host "  [ERROR] style.css not found" -ForegroundColor Red
    pause
    exit 1
}

# Backup existing CSS
$BackupPath = "$TargetCSS.backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
Copy-Item -Path $TargetCSS -Destination $BackupPath -Force
Write-Host "  [OK] Backed up existing CSS" -ForegroundColor Green

# Copy new CSS
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PatchCSS = Join-Path $ScriptDir "TechWriterReview\static\css\style.css"

if (-not (Test-Path $PatchCSS)) {
    Write-Host ""
    Write-Host "  [ERROR] Patch CSS not found" -ForegroundColor Red
    pause
    exit 1
}

Copy-Item -Path $PatchCSS -Destination $TargetCSS -Force
Write-Host "  [OK] Applied CSS patch" -ForegroundColor Green

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Green
Write-Host "   Patch Applied Successfully!" -ForegroundColor Green
Write-Host "  ==========================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Changes:" -ForegroundColor Cyan
Write-Host "    - Graph fills available height (no white space)" -ForegroundColor White
Write-Host "    - Adjudication list expands to fill space" -ForegroundColor White
Write-Host "    - RACI Matrix uses full height" -ForegroundColor White
Write-Host "    - All tab panels use flex layout" -ForegroundColor White
Write-Host ""
Write-Host "  Refresh your browser (Ctrl+F5) to see the fix." -ForegroundColor Yellow
Write-Host ""
pause
