/**
 * TechWriterReview - Role Dictionary Tab Fix
 * v3.0.60 - Fixed modal pointer-events issue
 * 
 * CHANGELOG v3.0.60:
 * - Fixed: Modal show/hide now uses classList.add/remove('active') to enable pointer-events
 * - Added: showModal() and hideModal() helper functions for consistent behavior
 * - Added: Enhanced diagnostic logging with [TWR DictFix] prefix
 * - Fixed: All toolbar buttons (Add, Import, Export, Seed, Sync, Share)
 * 
 * ROOT CAUSE OF ORIGINAL BUG: In app.js line 6977, the event listener is attached to:
 *   document.querySelectorAll('.roles-tab[data-tab="dictionary"]')
 * But the HTML uses:
 *   <button class="roles-nav-item" data-tab="dictionary">
 * 
 * The selector doesn't match (.roles-tab vs .roles-nav-item), so clicking
 * "Role Dictionary" in the sidebar never triggers loadRoleDictionary().
 */

(function() {
    'use strict';
    
    console.log('[TWR DictFix] Role Dictionary fix loading... v3.0.60');
    
    // State for dictionary data (matches app.js DictState structure)
    const DictState = {
        roles: [],
        filteredRoles: [],
        loaded: false
    };
    
    // ========================================
    // MODAL HELPER FUNCTIONS (v3.0.60)
    // ========================================
    
    /**
     * Show a modal properly - handles both inline style and CSS class
     * CRITICAL: Must add 'active' class to enable pointer-events
     */
    function showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) {
            console.warn(`[TWR DictFix] Modal not found: ${modalId}`);
            return null;
        }
        
        // Remove inline display:none if present (from HTML)
        modal.style.display = '';
        
        // Add active class (enables visibility and pointer-events via CSS)
        modal.classList.add('active');
        
        console.log(`[TWR DictFix] Modal shown: ${modalId}`);
        return modal;
    }
    
    /**
     * Hide a modal properly
     */
    function hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;
        
        modal.classList.remove('active');
        
        // Also set display:none as fallback for modals with inline styles
        modal.style.display = 'none';
        
        console.log(`[TWR DictFix] Modal hidden: ${modalId}`);
    }
    
    // ========================================
    // DICTIONARY DATA FUNCTIONS
    // ========================================
    
    /**
     * Load dictionary data from API
     */
    async function loadDictionary() {
        console.log('[TWR DictFix] loadDictionary called, loaded:', DictState.loaded);
        
        if (DictState.loaded && DictState.roles.length > 0) {
            // Already loaded, just re-render
            renderDictionary();
            return;
        }
        
        try {
            const response = await fetch('/api/roles/dictionary?include_inactive=true');
            const result = await response.json();
            
            if (result.success) {
                DictState.roles = result.data.roles || [];
                DictState.filteredRoles = [...DictState.roles];
                DictState.loaded = true;
                renderDictionary();
                updateDictStats();
                console.log('[TWR DictFix] Dictionary loaded:', DictState.roles.length, 'roles');
            } else {
                console.error('[TWR DictFix] Failed to load dictionary:', result.error);
                showDictError('Failed to load dictionary: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('[TWR DictFix] Error loading dictionary:', error);
            showDictError('Error loading dictionary: ' + error.message);
        }
    }
    
    /**
     * Render dictionary table
     */
    function renderDictionary() {
        const tbody = document.getElementById('dictionary-body');
        const emptyEl = document.getElementById('dict-empty');
        
        if (!tbody) {
            console.warn('[TWR DictFix] Dictionary table body not found');
            return;
        }
        
        // Apply filters
        const searchTerm = (document.getElementById('dict-search')?.value || '').toLowerCase();
        const sourceFilter = document.getElementById('dict-filter-source')?.value || '';
        const categoryFilter = document.getElementById('dict-filter-category')?.value || '';
        
        DictState.filteredRoles = DictState.roles.filter(role => {
            if (searchTerm) {
                const searchFields = [
                    role.role_name,
                    role.category,
                    role.description,
                    ...(role.aliases || [])
                ].filter(Boolean).join(' ').toLowerCase();
                if (!searchFields.includes(searchTerm)) return false;
            }
            if (sourceFilter && role.source !== sourceFilter) return false;
            if (categoryFilter && role.category !== categoryFilter) return false;
            return true;
        });
        
        if (DictState.filteredRoles.length === 0) {
            tbody.innerHTML = '';
            if (emptyEl) emptyEl.style.display = 'flex';
            return;
        }
        
        if (emptyEl) emptyEl.style.display = 'none';
        
        const escapeHtml = (str) => {
            if (str == null) return '';
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;')
                .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        };
        
        tbody.innerHTML = DictState.filteredRoles.map(role => {
            const aliases = (role.aliases || []).join(', ') || '-';
            const updatedAt = role.updated_at || role.created_at;
            const dateStr = updatedAt ? new Date(updatedAt).toLocaleDateString() : '-';
            const statusClass = role.is_active ? 'status-active' : 'status-inactive';
            const statusText = role.is_active ? 'Active' : 'Inactive';
            
            return `<tr data-role-id="${role.id}">
                <td>
                    <strong>${escapeHtml(role.role_name)}</strong>
                    ${aliases !== '-' ? `<div class="text-muted text-xs">Aliases: ${escapeHtml(aliases)}</div>` : ''}
                </td>
                <td><span class="category-badge">${escapeHtml(role.category || 'Custom')}</span></td>
                <td><span class="source-badge source-${escapeHtml(role.source || 'manual')}">${escapeHtml(role.source || 'manual')}</span></td>
                <td>${dateStr}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td>
                    <button class="btn btn-ghost btn-xs" onclick="TWR.DictFix.editRole(${role.id})" title="Edit">
                        <i data-lucide="edit-2"></i>
                    </button>
                    <button class="btn btn-ghost btn-xs" onclick="TWR.DictFix.toggleRole(${role.id})" title="${role.is_active ? 'Deactivate' : 'Activate'}">
                        <i data-lucide="${role.is_active ? 'eye-off' : 'eye'}"></i>
                    </button>
                    <button class="btn btn-ghost btn-xs btn-danger" onclick="TWR.DictFix.deleteRole(${role.id})" title="Delete">
                        <i data-lucide="trash-2"></i>
                    </button>
                </td>
            </tr>`;
        }).join('');
        
        // Refresh icons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
    }
    
    /**
     * Update dictionary stats display
     */
    function updateDictStats() {
        const total = DictState.roles.length;
        const active = DictState.roles.filter(r => r.is_active).length;
        const builtin = DictState.roles.filter(r => r.source === 'builtin').length;
        
        const totalEl = document.getElementById('dict-total');
        const activeEl = document.getElementById('dict-active');
        const builtinEl = document.getElementById('dict-builtin');
        
        if (totalEl) totalEl.textContent = total;
        if (activeEl) activeEl.textContent = active;
        if (builtinEl) builtinEl.textContent = builtin;
    }
    
    /**
     * Show error message in dictionary area
     */
    function showDictError(message) {
        const tbody = document.getElementById('dictionary-body');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center text-error" style="padding:20px;">
                <i data-lucide="alert-circle"></i> ${message}
            </td></tr>`;
        }
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
    }
    
    // ========================================
    // ROLE CRUD OPERATIONS
    // ========================================
    
    /**
     * Edit a role (opens the existing modal if available)
     */
    function editRole(roleId) {
        console.log('[TWR DictFix] editRole called for ID:', roleId);
        
        // Try to use existing app.js function
        if (typeof window.openRoleModal === 'function') {
            console.log('[TWR DictFix] Using app.js openRoleModal');
            window.openRoleModal(roleId);
            return;
        }
        
        // Fallback: find role and populate modal manually
        const role = DictState.roles.find(r => r.id === roleId);
        if (!role) {
            console.warn('[TWR DictFix] Role not found:', roleId);
            return;
        }
        
        const modal = document.getElementById('edit-role-modal');
        if (!modal) {
            console.warn('[TWR DictFix] edit-role-modal not found');
            return;
        }
        
        document.getElementById('edit-role-id').value = roleId;
        document.getElementById('edit-role-name').value = role.role_name || '';
        document.getElementById('edit-role-category').value = role.category || 'Custom';
        document.getElementById('edit-role-aliases').value = (role.aliases || []).join(', ');
        document.getElementById('edit-role-description').value = role.description || '';
        document.getElementById('edit-role-title').textContent = 'Edit Role';
        
        // v3.0.60: Use proper modal show function
        showModal('edit-role-modal');
    }
    
    /**
     * Toggle role active status
     */
    async function toggleRole(roleId) {
        const role = DictState.roles.find(r => r.id === roleId);
        if (!role) return;
        
        try {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const response = await fetch(`/api/roles/dictionary/${roleId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify({ is_active: !role.is_active })
            });
            
            const result = await response.json();
            if (result.success) {
                role.is_active = !role.is_active;
                renderDictionary();
                updateDictStats();
                showToast('success', `Role ${role.is_active ? 'activated' : 'deactivated'}`);
            } else {
                showToast('error', 'Failed to update role: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Error updating role: ' + error.message);
        }
    }
    
    /**
     * Delete a role
     */
    async function deleteRole(roleId) {
        if (!confirm('Are you sure you want to delete this role? This cannot be undone.')) {
            return;
        }
        
        try {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const response = await fetch(`/api/roles/dictionary/${roleId}?hard=true`, {
                method: 'DELETE',
                headers: { 'X-CSRF-Token': csrfToken }
            });
            
            const result = await response.json();
            if (result.success) {
                DictState.roles = DictState.roles.filter(r => r.id !== roleId);
                renderDictionary();
                updateDictStats();
                showToast('success', 'Role deleted');
            } else {
                showToast('error', 'Failed to delete role: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Error deleting role: ' + error.message);
        }
    }
    
    /**
     * Show toast notification
     */
    function showToast(type, message) {
        if (typeof window.toast === 'function') {
            window.toast(type, message);
        } else if (window.TWR?.Modals?.toast) {
            window.TWR.Modals.toast(type, message);
        } else {
            console.log(`[TWR DictFix] Toast [${type}]: ${message}`);
            // Fallback: simple alert for critical messages
            if (type === 'error') {
                alert(message);
            }
        }
    }
    
    // ========================================
    // MODAL OPERATIONS
    // ========================================
    
    /**
     * Show Add/Edit Role Modal
     * v3.0.60: Uses proper modal show function
     */
    function showAddRoleModal() {
        console.log('[TWR DictFix] showAddRoleModal called');
        
        const modal = document.getElementById('edit-role-modal');
        if (!modal) {
            console.warn('[TWR DictFix] edit-role-modal not found, using prompt fallback');
            // Fallback: create a simple prompt-based add
            const roleName = prompt('Enter role name:');
            if (roleName && roleName.trim()) {
                addNewRole({ role_name: roleName.trim() });
            }
            return;
        }
        
        // Clear form for new role
        const idField = document.getElementById('edit-role-id');
        const nameField = document.getElementById('edit-role-name');
        const categoryField = document.getElementById('edit-role-category');
        const aliasesField = document.getElementById('edit-role-aliases');
        const descField = document.getElementById('edit-role-description');
        const titleEl = document.getElementById('edit-role-title');
        const deliverableField = document.getElementById('edit-role-deliverable');
        const notesField = document.getElementById('edit-role-notes');
        
        if (idField) idField.value = '';
        if (nameField) nameField.value = '';
        if (categoryField) categoryField.value = 'Custom';
        if (aliasesField) aliasesField.value = '';
        if (descField) descField.value = '';
        if (titleEl) titleEl.textContent = 'Add New Role';
        if (deliverableField) deliverableField.checked = false;
        if (notesField) notesField.value = '';
        
        // v3.0.60: Use proper modal show function
        showModal('edit-role-modal');
        
        // Focus on name field
        setTimeout(() => nameField?.focus(), 100);
    }
    
    /**
     * Close the role modal
     * v3.0.60: Uses proper modal hide function
     */
    function closeRoleModal() {
        console.log('[TWR DictFix] closeRoleModal called');
        hideModal('edit-role-modal');
    }
    
    /**
     * Save role from modal form
     */
    async function saveRoleFromModal() {
        console.log('[TWR DictFix] saveRoleFromModal called');
        
        const idField = document.getElementById('edit-role-id');
        const nameField = document.getElementById('edit-role-name');
        const categoryField = document.getElementById('edit-role-category');
        const aliasesField = document.getElementById('edit-role-aliases');
        const descField = document.getElementById('edit-role-description');
        const deliverableField = document.getElementById('edit-role-deliverable');
        
        const roleName = nameField?.value?.trim();
        if (!roleName) {
            showToast('error', 'Role name is required');
            nameField?.focus();
            return;
        }
        
        const roleId = idField?.value;
        const isEdit = roleId && roleId !== '';
        
        const roleData = {
            role_name: roleName,
            category: categoryField?.value || 'Custom',
            aliases: aliasesField?.value?.split(',').map(a => a.trim()).filter(Boolean) || [],
            description: descField?.value?.trim() || '',
            is_deliverable: deliverableField?.checked || false,
            source: 'manual'
        };
        
        console.log('[TWR DictFix] Saving role:', roleData, 'isEdit:', isEdit);
        
        try {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            
            let response;
            if (isEdit) {
                response = await fetch(`/api/roles/dictionary/${roleId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken
                    },
                    body: JSON.stringify(roleData)
                });
            } else {
                response = await fetch('/api/roles/dictionary', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken
                    },
                    body: JSON.stringify(roleData)
                });
            }
            
            const result = await response.json();
            if (result.success) {
                closeRoleModal();
                DictState.loaded = false; // Force reload
                await loadDictionary();
                showToast('success', isEdit ? 'Role updated' : `Role "${roleName}" added`);
            } else {
                showToast('error', 'Failed: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Error: ' + error.message);
        }
    }
    
    /**
     * Add a new role via API (simple version for prompt fallback)
     */
    async function addNewRole(roleData) {
        try {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const response = await fetch('/api/roles/dictionary', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify({
                    role_name: roleData.role_name,
                    category: roleData.category || 'Custom',
                    source: 'manual'
                })
            });
            
            const result = await response.json();
            if (result.success) {
                DictState.loaded = false;
                await loadDictionary();
                showToast('success', `Role "${roleData.role_name}" added`);
            } else {
                showToast('error', 'Failed to add role: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Error adding role: ' + error.message);
        }
    }
    
    // ========================================
    // IMPORT/EXPORT OPERATIONS
    // ========================================
    
    /**
     * Import dictionary from file
     */
    async function importDictionary() {
        console.log('[TWR DictFix] importDictionary called');
        
        // Check for import modal first
        const importModal = document.getElementById('import-dict-modal');
        if (importModal) {
            showModal('import-dict-modal');
            return;
        }
        
        // Fallback: use file input
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.csv,.json,.xlsx,.xls,.txt';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            console.log('[TWR DictFix] Importing file:', file.name);
            
            const formData = new FormData();
            formData.append('file', file);
            
            try {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const isExcel = file.name.match(/\.xlsx?$/i);
                const endpoint = isExcel ? '/api/roles/dictionary/import-excel' : '/api/roles/dictionary/import';
                
                showToast('info', `Importing ${file.name}...`);
                
                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'X-CSRF-Token': csrfToken },
                    body: formData
                });
                
                const result = await response.json();
                if (result.success) {
                    DictState.loaded = false;
                    await loadDictionary();
                    showToast('success', result.message || `Imported ${result.data?.added || 0} roles`);
                } else {
                    showToast('error', 'Import failed: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                showToast('error', 'Import error: ' + error.message);
            }
        };
        
        input.click();
    }
    
    /**
     * Export dictionary to CSV
     */
    async function exportDictionary() {
        console.log('[TWR DictFix] exportDictionary called');
        
        try {
            showToast('info', 'Generating export...');
            const response = await fetch('/api/roles/dictionary/export');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `role_dictionary_${new Date().toISOString().slice(0, 10)}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showToast('success', 'Dictionary exported');
            } else {
                const result = await response.json();
                showToast('error', 'Export failed: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Export error: ' + error.message);
        }
    }
    
    /**
     * Seed dictionary with built-in roles
     */
    async function seedDictionary() {
        console.log('[TWR DictFix] seedDictionary called');
        
        if (!confirm('Add built-in aerospace/government roles to the dictionary?\nThis will not overwrite existing roles.')) {
            return;
        }
        
        try {
            showToast('info', 'Seeding dictionary...');
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const response = await fetch('/api/roles/dictionary/seed', {
                method: 'POST',
                headers: { 'X-CSRF-Token': csrfToken }
            });
            
            const result = await response.json();
            if (result.success) {
                DictState.loaded = false;
                await loadDictionary();
                const msg = `Added ${result.data?.added || 0} roles, ${result.data?.skipped || 0} already existed`;
                showToast('success', msg);
            } else {
                showToast('error', 'Seed failed: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Seed error: ' + error.message);
        }
    }
    
    /**
     * Sync from shared master file
     */
    async function syncDictionary() {
        console.log('[TWR DictFix] syncDictionary called');
        
        try {
            showToast('info', 'Syncing from shared master...');
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const response = await fetch('/api/roles/dictionary/sync', {
                method: 'POST',
                headers: { 'X-CSRF-Token': csrfToken }
            });
            
            const result = await response.json();
            if (result.success) {
                DictState.loaded = false;
                await loadDictionary();
                showToast('success', result.message || 'Sync complete');
            } else {
                showToast('warning', result.error || 'No shared master file found');
            }
        } catch (error) {
            showToast('error', 'Sync error: ' + error.message);
        }
    }
    
    /**
     * Download shareable master file
     */
    async function downloadMaster() {
        console.log('[TWR DictFix] downloadMaster called');
        
        try {
            showToast('info', 'Generating master file...');
            const response = await fetch('/api/roles/dictionary/download-master');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `role_dictionary_master_${new Date().toISOString().slice(0, 10)}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showToast('success', 'Master file downloaded - share with your team');
            } else {
                const result = await response.json();
                showToast('error', 'Download failed: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            showToast('error', 'Download error: ' + error.message);
        }
    }
    
    // ========================================
    // INITIALIZATION
    // ========================================
    
    /**
     * Initialize fix - attach event listener to correct element
     * v3.0.60: Enhanced logging and modal button handlers
     */
    function init() {
        console.log('[TWR DictFix] Initializing v3.0.60...');
        
        // Find the dictionary tab button using CORRECT selector
        const dictTab = document.querySelector('.roles-nav-item[data-tab="dictionary"]');
        
        if (dictTab) {
            // Use capturing phase to run before any existing handlers
            dictTab.addEventListener('click', function(e) {
                console.log('[TWR DictFix] Dictionary tab clicked - loading data...');
                loadDictionary();
            }, true);
            
            console.log('[TWR DictFix] Tab click handler attached');
        } else {
            console.warn('[TWR DictFix] Dictionary tab button not found - selector: .roles-nav-item[data-tab="dictionary"]');
        }
        
        // Filter listeners
        document.getElementById('dict-search')?.addEventListener('input', function() {
            if (DictState.loaded) {
                clearTimeout(this._debounce);
                this._debounce = setTimeout(renderDictionary, 300);
            }
        });
        
        document.getElementById('dict-filter-source')?.addEventListener('change', function() {
            if (DictState.loaded) renderDictionary();
        });
        
        document.getElementById('dict-filter-category')?.addEventListener('change', function() {
            if (DictState.loaded) renderDictionary();
        });
        
        // Toolbar button handlers
        initToolbarButtons();
        
        // Modal button handlers
        initModalButtons();
        
        console.log('[TWR DictFix] Fully initialized v3.0.60');
    }
    
    /**
     * Initialize toolbar buttons
     * Uses a slight delay to ensure DOM is fully ready
     */
    function initToolbarButtons() {
        console.log('[TWR DictFix] Initializing toolbar buttons...');
        
        const attachHandler = (id, handler, name) => {
            const btn = document.getElementById(id);
            if (btn) {
                // Remove any existing handler we added
                if (btn._dictFixHandler) {
                    btn.removeEventListener('click', btn._dictFixHandler);
                }
                btn._dictFixHandler = handler;
                btn.addEventListener('click', handler);
                console.log(`[TWR DictFix] ✓ ${name} handler attached to #${id}`);
                return true;
            }
            console.log(`[TWR DictFix] ✗ ${name} button not found: #${id}`);
            return false;
        };
        
        // Try immediately
        let allAttached = true;
        allAttached &= attachHandler('btn-add-role', showAddRoleModal, 'Add Role');
        allAttached &= attachHandler('btn-import-dictionary', importDictionary, 'Import');
        allAttached &= attachHandler('btn-export-dictionary', exportDictionary, 'Export');
        allAttached &= attachHandler('btn-seed-dictionary', seedDictionary, 'Seed');
        allAttached &= attachHandler('btn-sync-dictionary', syncDictionary, 'Sync');
        allAttached &= attachHandler('btn-download-master', downloadMaster, 'Share');
        
        // If not all attached, try again after a delay (for elements in modals)
        if (!allAttached) {
            console.log('[TWR DictFix] Some buttons not found, retrying in 500ms...');
            setTimeout(() => {
                attachHandler('btn-add-role', showAddRoleModal, 'Add Role (delayed)');
                attachHandler('btn-import-dictionary', importDictionary, 'Import (delayed)');
                attachHandler('btn-export-dictionary', exportDictionary, 'Export (delayed)');
                attachHandler('btn-seed-dictionary', seedDictionary, 'Seed (delayed)');
                attachHandler('btn-sync-dictionary', syncDictionary, 'Sync (delayed)');
                attachHandler('btn-download-master', downloadMaster, 'Share (delayed)');
            }, 500);
        }
    }
    
    /**
     * Initialize modal save/cancel buttons
     */
    function initModalButtons() {
        console.log('[TWR DictFix] Initializing modal buttons...');
        
        // Save button
        const saveBtn = document.getElementById('btn-save-role');
        if (saveBtn) {
            saveBtn.addEventListener('click', saveRoleFromModal);
            console.log('[TWR DictFix] ✓ Modal save handler attached');
        } else {
            console.log('[TWR DictFix] ✗ Modal save button not found: #btn-save-role');
        }
        
        // Cancel button
        const cancelBtn = document.getElementById('btn-cancel-role');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', closeRoleModal);
            console.log('[TWR DictFix] ✓ Modal cancel handler attached');
        } else {
            console.log('[TWR DictFix] ✗ Modal cancel button not found: #btn-cancel-role');
        }
        
        // Close button (X)
        const closeBtn = document.getElementById('btn-close-role-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', closeRoleModal);
            console.log('[TWR DictFix] ✓ Modal close handler attached');
        } else {
            console.log('[TWR DictFix] ✗ Modal close button not found: #btn-close-role-modal');
        }
        
        // Click overlay to close
        const modal = document.getElementById('edit-role-modal');
        const overlay = modal?.querySelector('.modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', closeRoleModal);
            console.log('[TWR DictFix] ✓ Modal overlay handler attached');
        }
    }
    
    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Expose functions globally for button onclick handlers
    window.TWR = window.TWR || {};
    window.TWR.DictFix = {
        loadDictionary: loadDictionary,
        renderDictionary: renderDictionary,
        editRole: editRole,
        toggleRole: toggleRole,
        deleteRole: deleteRole,
        showAddRoleModal: showAddRoleModal,
        closeRoleModal: closeRoleModal,
        saveRoleFromModal: saveRoleFromModal,
        addNewRole: addNewRole,
        importDictionary: importDictionary,
        exportDictionary: exportDictionary,
        seedDictionary: seedDictionary,
        syncDictionary: syncDictionary,
        downloadMaster: downloadMaster,
        showModal: showModal,
        hideModal: hideModal
    };
    
    console.log('[TWR DictFix] Module loaded and exposed at window.TWR.DictFix');
    
})();
