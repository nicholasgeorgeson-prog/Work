/**
 * TechWriterReview - Graph Diagnostic Script
 * v3.0.61 - Paste in browser console to diagnose graph issues
 */

(function() {
    console.log('='.repeat(60));
    console.log('TWR GRAPH DIAGNOSTIC v3.0.61');
    console.log('='.repeat(60));
    
    // Test 1: Check D3.js availability
    console.log('\n[TEST 1] D3.js Availability:');
    console.log('  typeof d3:', typeof d3);
    if (typeof d3 !== 'undefined') {
        console.log('  d3.version:', d3.version);
        console.log('  ✓ D3.js is available');
    } else {
        console.log('  ✗ D3.js NOT LOADED - Graph will use fallback table');
    }
    
    // Test 2: Check TWR.Roles functions
    console.log('\n[TEST 2] TWR.Roles Graph Functions:');
    const funcs = [
        'renderRolesGraph',
        'initGraphControls', 
        'updateGraphVisibility',
        'highlightSearchMatches',
        'resetGraphView',
        'clearNodeSelection'
    ];
    funcs.forEach(fn => {
        const exists = typeof window.TWR?.Roles?.[fn] === 'function';
        console.log(`  TWR.Roles.${fn}:`, exists ? '✓ EXISTS' : '✗ NOT FOUND');
    });
    
    // Test 3: Check graph DOM elements
    console.log('\n[TEST 3] Graph DOM Elements:');
    const elements = [
        'roles-graph',           // Section container
        'roles-graph-container', // Graph container
        'roles-graph-svg',       // SVG element
        'graph-loading',         // Loading indicator
        'graph-fallback',        // Fallback table
        'graph-search',          // Search input
        'graph-weight-filter',   // Weight slider
        'graph-max-nodes',       // Max nodes dropdown
        'graph-layout',          // Layout dropdown
        'graph-labels'           // Labels dropdown
    ];
    
    elements.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            const styles = getComputedStyle(el);
            const visible = styles.display !== 'none' && styles.visibility !== 'hidden';
            console.log(`  #${id}: ✓ EXISTS, display=${styles.display}, visible=${visible}`);
        } else {
            console.log(`  #${id}: ✗ NOT FOUND`);
        }
    });
    
    // Test 4: Check graph section visibility
    console.log('\n[TEST 4] Graph Section Visibility:');
    const graphSection = document.getElementById('roles-graph');
    if (graphSection) {
        const styles = getComputedStyle(graphSection);
        console.log('  display:', styles.display);
        console.log('  visibility:', styles.visibility);
        console.log('  has .active class:', graphSection.classList.contains('active'));
        console.log('  offsetWidth:', graphSection.offsetWidth);
        console.log('  offsetHeight:', graphSection.offsetHeight);
    }
    
    // Test 5: Check control values
    console.log('\n[TEST 5] Current Control Values:');
    const controls = {
        'graph-search': 'value',
        'graph-weight-filter': 'value',
        'graph-max-nodes': 'value',
        'graph-layout': 'value',
        'graph-labels': 'value'
    };
    Object.entries(controls).forEach(([id, prop]) => {
        const el = document.getElementById(id);
        if (el) {
            console.log(`  #${id}.${prop}:`, el[prop]);
            console.log(`    - disabled:`, el.disabled);
            console.log(`    - _twrInitialized:`, el._twrInitialized);
        }
    });
    
    // Test 6: Check event handlers
    console.log('\n[TEST 6] Event Handler Check:');
    const maxNodes = document.getElementById('graph-max-nodes');
    if (maxNodes) {
        // Try to get listeners (this is tricky in modern browsers)
        console.log('  #graph-max-nodes._twrInitialized:', maxNodes._twrInitialized);
        
        // Add a test listener
        const testHandler = () => console.log('  >>> TEST: Max nodes change detected!');
        maxNodes.addEventListener('change', testHandler);
        console.log('  Added test change handler to #graph-max-nodes');
        console.log('  Try changing the dropdown and look for "TEST:" message');
    }
    
    // Test 7: Try calling renderRolesGraph directly
    console.log('\n[TEST 7] Direct Function Call Test:');
    console.log('  Attempting to call TWR.Roles.renderRolesGraph()...');
    
    if (typeof window.TWR?.Roles?.renderRolesGraph === 'function') {
        try {
            // Check if graph section is visible first
            const section = document.getElementById('roles-graph');
            if (section && getComputedStyle(section).display === 'none') {
                console.log('  ⚠ Graph section is hidden (display:none)');
                console.log('  Making it visible for testing...');
                section.style.display = 'block';
            }
            
            window.TWR.Roles.renderRolesGraph(true);
            console.log('  ✓ renderRolesGraph() called - check Network tab for API call');
        } catch (e) {
            console.error('  ✗ Error calling renderRolesGraph:', e);
        }
    } else {
        console.log('  ✗ Cannot test - function not available');
    }
    
    // Test 8: Check API availability
    console.log('\n[TEST 8] API Function Check:');
    console.log('  window.api:', typeof window.api);
    console.log('  TWR.API:', typeof window.TWR?.API);
    console.log('  TWR.API.api:', typeof window.TWR?.API?.api);
    
    // Test 9: Manual API test
    console.log('\n[TEST 9] Manual API Test:');
    console.log('  Fetching /api/roles/graph...');
    fetch('/api/roles/graph?max_nodes=50&min_weight=1')
        .then(r => r.json())
        .then(data => {
            console.log('  API Response:', data);
            if (data.success) {
                console.log('  ✓ API returned data');
                console.log('    Nodes:', data.data?.nodes?.length || 0);
                console.log('    Links:', data.data?.links?.length || 0);
            } else {
                console.log('  ✗ API error:', data.error);
            }
        })
        .catch(e => console.error('  ✗ Fetch error:', e));
    
    console.log('\n' + '='.repeat(60));
    console.log('DIAGNOSTIC RUNNING - Check console for API response');
    console.log('='.repeat(60));
    
    // Return helper functions
    return {
        showGraphSection: () => {
            const section = document.getElementById('roles-graph');
            if (section) {
                section.style.display = 'block';
                section.classList.add('active');
                console.log('Graph section shown');
            }
        },
        renderGraph: () => {
            if (window.TWR?.Roles?.renderRolesGraph) {
                window.TWR.Roles.renderRolesGraph(true);
                console.log('renderRolesGraph(true) called');
            }
        },
        initControls: () => {
            if (window.TWR?.Roles?.initGraphControls) {
                window.TWR.Roles.initGraphControls();
                console.log('initGraphControls() called');
            } else if (window.TWR?.RolesTabs?.initGraphControlsFallback) {
                window.TWR.RolesTabs.initGraphControlsFallback();
                console.log('initGraphControlsFallback() called');
            }
        }
    };
})();
