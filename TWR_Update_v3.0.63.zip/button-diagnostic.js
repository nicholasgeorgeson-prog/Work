/**
 * TechWriterReview - Button Diagnostic Helper
 * v3.0.60 - Run from browser console to diagnose button issues
 * 
 * USAGE: Paste this entire script in DevTools Console (F12)
 * 
 * Tests:
 * 1. Checks if fix scripts loaded
 * 2. Checks if buttons exist
 * 3. Tests event handlers
 * 4. Checks for CSS issues blocking clicks
 */

(function() {
    console.log('='.repeat(60));
    console.log('TWR BUTTON DIAGNOSTIC v3.0.60');
    console.log('='.repeat(60));
    
    // Test 1: Check if fix scripts loaded
    console.log('\n[TEST 1] Fix Scripts Loaded:');
    console.log('  TWR.DictFix:', typeof window.TWR?.DictFix === 'object' ? '✓ LOADED' : '✗ NOT FOUND');
    console.log('  TWR.RolesTabs:', typeof window.TWR?.RolesTabs === 'object' ? '✓ LOADED' : 'ℹ (not exposed to window, OK)');
    
    // Test 2: Check toolbar buttons
    console.log('\n[TEST 2] Role Dictionary Toolbar Buttons:');
    const dictButtons = [
        'btn-add-role',
        'btn-import-dictionary',
        'btn-export-dictionary',
        'btn-seed-dictionary',
        'btn-sync-dictionary',
        'btn-download-master'
    ];
    
    dictButtons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            const styles = getComputedStyle(btn);
            const clickable = styles.pointerEvents !== 'none';
            console.log(`  #${id}: ✓ EXISTS ${clickable ? '✓ clickable' : '✗ pointer-events:none'}`);
        } else {
            console.log(`  #${id}: ✗ NOT FOUND`);
        }
    });
    
    // Test 3: Check modal
    console.log('\n[TEST 3] Edit Role Modal:');
    const modal = document.getElementById('edit-role-modal');
    if (modal) {
        const styles = getComputedStyle(modal);
        console.log('  #edit-role-modal: ✓ EXISTS');
        console.log('    - display:', modal.style.display || styles.display);
        console.log('    - visibility:', styles.visibility);
        console.log('    - pointer-events:', styles.pointerEvents);
        console.log('    - has .active class:', modal.classList.contains('active'));
        
        // Check modal buttons
        const modalButtons = ['btn-save-role', 'btn-cancel-role', 'btn-close-role-modal'];
        modalButtons.forEach(id => {
            const btn = document.getElementById(id);
            console.log(`    #${id}:`, btn ? '✓ EXISTS' : '✗ NOT FOUND');
        });
    } else {
        console.log('  #edit-role-modal: ✗ NOT FOUND');
    }
    
    // Test 4: Check adjudication list
    console.log('\n[TEST 4] Adjudication Container:');
    const adjList = document.getElementById('adjudication-list');
    if (adjList) {
        console.log('  #adjudication-list: ✓ EXISTS');
        console.log('    - has _adjClickHandler:', !!adjList._adjClickHandler);
        console.log('    - has _adjChangeHandler:', !!adjList._adjChangeHandler);
        
        const items = adjList.querySelectorAll('.adjudication-item');
        console.log('    - adjudication items:', items.length);
        
        if (items.length > 0) {
            const firstItem = items[0];
            const editBtn = firstItem.querySelector('.adj-btn-edit');
            const confirmBtn = firstItem.querySelector('.adj-btn-confirm');
            console.log('    - First item has edit button:', !!editBtn);
            console.log('    - First item has confirm button:', !!confirmBtn);
            
            if (editBtn) {
                const styles = getComputedStyle(editBtn);
                console.log('    - Edit button pointer-events:', styles.pointerEvents);
            }
        }
    } else {
        console.log('  #adjudication-list: ✗ NOT FOUND');
    }
    
    // Test 5: Interactive click test
    console.log('\n[TEST 5] Click Handler Test:');
    console.log('  Adding test click handler to document...');
    
    const testHandler = (e) => {
        const btn = e.target.closest('button');
        if (btn) {
            console.log('  CLICK DETECTED on button:', btn.id || btn.className);
        }
    };
    
    document.addEventListener('click', testHandler, true);
    console.log('  ✓ Handler added - now click any button and watch for messages');
    console.log('  (Remove handler with: window._twrRemoveTestHandler())');
    
    window._twrRemoveTestHandler = () => {
        document.removeEventListener('click', testHandler, true);
        console.log('  Test handler removed');
    };
    
    // Test 6: Manual button trigger test
    console.log('\n[TEST 6] Manual Function Test:');
    console.log('  Try running these commands to test functions directly:');
    console.log('    TWR.DictFix.showAddRoleModal()');
    console.log('    TWR.DictFix.seedDictionary()');
    console.log('    TWR.DictFix.exportDictionary()');
    
    console.log('\n' + '='.repeat(60));
    console.log('DIAGNOSTIC COMPLETE');
    console.log('='.repeat(60));
    
    // Return summary
    return {
        dictFixLoaded: typeof window.TWR?.DictFix === 'object',
        buttonsFound: dictButtons.filter(id => document.getElementById(id)).length,
        modalFound: !!document.getElementById('edit-role-modal'),
        adjListFound: !!document.getElementById('adjudication-list')
    };
})();
