<#
.SYNOPSIS
    TechWriterReview Installer v3.0.69
    
.DESCRIPTION
    Installs or upgrades TechWriterReview to the specified directory.
    
    For NEW installations:
    - Creates Python virtual environment
    - Installs dependencies
    - Sets up Run/Stop scripts
    
    For UPGRADES (existing installation detected):
    - Backs up user data (scan_history.db, dictionaries, config)
    - Removes old installation
    - Installs fresh copy
    - Restores user data
    
    Designed for air-gapped Windows environments.

.PARAMETER InstallPath
    Target installation directory. Default: C:\TWR

.PARAMETER SkipCleanup
    If specified, keeps installer files after installation.

.PARAMETER ForceClean
    If specified, removes all user data (no backup/restore).

.EXAMPLE
    .\INSTALL.ps1
    .\INSTALL.ps1 -InstallPath "D:\Tools\TWR"
    .\INSTALL.ps1 -ForceClean
#>

param(
    [string]$InstallPath = "C:\TWR",
    [switch]$SkipCleanup,
    [switch]$ForceClean
)

$Version = "3.0.75"

# ============================================================
# USER DATA FILES TO PRESERVE DURING UPGRADES
# ============================================================
$UserDataFiles = @(
    "scan_history.db",
    "role_dictionary_master.json",
    "config.json"
)

$UserDataFolders = @(
    "backups",
    "data"
)

# ============================================================
# HELPER FUNCTIONS
# ============================================================

function Write-Banner {
    param([string]$Text, [string]$Color = "Cyan")
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor $Color
    Write-Host "  $Text" -ForegroundColor $Color
    Write-Host ("=" * 60) -ForegroundColor $Color
}

function Write-Step {
    param([int]$Num, [string]$Text)
    Write-Host ""
    Write-Host "[$Num] $Text" -ForegroundColor Yellow
}

function Write-Success {
    param([string]$Text)
    Write-Host "    [OK] $Text" -ForegroundColor Green
}

function Write-Fail {
    param([string]$Text)
    Write-Host "    [FAIL] $Text" -ForegroundColor Red
}

function Write-Info {
    param([string]$Text)
    Write-Host "    $Text" -ForegroundColor Gray
}

function Write-Warn {
    param([string]$Text)
    Write-Host "    [!] $Text" -ForegroundColor Yellow
}

function Exit-WithError {
    param([string]$Message)
    if ($Message) {
        Write-Fail $Message
    }
    Write-Host ""
    Write-Host "  Installation failed. Press Enter to exit..." -ForegroundColor Red
    Read-Host
    exit 1
}

function Test-PythonVersion {
    try {
        $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
        if (-not $pythonCmd) {
            $pythonCmd = Get-Command python3 -ErrorAction SilentlyContinue
        }
        if (-not $pythonCmd) {
            return $null
        }
        
        $versionOutput = & $pythonCmd.Source --version 2>&1
        if ($versionOutput -match "Python (\d+)\.(\d+)\.(\d+)") {
            $major = [int]$matches[1]
            $minor = [int]$matches[2]
            if ($major -ge 3 -and $minor -ge 8) {
                return $pythonCmd.Source
            }
        }
        return $null
    }
    catch {
        return $null
    }
}

function Get-ExistingVersion {
    param([string]$AppDir)
    
    $versionFile = Join-Path $AppDir "version.json"
    if (Test-Path $versionFile) {
        try {
            $versionJson = Get-Content $versionFile -Raw | ConvertFrom-Json
            return $versionJson.version
        }
        catch {
            return "unknown"
        }
    }
    return $null
}

function Backup-UserData {
    param(
        [string]$AppDir,
        [string]$BackupDir
    )
    
    $backedUp = @()
    
    # Create backup directory
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    
    # Backup individual files
    foreach ($file in $UserDataFiles) {
        $sourcePath = Join-Path $AppDir $file
        if (Test-Path $sourcePath) {
            $destPath = Join-Path $BackupDir $file
            Copy-Item -Path $sourcePath -Destination $destPath -Force
            $backedUp += $file
            Write-Info "Backed up: $file"
        }
    }
    
    # Backup folders (with contents)
    foreach ($folder in $UserDataFolders) {
        $sourcePath = Join-Path $AppDir $folder
        if (Test-Path $sourcePath) {
            $itemCount = (Get-ChildItem -Path $sourcePath -Recurse -File -ErrorAction SilentlyContinue).Count
            if ($itemCount -gt 0) {
                $destPath = Join-Path $BackupDir $folder
                Copy-Item -Path $sourcePath -Destination $destPath -Recurse -Force
                $backedUp += "$folder/ ($itemCount files)"
                Write-Info "Backed up: $folder/ ($itemCount files)"
            }
        }
    }
    
    # Also check for any .db files we might have missed
    $dbFiles = Get-ChildItem -Path $AppDir -Filter "*.db" -File -ErrorAction SilentlyContinue
    foreach ($db in $dbFiles) {
        if ($db.Name -notin $UserDataFiles -and $db.Name -notin $backedUp) {
            $destPath = Join-Path $BackupDir $db.Name
            Copy-Item -Path $db.FullName -Destination $destPath -Force
            $backedUp += $db.Name
            Write-Info "Backed up: $($db.Name)"
        }
    }
    
    return $backedUp
}

function Restore-UserData {
    param(
        [string]$BackupDir,
        [string]$AppDir
    )
    
    $restored = @()
    
    if (-not (Test-Path $BackupDir)) {
        return $restored
    }
    
    # Restore individual files
    foreach ($file in $UserDataFiles) {
        $sourcePath = Join-Path $BackupDir $file
        if (Test-Path $sourcePath) {
            $destPath = Join-Path $AppDir $file
            Copy-Item -Path $sourcePath -Destination $destPath -Force
            $restored += $file
            Write-Info "Restored: $file"
        }
    }
    
    # Restore folders
    foreach ($folder in $UserDataFolders) {
        $sourcePath = Join-Path $BackupDir $folder
        if (Test-Path $sourcePath) {
            $destPath = Join-Path $AppDir $folder
            if (-not (Test-Path $destPath)) {
                New-Item -ItemType Directory -Path $destPath -Force | Out-Null
            }
            $items = Get-ChildItem -Path $sourcePath -Recurse -File
            foreach ($item in $items) {
                $relativePath = $item.FullName.Substring($sourcePath.Length + 1)
                $destFile = Join-Path $destPath $relativePath
                $destFileDir = Split-Path -Parent $destFile
                if (-not (Test-Path $destFileDir)) {
                    New-Item -ItemType Directory -Path $destFileDir -Force | Out-Null
                }
                Copy-Item -Path $item.FullName -Destination $destFile -Force
            }
            $restored += "$folder/"
            Write-Info "Restored: $folder/"
        }
    }
    
    # Restore any extra .db files
    $dbFiles = Get-ChildItem -Path $BackupDir -Filter "*.db" -File -ErrorAction SilentlyContinue
    foreach ($db in $dbFiles) {
        if ($db.Name -notin $UserDataFiles -and $db.Name -notin $restored) {
            $destPath = Join-Path $AppDir $db.Name
            Copy-Item -Path $db.FullName -Destination $destPath -Force
            $restored += $db.Name
            Write-Info "Restored: $($db.Name)"
        }
    }
    
    return $restored
}

# ============================================================
# MAIN INSTALLATION (wrapped in try/catch)
# ============================================================

try {
    Write-Banner "TechWriterReview Installer v$Version"
    Write-Host ""
    Write-Host "  This will install or upgrade TechWriterReview." -ForegroundColor White
    Write-Host ""

    # Prompt user for install location
    Write-Host "  Install location" -ForegroundColor Cyan
    Write-Host "  Default: " -NoNewline -ForegroundColor Gray
    Write-Host "$InstallPath" -ForegroundColor White
    Write-Host ""
    Write-Host "  Enter install path (or press Enter for default): " -ForegroundColor Yellow -NoNewline
    $UserPath = Read-Host

    if ($UserPath -and $UserPath.Trim() -ne "") {
        $InstallPath = $UserPath.Trim()
        $InstallPath = $InstallPath.TrimEnd('\')
    }

    # Validate the path is a valid Windows path format
    if ($InstallPath -notmatch '^[A-Za-z]:\\') {
        Write-Fail "Invalid path format. Path must start with a drive letter (e.g., C:\TWR)"
        Exit-WithError
    }

    # Determine script location (where the zip was extracted)
    $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $SourceApp = Join-Path $ScriptDir "TechWriterReview"
    $AppDir = Join-Path $InstallPath "app"

    if (-not (Test-Path $SourceApp)) {
        Write-Fail "Cannot find TechWriterReview folder in $ScriptDir"
        Write-Info "Make sure you extracted the entire ZIP file first."
        Exit-WithError
    }

    # ============================================================
    # DETECT EXISTING INSTALLATION
    # ============================================================

    $IsUpgrade = $false
    $ExistingVersion = $null
    $BackupDir = $null

    if (Test-Path $AppDir) {
        $ExistingVersion = Get-ExistingVersion -AppDir $AppDir
        
        if ($ExistingVersion) {
            $IsUpgrade = $true
            Write-Host ""
            Write-Host "  ============================================" -ForegroundColor Yellow
            Write-Host "  EXISTING INSTALLATION DETECTED" -ForegroundColor Yellow
            Write-Host "  ============================================" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "  Current version: " -NoNewline -ForegroundColor Gray
            Write-Host "v$ExistingVersion" -ForegroundColor White
            Write-Host "  New version:     " -NoNewline -ForegroundColor Gray
            Write-Host "v$Version" -ForegroundColor Green
            Write-Host ""
            
            if (-not $ForceClean) {
                Write-Host "  The installer will:" -ForegroundColor Cyan
                Write-Host "    1. Back up your user data (scan history, dictionaries)" -ForegroundColor White
                Write-Host "    2. Remove the old installation" -ForegroundColor White
                Write-Host "    3. Install fresh v$Version" -ForegroundColor White
                Write-Host "    4. Restore your user data" -ForegroundColor White
                Write-Host ""
                Write-Host "  Your scan history and dictionaries will be PRESERVED." -ForegroundColor Green
            } else {
                Write-Host "  WARNING: -ForceClean specified!" -ForegroundColor Red
                Write-Host "  All user data will be DELETED. This cannot be undone." -ForegroundColor Red
            }
            
            Write-Host ""
            Write-Host "  Continue with upgrade? (Y/n): " -ForegroundColor Yellow -NoNewline
            $confirm = Read-Host
            if ($confirm -eq 'n' -or $confirm -eq 'N') {
                Write-Info "Upgrade cancelled."
                Write-Host ""
                Write-Host "  Press Enter to exit..." -ForegroundColor Gray
                Read-Host
                exit 0
            }
        }
    }

    Write-Host ""
    Write-Host "  Installing to: " -NoNewline -ForegroundColor Gray
    Write-Host "$InstallPath" -ForegroundColor Green
    if ($IsUpgrade) {
        Write-Host "  Mode: " -NoNewline -ForegroundColor Gray
        Write-Host "UPGRADE (v$ExistingVersion -> v$Version)" -ForegroundColor Cyan
    } else {
        Write-Host "  Mode: " -NoNewline -ForegroundColor Gray
        Write-Host "NEW INSTALLATION" -ForegroundColor Cyan
    }
    Write-Host ""
    Write-Host "  Press Enter to continue or Ctrl+C to cancel..." -ForegroundColor Gray
    Read-Host

    # ============================================================
    # STEP 1: Check Python
    # ============================================================
    Write-Step 1 "Checking Python installation..."

    $PythonPath = Test-PythonVersion
    if (-not $PythonPath) {
        Write-Fail "Python 3.8+ not found"
        Write-Info ""
        Write-Info "Please install Python 3.8 or later from:"
        Write-Info "  https://www.python.org/downloads/"
        Write-Info ""
        Write-Info "Make sure to check 'Add Python to PATH' during installation."
        Exit-WithError
    }

    $PythonVersion = & $PythonPath --version 2>&1
    Write-Success "Found $PythonVersion at $PythonPath"

    # ============================================================
    # STEP 2: Stop existing TWR processes (if upgrading)
    # ============================================================
    if ($IsUpgrade) {
        Write-Step 2 "Stopping existing TechWriterReview processes..."
        
        # Kill by window title
        taskkill /f /fi "WINDOWTITLE eq TechWriterReview*" 2>$null
        
        # Kill all python.exe (most reliable)
        $pythonProcs = Get-Process -Name "python" -ErrorAction SilentlyContinue
        if ($pythonProcs) {
            Write-Info "Stopping $($pythonProcs.Count) Python process(es)..."
            $pythonProcs | Stop-Process -Force -ErrorAction SilentlyContinue
        }
        
        # Kill pythonw.exe
        Get-Process -Name "pythonw" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        
        # Kill waitress
        Get-Process -Name "waitress-serve" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        
        # Wait for file handles to release
        Write-Info "Waiting for file handles to release..."
        Start-Sleep -Seconds 3
        
        Write-Success "Process cleanup complete"
        
        # Check for OneDrive in path and warn
        if ($InstallPath -match "OneDrive") {
            Write-Host ""
            Write-Warn "OneDrive detected in install path!"
            Write-Info "OneDrive can lock files during sync, causing upgrade failures."
            Write-Info "Recommendation: Pause OneDrive syncing before continuing."
            Write-Host ""
            Write-Host "  Continue anyway? (y/N): " -ForegroundColor Yellow -NoNewline
            $continueOneDrive = Read-Host
            if ($continueOneDrive -ne 'y' -and $continueOneDrive -ne 'Y') {
                Write-Info "Pausing for you to disable OneDrive sync..."
                Write-Info "Right-click OneDrive icon in system tray -> Pause syncing"
                Write-Host ""
                Write-Host "  Press Enter when ready to continue..." -ForegroundColor Yellow
                Read-Host
            }
        }
    } else {
        Write-Step 2 "New installation - no cleanup needed"
    }

    # ============================================================
    # STEP 3: Backup user data (if upgrading)
    # ============================================================
    if ($IsUpgrade -and -not $ForceClean) {
        Write-Step 3 "Backing up user data..."
        
        $BackupDir = Join-Path $InstallPath "upgrade_backup_$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        $backedUpItems = Backup-UserData -AppDir $AppDir -BackupDir $BackupDir
        
        if ($backedUpItems.Count -gt 0) {
            Write-Success "Backed up $($backedUpItems.Count) items to $BackupDir"
        } else {
            Write-Info "No user data found to backup"
        }
    } elseif ($IsUpgrade -and $ForceClean) {
        Write-Step 3 "Skipping backup (-ForceClean specified)..."
        Write-Warn "User data will not be preserved!"
    } else {
        Write-Step 3 "New installation - no backup needed"
    }

    # ============================================================
    # STEP 4: Remove existing installation (if upgrading)
    # ============================================================
    if ($IsUpgrade) {
        Write-Step 4 "Removing old installation..."
        
        # Helper function to remove directory with retries
        function Remove-DirectoryWithRetry {
            param([string]$Path, [int]$MaxRetries = 3)
            
            for ($i = 1; $i -le $MaxRetries; $i++) {
                try {
                    if (Test-Path $Path) {
                        Remove-Item -Path $Path -Recurse -Force -ErrorAction Stop
                        return $true
                    }
                    return $true
                }
                catch {
                    if ($i -lt $MaxRetries) {
                        Write-Info "Retry $i/$MaxRetries - waiting for files to unlock..."
                        Start-Sleep -Seconds 3
                    } else {
                        Write-Fail "Could not remove: $Path"
                        Write-Info "Error: $($_.Exception.Message)"
                        return $false
                    }
                }
            }
        }
        
        # Remove the app directory with retries
        if (Test-Path $AppDir) {
            $appRemoved = Remove-DirectoryWithRetry -Path $AppDir
            if ($appRemoved) {
                Write-Success "Removed old app directory"
            } else {
                Write-Host ""
                Write-Fail "Could not remove old app directory."
                Write-Info "Files may be locked by OneDrive or another process."
                Write-Info ""
                Write-Info "Please try:"
                Write-Info "  1. Pause OneDrive syncing"
                Write-Info "  2. Close all File Explorer windows"
                Write-Info "  3. Close any Python IDEs (VS Code, PyCharm)"
                Write-Info "  4. Wait 30 seconds and run installer again"
                Exit-WithError
            }
        }
        
        # Remove old venv (will be recreated)
        $VenvDir = Join-Path $InstallPath ".venv"
        if (Test-Path $VenvDir) {
            $venvRemoved = Remove-DirectoryWithRetry -Path $VenvDir
            if ($venvRemoved) {
                Write-Success "Removed old virtual environment"
            } else {
                Write-Warn "Could not fully remove old .venv directory"
                Write-Info "Will attempt to continue anyway..."
            }
        }
    } else {
        Write-Step 4 "Creating installation directory..."
        
        if (-not (Test-Path $InstallPath)) {
            New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
        }
    }

    Write-Success "Installation directory ready: $InstallPath"

    # ============================================================
    # STEP 4: Copy application files
    # ============================================================
    Write-Step 5 "Copying application files..."

    Copy-Item -Path $SourceApp -Destination $AppDir -Recurse -Force

    # Verify critical files
    $criticalFiles = @(
        "app.py",
        "core.py",
        "requirements.txt",
        "config.json",
        "templates/index.html",
        "static/js/app.js",
        "static/js/help-docs.js",
        "static/css/style.css",
        "statement_forge/__init__.py"
    )

    $missingFiles = @()
    foreach ($file in $criticalFiles) {
        $fullPath = Join-Path $AppDir $file
        if (-not (Test-Path $fullPath)) {
            $missingFiles += $file
        }
    }

    if ($missingFiles.Count -gt 0) {
        Write-Fail "Missing critical files:"
        foreach ($f in $missingFiles) {
            Write-Info "  - $f"
        }
        Exit-WithError
    }

    $fileCount = (Get-ChildItem -Path $AppDir -Recurse -File).Count
    Write-Success "Copied $fileCount files to $AppDir"

    # ============================================================
    # STEP 5: Restore user data (if upgrading)
    # ============================================================
    if ($IsUpgrade -and -not $ForceClean -and $BackupDir) {
        Write-Step 6 "Restoring user data..."
        
        $restoredItems = Restore-UserData -BackupDir $BackupDir -AppDir $AppDir
        
        if ($restoredItems.Count -gt 0) {
            Write-Success "Restored $($restoredItems.Count) items"
        } else {
            Write-Info "No user data to restore"
        }
    } else {
        Write-Step 6 "No user data to restore"
    }

    # ============================================================
    # STEP 6: Create virtual environment
    # ============================================================
    Write-Step 7 "Creating Python virtual environment..."

    $VenvDir = Join-Path $InstallPath ".venv"
    if (Test-Path $VenvDir) {
        Write-Info "Removing existing virtual environment..."
        Remove-Item -Path $VenvDir -Recurse -Force
    }

    & $PythonPath -m venv $VenvDir 2>&1 | Out-Null

    if (-not (Test-Path (Join-Path $VenvDir "Scripts\python.exe"))) {
        Exit-WithError "Failed to create virtual environment"
    }

    Write-Success "Virtual environment created at $VenvDir"

    # ============================================================
    # STEP 7: Install dependencies
    # ============================================================
    Write-Step 8 "Installing Python dependencies..."

    $VenvPython = Join-Path $VenvDir "Scripts\python.exe"
    $VenvPip = Join-Path $VenvDir "Scripts\pip.exe"
    $RequirementsFile = Join-Path $AppDir "requirements.txt"

    # Read requirements and count packages
    $requirements = Get-Content $RequirementsFile | Where-Object { 
        $_ -match '^\w' -and $_ -notmatch '^#' 
    }
    $totalPackages = $requirements.Count
    $currentPackage = 0

    Write-Info "Installing $totalPackages packages..."
    Write-Host ""

    # Upgrade pip first (with progress)
    Write-Host "    [" -NoNewline
    Write-Host "=" -ForegroundColor Cyan -NoNewline
    Write-Host ("-" * ($totalPackages - 1)) -NoNewline
    Write-Host "] " -NoNewline
    Write-Host "Preparing pip..." -ForegroundColor Gray
    & $VenvPython -m pip install --upgrade pip --quiet 2>&1 | Out-Null

    # Install each package with progress
    $failedPackages = @()
    foreach ($req in $requirements) {
        $currentPackage++
        $packageName = ($req -split '[<>=]')[0].Trim()
        $progressBar = "=" * $currentPackage + "-" * ($totalPackages - $currentPackage)
        $percent = [math]::Round(($currentPackage / $totalPackages) * 100)
        
        # Clear line and show progress
        Write-Host "`r    [$progressBar] $percent% - Installing $packageName...                    " -NoNewline
        
        $output = & $VenvPip install $req --quiet 2>&1
        if ($LASTEXITCODE -ne 0) {
            $failedPackages += $packageName
        }
    }

    Write-Host ""  # New line after progress

    if ($failedPackages.Count -gt 0) {
        Write-Fail "Failed to install some dependencies: $($failedPackages -join ', ')"
        Write-Info ""
        Write-Info "If you're in an air-gapped environment, you may need to"
        Write-Info "pre-download wheel files and use: pip install --no-index --find-links=<wheels_dir>"
        Exit-WithError
    }

    # Verify key packages
    $testImport = & $VenvPython -c "import flask, waitress; print('OK')" 2>&1
    if ($testImport -ne "OK") {
        Exit-WithError "Package verification failed"
    }

    Write-Success "All $totalPackages packages installed successfully"

    # ============================================================
    # STEP 8: Create Run/Stop scripts
    # ============================================================
    Write-Step 9 "Creating launcher scripts..."

    # Run_TWR.bat - with auto-restart support
    $RunScript = @"
@echo off
title TechWriterReview Server
cd /d "$AppDir"

echo.
echo  ============================================
echo   TechWriterReview Server v$Version
echo  ============================================
echo.
echo  Server URL: http://127.0.0.1:5050
echo.
echo  Keep this window open while using the tool.
echo  Press Ctrl+C or close this window to stop.
echo.
echo  Note: Server will auto-restart when updates
echo        are applied from the Settings menu.
echo.
echo  ============================================
echo.

:START
"$VenvPython" app.py
set EXIT_CODE=%errorlevel%

if %EXIT_CODE%==75 (
    echo.
    echo  [UPDATE] Server restarting after update...
    echo.
    timeout /t 2 /nobreak >nul
    goto START
)

if %EXIT_CODE%==0 (
    echo.
    echo  Server stopped normally.
) else (
    echo.
    echo  ERROR: Server exited with code %EXIT_CODE%
    echo  Check the logs folder for details.
    pause
)
"@

    $RunScriptPath = Join-Path $InstallPath "Run_TWR.bat"
    Set-Content -Path $RunScriptPath -Value $RunScript -Encoding ASCII
    Write-Success "Created $RunScriptPath"

    # Stop_TWR.bat - Robust version that kills all related processes
    $StopScript = @"
@echo off
title Stop TechWriterReview
echo.
echo  ============================================
echo   Stopping TechWriterReview
echo  ============================================
echo.

:: Method 1: Kill by window title
echo  [1] Checking for TWR server window...
taskkill /f /fi "WINDOWTITLE eq TechWriterReview*" 2>nul

:: Method 2: Kill ALL python.exe processes (most reliable for TWR)
echo  [2] Stopping Python processes...
taskkill /f /im python.exe 2>nul
if %errorlevel%==0 (
    echo      Stopped python.exe processes
) else (
    echo      No python.exe processes found
)

:: Method 3: Kill pythonw.exe (background python)
echo  [3] Checking background Python...
taskkill /f /im pythonw.exe 2>nul

:: Method 4: Kill waitress if running standalone
echo  [4] Checking waitress server...
taskkill /f /im waitress-serve.exe 2>nul

:: Wait for processes to fully release file handles
echo.
echo  Waiting for file handles to release...
timeout /t 3 /nobreak >nul

:: Verify
echo.
tasklist /fi "imagename eq python.exe" 2>nul | findstr /i python.exe >nul
if %errorlevel%==0 (
    echo  [!] Some Python processes still running.
    echo      Close any Python IDEs and run this again if needed.
) else (
    echo  [OK] All Python processes stopped.
)

echo.
timeout /t 2 /nobreak >nul
"@

    $StopScriptPath = Join-Path $InstallPath "Stop_TWR.bat"
    Set-Content -Path $StopScriptPath -Value $StopScript -Encoding ASCII
    Write-Success "Created $StopScriptPath"

    # ============================================================
    # STEP 9: Verify installation
    # ============================================================
    Write-Step 10 "Verifying installation..."

    # Test that Flask can be imported
    $verifyResult = & $VenvPython -c "import flask; print('OK')" 2>&1
    if ($verifyResult -match "OK") {
        Write-Success "Python environment working"
    }
    else {
        Write-Info "Warning: Could not verify Python environment"
        Write-Info "The application may still work - try running it"
    }

    # Check critical files exist
    $appPy = Join-Path $AppDir "app.py"
    if (Test-Path $appPy) {
        Write-Success "Application files in place"
    }
    else {
        Exit-WithError "app.py not found at $appPy"
    }

    # Verify directory structure
    $staticJs = Join-Path $AppDir "static\js\app.js"
    $staticCss = Join-Path $AppDir "static\css\style.css"
    $templates = Join-Path $AppDir "templates\index.html"

    if ((Test-Path $staticJs) -and (Test-Path $staticCss) -and (Test-Path $templates)) {
        Write-Success "Directory structure verified"
    } else {
        Write-Warn "Some directory structure issues detected"
        if (-not (Test-Path $staticJs)) { Write-Info "  Missing: static/js/app.js" }
        if (-not (Test-Path $staticCss)) { Write-Info "  Missing: static/css/style.css" }
        if (-not (Test-Path $templates)) { Write-Info "  Missing: templates/index.html" }
    }

    # ============================================================
    # STEP 10: Cleanup (optional)
    # ============================================================
    if (-not $SkipCleanup) {
        Write-Step 11 "Cleaning up installer files..."
        
        # Remove the source TechWriterReview folder (we copied it)
        if (Test-Path $SourceApp) {
            Remove-Item -Path $SourceApp -Recurse -Force -ErrorAction SilentlyContinue
            Write-Info "Removed source folder"
        }
        
        Write-Success "Cleanup complete"
        Write-Info "You can delete the extracted installer folder."
    }
    else {
        Write-Step 11 "Skipping cleanup (-SkipCleanup specified)"
    }

    # Clean up upgrade backup reminder
    if ($IsUpgrade -and $BackupDir -and (Test-Path $BackupDir)) {
        Write-Host ""
        Write-Info "Upgrade backup saved at: $BackupDir"
        Write-Info "You can delete this folder once you verify everything works."
    }

    # ============================================================
    # DONE
    # ============================================================
    if ($IsUpgrade) {
        Write-Banner "Upgrade Complete! v$ExistingVersion -> v$Version" "Green"
    } else {
        Write-Banner "Installation Complete!" "Green"
    }

    Write-Host ""
    Write-Host "  Installation Location: $InstallPath" -ForegroundColor White
    Write-Host "  Version: $Version" -ForegroundColor White
    Write-Host ""
    Write-Host "  To start TechWriterReview:" -ForegroundColor Cyan
    Write-Host "    1. Double-click: $RunScriptPath" -ForegroundColor White
    Write-Host "    2. Open browser to: http://127.0.0.1:5050" -ForegroundColor White
    Write-Host ""
    Write-Host "  To stop:" -ForegroundColor Cyan
    Write-Host "    Close the server window or run: $StopScriptPath" -ForegroundColor White
    Write-Host ""

    if ($IsUpgrade) {
        Write-Host "  IMPORTANT: Do a hard refresh (Ctrl+Shift+R) in your browser" -ForegroundColor Yellow
        Write-Host "             to load the new version's files." -ForegroundColor Yellow
        Write-Host ""
    }

    # Create desktop shortcut option
    Write-Host "  Create desktop shortcut? (y/N): " -ForegroundColor Yellow -NoNewline
    $createShortcut = Read-Host

    if ($createShortcut -eq 'y' -or $createShortcut -eq 'Y') {
        try {
            $WshShell = New-Object -ComObject WScript.Shell
            $Desktop = [Environment]::GetFolderPath("Desktop")
            $Shortcut = $WshShell.CreateShortcut("$Desktop\TechWriterReview.lnk")
            $Shortcut.TargetPath = $RunScriptPath
            $Shortcut.WorkingDirectory = $InstallPath
            $Shortcut.Description = "TechWriterReview Document Analysis Tool v$Version"
            
            # Set icon if available
            $IconPath = Join-Path $AppDir "images\twr_icon.ico"
            if (Test-Path $IconPath) {
                $Shortcut.IconLocation = "$IconPath,0"
            }
            
            $Shortcut.Save()
            Write-Success "Desktop shortcut created!"
        }
        catch {
            Write-Info "Could not create shortcut: $_"
        }
    }

    Write-Host ""
    Write-Host "  Press Enter to exit..." -ForegroundColor Gray
    Read-Host

}
catch {
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Red
    Write-Host "  UNEXPECTED ERROR" -ForegroundColor Red
    Write-Host "  ============================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Location: $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Full details:" -ForegroundColor Gray
    Write-Host "  $($_.Exception.ToString())" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Press Enter to exit..." -ForegroundColor Red
    Read-Host
    exit 1
}
