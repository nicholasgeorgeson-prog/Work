# TechWriterReview v3.0.86

Document analysis and review tool for technical writers in aerospace and government contracting.

## Quick Start

### Development Setup (With Internet)

```batch
1. Unzip this package
2. Double-click: setup.bat
3. Double-click: start_twr.bat
4. Open browser to: http://localhost:5000
```

That's it! `setup.bat` installs all dependencies automatically.

### Air-Gapped Deployment (No Internet)

If you need to install on a machine without internet:

```batch
# On a machine WITH internet:
1. Run: deployment\package_for_distribution.bat
2. Wait for downloads (~100 MB)
3. Copy dist\TWR_Distribution.zip to target machine

# On the AIR-GAPPED machine:
1. Extract TWR_Distribution.zip
2. Run: install.bat
3. Enter installation path when prompted
```

## Features

- **Document Review**: Analyze technical documents for compliance, grammar, and consistency
- **Role Extraction**: Automatically identify roles and responsibilities using pattern matching
- **Table Detection**: Extract roles from RACI matrices and responsibility tables (PDFs/DOCX)
- **RACI Matrix Generation**: Build responsibility matrices from extracted data
- **Scan History**: Track document reviews over time
- **Statement Forge**: Generate compliant requirement statements

## File Structure

```
TechWriterReview/
├── app.py                    # Main Flask application
├── core.py                   # Document processing engine
├── role_integration.py       # Role extraction integration
├── role_extractor_v3.py      # Pattern-based role extraction
├── table_processor.py        # PDF/DOCX table extraction
├── scan_history.py           # Database for tracking scans
├── setup.bat                 # Development setup script
├── static/                   # CSS, JavaScript
├── templates/                # HTML templates
├── deployment/               # Distribution packaging
│   ├── package_for_distribution.bat
│   └── install.bat
└── docs/
    ├── TWR_LESSONS_LEARNED.md
    └── TWR_SESSION_HANDOFF.md
```

## Requirements

- Python 3.12 (recommended) or 3.10+
- Windows 10/11 (for batch scripts)
- ~200 MB disk space (with all dependencies)

## Version History

See `version.json` for complete changelog.

### v3.0.86 (2026-01-27)
- Added table extraction from PDFs/DOCX
- Added automated setup.bat for development
- Added air-gapped deployment support
- Roles found in tables get confidence boost

### v3.0.85 (2026-01-26)
- Fixed role export functionality
- Created roles-export-fix.js module

### v3.0.75-84 (2026-01-26)
- Graph visualization improvements
- Orphan node fixes
- Tab layout fixes

## Support

For issues or questions, see `docs/TWR_LESSONS_LEARNED.md` for known patterns and fixes.
