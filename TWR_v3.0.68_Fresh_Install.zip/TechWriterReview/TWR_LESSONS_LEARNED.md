# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.68

---

## CRITICAL: End of Session Requirements

**At the end of EVERY development session, Claude must provide:**

1. **Complete Fresh Install ZIP** - A full `TWR_v3.0.XX_Fresh_Install.zip` containing:
   - All source files (Python backend, HTML templates, CSS, JS)
   - All fix modules that have been created
   - Updated version.json
   - Updated index.html with all script tags
   - This TWR_LESSONS_LEARNED.md file
   
2. **This ensures continuity** - The next chat session can start with a working, complete codebase rather than having to piece together multiple fixes.

---

## Session: v3.0.68 (January 26, 2026) - FINAL FIX: CSS !important Override

### THE ACTUAL ROOT CAUSE ✅

**The Problem:** Tabs showed blank white boxes despite JavaScript rendering content correctly.

**Discovery Process:**
1. v3.0.66: Added fadeIn keyframes - didn't fix it
2. v3.0.67: Tried re-applying display:block after render - didn't fix it
3. Diagnostic script revealed the truth:
   ```
   Inline style display: block     ← We set this correctly
   Computed display: none          ← But CSS overrides it!
   ```

**Root Cause:** CSS uses `!important` which **cannot be overridden by inline styles**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

**The Fix:**
```javascript
// WRONG - gets overridden by !important
targetSection.style.display = 'block';

// CORRECT - matches the CSS rule
targetSection.classList.add('active');
```

### Critical CSS Specificity Lesson

**Inline styles DO NOT override `!important` CSS rules.**

Priority order (highest to lowest):
1. `!important` CSS rules
2. Inline styles (normally highest, but NOT vs !important)
3. ID selectors
4. Class selectors
5. Element selectors

When debugging visibility issues:
1. Check computed style vs inline style
2. If they differ, look for `!important` in CSS rules
3. Match what the CSS expects (classes, not inline styles)

### Diagnostic Script That Found It

```javascript
const section = document.getElementById('roles-overview');
console.log('Inline style display:', section.style.display);
console.log('Computed display:', getComputedStyle(section).display);

const rules = [];
for (const sheet of document.styleSheets) {
    try {
        for (const rule of sheet.cssRules) {
            if (rule.selectorText?.includes('roles-section')) {
                rules.push({selector: rule.selectorText, display: rule.style.display});
            }
        }
    } catch(e) {}
}
console.log('CSS rules:', rules);
```

---

## Session: v3.0.66 (January 25, 2026) - CSS Animation Fix

Added missing `@keyframes fadeIn` - good fix but not the main visibility issue.

---

## Session: v3.0.65 (January 24, 2026) - Graph Controls Fixed

Fixed all graph control dropdowns, search, slider, and buttons.

---

## Key Development Patterns

### 1. Section Visibility
Use `classList.add('active')` not `style.display` - CSS uses `!important` rules.

### 2. Modal Visibility  
Use `modal.classList.add('active')` for pointer-events.

### 3. Control Initialization
Use `_tabsFixInitialized` flag to prevent duplicate handlers.

### 4. API Namespace
Export functions via `window.TWR.RolesTabs = {...}`.

### 5. File Locations

| File Type | Production Location |
|-----------|---------------------|
| Python backend | TechWriterReview/*.py |
| HTML templates | TechWriterReview/templates/*.html |
| CSS | TechWriterReview/static/css/*.css |
| JavaScript | TechWriterReview/static/js/*.js |
| Fix modules | TechWriterReview/static/js/*-fix.js |

---

## Fix Modules Added Since v3.0.52

| Module | Version | Purpose |
|--------|---------|---------|
| button-fixes.js | v3.0.52 | Missing button handlers |
| run-state-fixes.js | v3.0.53 | Run state updates |
| history-fixes.js | v3.0.54b | Scan history rendering |
| update-functions.js | v3.0.52 | Update system helpers |
| roles-dictionary-fix.js | v3.0.52 | Dictionary tab functionality |
| roles-tabs-fix.js | v3.0.68 | Tab switching with .active class |
