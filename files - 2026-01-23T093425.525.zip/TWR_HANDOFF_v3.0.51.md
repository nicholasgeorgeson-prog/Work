# TechWriterReview - Complete Handoff Document

**Version:** 3.0.51  
**Date:** 2026-01-23  
**Owner:** Nick (SAIC Systems Engineer, Stevens Institute MS candidate)

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Current Status](#current-status)
3. [Installation Methods](#installation-methods)
4. [Directory Structure](#directory-structure)
5. [Lessons Learned - What NOT To Do](#lessons-learned---what-not-to-do)
6. [Lessons Learned - What Works](#lessons-learned---what-works)
7. [Known Issues & Fixes Applied](#known-issues--fixes-applied)
8. [Update System](#update-system)
9. [Development Workflow](#development-workflow)
10. [Testing](#testing)
11. [Remaining Work](#remaining-work)
12. [Quick Reference](#quick-reference)

---

## Project Overview

### What Is TechWriterReview?

TechWriterReview (TWR) is a Flask-based document analysis application designed for **air-gapped Windows corporate environments**. It analyzes technical documents (DOCX, PDF) against enterprise writing standards.

### Core Features

- **Document Analysis**: Grammar, spelling, acronyms, passive voice, sentence length
- **Role Extraction**: Identifies organizational roles from documents
- **Statement Forge**: Extracts requirements/procedures for TIBCO Nimbus
- **Export Options**: Word (tracked changes), CSV, JSON, XLSX
- **Visualizations**: D3.js role relationship graphs, analytics dashboards
- **Hyperlink Validation**: PowerShell-based URL checking with comment insertion
- **Built-in Update System**: Apply patches without full reinstall

### Target Environment Constraints

| Constraint | Requirement |
|------------|-------------|
| Network | Air-gapped (no internet during normal operation) |
| OS | Windows 10/11, Windows Server 2016+ |
| Python | 3.8+ |
| Browser | Chrome, Edge, Firefox |
| External APIs | NONE - all processing is local |
| PowerShell | 5.1+ (comes with Windows 10/11) |

---

## Current Status

### Version: 3.0.51

| Component | Status | Notes |
|-----------|--------|-------|
| Core Analysis Engine | ✅ Complete | All checkers working |
| Statement Forge | ✅ Complete | Session extraction working |
| Role Extraction | ✅ Complete | D3 visualization working |
| Export Module | ✅ Complete | XLSX, CSV, JSON, DOCX |
| Hyperlink Validator | ✅ Complete | PowerShell script + config API |
| Update Manager | ✅ Complete | Auto-restart + browser refresh (v3.0.51) |
| Job Manager | ⚠️ Partial | Infrastructure exists, not wired to review |
| Tests | ✅ 109 tests | All implemented batches tested |

### Completed Batches

- **Batch G**: Hyperlink Comments in Document ✅
- **Batch H**: Statement Forge → Role Responsibilities ✅
- **Batch I**: Job-based Review with Progress ✅
- **Batch K**: Update System UX Improvements ✅ (v3.0.51)

### Remaining Work

- **Batch J**: Enterprise Logging Bundle (LOW PRIORITY)
  - Enhanced redaction patterns
  - Timing metrics in diagnostic export

---

## Installation Methods

### Method 1: Fresh Install via GitHub (RECOMMENDED)

Since GitHub is now available for file transfer, use the clean package:

**Package:** `TechWriterReview_v3.0.50.zip` (825KB)

**Steps:**
1. Download from GitHub repository
2. Extract to any folder (e.g., `C:\TWR_Install`)
3. Right-click `INSTALL.ps1` → "Run with PowerShell"
4. Follow prompts (default install: `C:\TWR`)
5. Double-click `Run_TWR.bat` to start
6. Open `http://127.0.0.1:5050` in browser

**Post-Install Structure:**
```
C:\TWR\
├── Run_TWR.bat      # Start server (double-click)
├── Stop_TWR.bat     # Stop server
├── .venv\           # Python virtual environment
├── app\             # Application files
│   ├── app.py
│   ├── core.py
│   ├── config.json
│   ├── static\
│   │   ├── css\
│   │   └── js\
│   │       ├── app.js
│   │       ├── features\
│   │       │   ├── roles.js
│   │       │   ├── families.js
│   │       │   └── triage.js
│   │       └── vendor\
│   ├── templates\
│   ├── statement_forge\
│   └── tools\
├── updates\         # Drop update files here
├── backups\         # Auto-created before updates
└── logs\
```

### Method 2: Update Existing Installation

For applying fixes to an existing installation:

**Package:** `TWR_UPDATE_v3.0.50_patch2.zip` (28KB)

**Steps:**
1. Extract contents to `C:\TWR\updates\` (keep folder structure!)
2. Open TechWriterReview → Settings → Updates tab
3. Click "Check for Updates" 
4. Click "Apply Updates"
5. Restart server (close and reopen Run_TWR.bat)
6. Hard refresh browser (Ctrl+Shift+R)

---

## Directory Structure

### Package Structure (Clean - v3.0.51)

```
TechWriterReview_v3.0.51.zip
├── INSTALL.ps1                  # PowerShell installer (with progress bar)
├── README.md                    # Quick start guide
├── backups/                     # Empty - for update backups
├── updates/                     # Empty - drop update files here
├── logs/                        # Empty - for log files
└── TechWriterReview/            # Application source
    ├── app.py                   # Main Flask application
    ├── core.py                  # Document analysis engine
    ├── config.json              # User configuration
    ├── version.json             # Version info
    ├── requirements.txt         # Python dependencies
    ├── tests.py                 # Unit tests
    ├── update_manager.py        # Update system backend (with restart)
    ├── statement_forge/         # Statement Forge package
    │   ├── __init__.py          # Package init
    │   ├── extractor.py
    │   ├── routes.py
    │   ├── models.py
    │   └── export.py
    ├── static/
    │   ├── css/style.css
    │   └── js/
    │       ├── app.js           # Main frontend
    │       ├── features/        # Feature modules
    │       │   ├── roles.js
    │       │   ├── families.js
    │       │   └── triage.js
    │       ├── ui/              # UI modules
    │       ├── api/             # API client
    │       └── vendor/          # D3, Chart.js, Lucide
    ├── templates/
    │   └── index.html
    ├── images/                  # v3.0.51: Application images
    │   └── twr_icon.ico         # Desktop shortcut icon
    └── tools/
        └── HyperlinkValidator.ps1
```

### Key Differences from Old Package Format

| Old (.txt encoding) | New (Native) |
|---------------------|--------------|
| `__PATH__app__app.py__EXT__.py.txt` | `app.py` |
| `__PATH__statement_forge___INIT____EXT__.py.txt` | `statement_forge/__init__.py` |
| Flat structure with encoded names | Normal directory tree |
| Required complex PowerShell to decode | Simple copy operation |

---

## Lessons Learned - What NOT To Do

### ❌ NEVER: Use `pip upgrade pip` on Air-Gapped Networks

**Problem:** Installer would hang indefinitely trying to upgrade pip on networks without internet access.

**Solution:** Skip pip upgrade entirely. The bundled pip version works fine.

```batch
:: OLD (BROKEN)
"%VENV_PIP%" install --upgrade pip

:: NEW (WORKS)
echo Skipping pip upgrade (using bundled version)
```

### ❌ NEVER: Use .txt Extension Encoding with Double Underscores

**Problem:** The `__PATH__` and `__EXT__` markers conflicted with Python's `__init__.py`:
- `statement_forge___INIT__` parsed incorrectly
- Resulted in `statement_forge\_INIT_\` instead of `statement_forge\__init__.py`

**Solution:** Use native file extensions. Since GitHub is available, no .txt encoding needed.

### ❌ NEVER: Transfer Files via Corporate Outlook Email

**Problem:** Corporate Outlook security policies strip/corrupt attachment content regardless of:
- File extension changes (.zip → .zi_, etc.)
- Password protection
- Base64 encoding inside .txt files

Files arrived as 128-byte placeholders with no actual content.

**Solution:** Use GitHub for file transfer. It works reliably.

### ❌ NEVER: Trust OneDrive "Files On-Demand"

**Problem:** OneDrive creates placeholder files that:
- Show correct file sizes in Explorer
- Appear to have content
- Are actually empty (just cloud references)
- Only download when opened

**Solution:** Before using files from OneDrive:
1. Right-click → "Always keep on this device"
2. Or copy to a non-OneDrive folder first
3. Verify actual file size with `dir` command

### ❌ NEVER: Use `-LiteralPath` in PowerShell 5.1

**Problem:** PowerShell 5.1 (Windows 10 default) doesn't support `-LiteralPath` parameter on many cmdlets.

**Solution:** Use string concatenation instead:
```powershell
# OLD (FAILS on PS 5.1)
$path = Join-Path -LiteralPath $baseDir -ChildPath $file

# NEW (WORKS on PS 5.1+)
$path = "$baseDir\$file"
```

### ❌ NEVER: Use WMIC Commands

**Problem:** WMIC is deprecated in Windows 11 and may not be available.

**Solution:** Use PowerShell equivalents for all system queries.

### ❌ NEVER: Export Undefined Functions in JavaScript

**Problem:** The roles.js file had this at line 1884:
```javascript
showNodeInfoPanel: showNodeInfoPanel  // Function was NEVER defined!
```
This caused "ReferenceError: showNodeInfoPanel is not defined".

**Solution:** Only export functions that actually exist. Remove undefined exports.

### ❌ NEVER: Assume SHA-256 Hashes Will Match Cross-Platform

**Problem:** Files created on Mac have different line endings than Windows. SHA-256 hashes computed on Mac won't match the same file on Windows after line ending conversion.

**Solution:** Skip hash verification for cross-platform transfers. ZIP's built-in CRC provides sufficient integrity checking.

---

## Lessons Learned - What Works

### ✅ DO: Use GitHub for File Transfer

GitHub preserves file integrity perfectly. No encoding, no corruption, no security stripping.

### ✅ DO: Use Native File Extensions in Update Packages

As of v3.0.50, the update manager supports:
- Native extensions: `.py`, `.js`, `.css`, `.html`, `.json`
- Legacy `.txt` wrapped files (backward compatible)

Future updates can just copy files with their real names.

### ✅ DO: Use PowerShell for Installation (Not Batch)

PowerShell provides:
- Better error handling
- Proper object-based file operations
- Consistent behavior across Windows versions
- UTF-8 support without BOM issues

### ✅ DO: Use `--trusted-host` Flags for pip

Even on networks with internet, corporate proxies may cause SSL issues:
```batch
pip install -r requirements.txt --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org --timeout 60
```

### ✅ DO: Create Virtual Environments

Always isolate TWR's dependencies:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### ✅ DO: Use the Built-in Update System

For fixes and patches, use the update manager instead of full reinstalls:
1. Create small update packages (just changed files)
2. Drop in `C:\TWR\updates\`
3. Apply via Settings → Updates
4. Automatic backup before apply
5. Rollback available if needed

### ✅ DO: Test JavaScript Changes in Browser Console

Before packaging, test JS changes:
```javascript
// In browser console, check for syntax errors:
try { eval(yourCode); console.log('OK'); } catch(e) { console.error(e); }
```

### ✅ DO: Show Progress During Installation (v3.0.51)

The installer now shows real-time progress during pip install:
```
[5] Installing Python dependencies...
    Installing 8 packages...

    [========] 100% - Installing PyPDF2...

    [OK] All 8 packages installed successfully
```

This prevents users from thinking the installer has hung on air-gapped networks.

### ✅ DO: Use Custom Icons for Shortcuts (v3.0.51)

Desktop shortcuts now use a custom icon (`images/twr_icon.ico`) instead of the generic Windows script icon. This improves professionalism and makes the shortcut easier to identify.

---

## Known Issues & Fixes Applied

### Issue: "Check for Updates" Always Shows No Updates (v3.0.51 FIX)
- **Location:** `static/js/app.js` line 6296
- **Cause:** Frontend checked for `data.updates_available` but backend returns `data.has_updates` and `data.updates`
- **Fix:** Changed frontend to check correct property names
- **Related:** Added auto-restart capability with `/api/updates/restart` and `/api/updates/health` endpoints

### Issue: "showNodeInfoPanel is not defined"
- **Location:** `static/js/features/roles.js` line 1884
- **Cause:** Undefined function exported in TWR.Roles module
- **Fix:** Removed undefined export (applied in v3.0.50)

### Issue: Installer Hangs on "Update pip"
- **Location:** INSTALLER.bat/INSTALL.ps1
- **Cause:** Air-gapped networks can't reach PyPI for pip upgrade
- **Fix:** Skip pip upgrade entirely

### Issue: PowerShell Script Fails with "Parameter not found"
- **Location:** twr_reconstruct.ps1
- **Cause:** Using PowerShell 7 features in PS 5.1 environment
- **Fix:** Use only PS 5.1 compatible syntax

### Issue: statement_forge Module Not Found
- **Location:** Various Python imports
- **Cause:** `__init__.py` wasn't created due to encoding bug
- **Fix:** Use normal directory structure with actual `__init__.py`

### Issue: JavaScript Corruption After Install
- **Location:** Multiple .js files
- **Cause:** .txt encoding scheme mishandled special characters
- **Fix:** Use native file extensions, no .txt encoding

---

## Update System

### How It Works (v3.0.51 - Auto-Restart)

The `update_manager.py` module provides:
- File monitoring in `C:\TWR\updates\` folder
- Automatic backup before applying changes
- File routing based on path structure
- Rollback capability
- **Auto-restart**: Server restarts automatically after updates
- **Browser refresh**: Page reloads when server is back online
- API endpoints for UI integration

### User Experience (v3.0.51)

1. User clicks **"Check for Updates"** → Shows count of available updates
2. User clicks **"Apply Updates"**
3. System automatically:
   - Copies update files
   - Creates backup
   - Triggers server restart (exit code 75)
   - `Run_TWR.bat` detects code 75 and restarts Python
   - Browser polls `/api/updates/health` until server responds
   - Page hard-refreshes automatically

**No manual steps required** - user just waits a few seconds.

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/updates/status` | GET | Get current update status |
| `/api/updates/check` | GET | Scan for new update files |
| `/api/updates/apply` | POST | Apply pending updates |
| `/api/updates/rollback` | POST | Revert to previous backup |
| `/api/updates/restart` | POST | Trigger server restart (v3.0.51) |
| `/api/updates/health` | GET | Health check for restart polling (v3.0.51) |

### Auto-Restart Flow (Technical)

```
Browser                    Python Server              Run_TWR.bat
   |                            |                          |
   |-- POST /apply ------------>|                          |
   |<-- {success: true} --------|                          |
   |                            |                          |
   |-- POST /restart ---------->|                          |
   |<-- {success: true} --------|                          |
   |                            |-- os._exit(75) --------->|
   |                            X                          |
   |                                                       |-- sees code 75
   |                                                       |-- goto :START
   |                            |<-- restarts python ------|
   |-- GET /health ------------>|                          |
   |<-- {status: ok} -----------|                          |
   |                            |                          |
   |-- location.reload() ----->REFRESH                     |
```

### Creating Update Packages

**For v3.0.50+** (native extensions):
```
TWR_UPDATE_v3.0.XX_patchN/
├── static/js/features/roles.js      # Native extension!
├── app.py                            # Just the file, correct path
└── README.txt                        # Instructions
```

**For older versions** (legacy .txt):
```
TWR_UPDATE_v3.0.XX_patchN/
├── static/js/features/roles.js.txt  # Add .txt extension
├── app.py.txt
└── README.txt
```

### File Routing Logic

The update manager routes files based on their path:
```
static/js/features/roles.js → C:\TWR\app\static\js\features\roles.js
static/css/style.css → C:\TWR\app\static\css\style.css
app.py → C:\TWR\app\app.py
statement_forge/extractor.py → C:\TWR\app\statement_forge\extractor.py
```

---

## Development Workflow

### Session Continuity Pattern

When starting a new Claude session:

1. **Read project instructions** (TWR_PROJECT_INSTRUCTIONS.md)
2. **Read this handoff document**
3. **Check current version** in `version.json`
4. **Run tests** to verify baseline: `python -m unittest tests -q`

### Making Changes

1. Make code changes
2. Run tests: `python -m unittest tests -q`
3. Test manually in browser
4. Update CHANGELOG.md
5. Bump version in version.json
6. Create release package
7. Update handoff document if needed

### Creating Release Packages

```bash
# Full install package
zip -r TechWriterReview_v3.0.XX.zip INSTALL.ps1 README.md TechWriterReview/

# Update package (just changed files)
mkdir -p update_package/static/js/features
cp TechWriterReview/static/js/features/roles.js update_package/static/js/features/
zip -r TWR_UPDATE_v3.0.XX_patchN.zip update_package/
```

---

## Testing

### Running Tests

```bash
# All tests
python -m unittest tests -q

# Specific test class
python -m unittest tests.TestHyperlinkHealth -v

# Specific test method
python -m unittest tests.TestHyperlinkHealth.test_ps1_validator_script_exists -v
```

### Current Test Count: 103 tests

Tests cover:
- API endpoints
- Document analysis
- Export functionality
- Statement Forge
- Role extraction
- Hyperlink validation
- Update manager
- Configuration handling

### Browser Testing Checklist

After any JavaScript changes:
- [ ] Main review flow works
- [ ] Roles tab loads without console errors
- [ ] Statement Forge extraction works
- [ ] Export buttons function
- [ ] Settings save correctly
- [ ] Update check/apply works

---

## Remaining Work

### Batch J: Enterprise Logging Bundle (LOW PRIORITY)

**Scope:** Enhanced diagnostics and logging

**Files to modify:**
- `config_logging.py` - Add more redaction patterns
- `diagnostic_export.py` - Add timing metrics

**Not blocking deployment** - Current logging is functional.

---

## Quick Reference

### Start the Application

```batch
C:\TWR\Run_TWR.bat
:: Then open http://127.0.0.1:5050
```

### Stop the Application

```batch
C:\TWR\Stop_TWR.bat
```

### Apply an Update (v3.0.51 - Automatic)

1. Extract update to `C:\TWR\updates\`
2. Open app → Settings → Updates
3. Click "Check for Updates" → Click "Apply Updates"
4. **Wait** - server restarts and browser refreshes automatically

### Run Tests

```bash
cd C:\TWR\app
..\.venv\Scripts\python -m unittest tests -q
```

### Key Files

| File | Purpose |
|------|---------|
| `app.py` | Main Flask application (~3500 lines) |
| `core.py` | Document extraction engine |
| `static/js/app.js` | Main frontend (~9300 lines) |
| `static/js/features/roles.js` | Role visualization |
| `update_manager.py` | Update system backend (with restart endpoints) |
| `config.json` | User settings |
| `version.json` | Version info |
| `images/twr_icon.ico` | Desktop shortcut icon (v3.0.51) |

### Default Ports

| Service | Port |
|---------|------|
| TWR Web UI | 5050 |
| (Change in Run_TWR.bat if needed) |

---

## Contact & Resources

- **Project Folder:** Claude Projects → TechWriterReview
- **Latest Package:** `TechWriterReview_v3.0.51.zip`
- **Previous Package:** `TechWriterReview_v3.0.50.zip`

---

## Changelog

### v3.0.51 (2026-01-23)

**Bug Fixes:**
- Fixed "Check for Updates" always showing "No updates available" even when files present
  - Frontend was checking `data.updates_available` but backend returns `data.has_updates`
- Removed outdated ".txt" file requirement from Settings → Updates UI text
  - Update system now supports native extensions (.py, .js, .css, etc.)

**New Features:**
- **Auto-restart on update**: Server automatically restarts after applying updates
  - New `/api/updates/restart` endpoint triggers server exit with code 75
  - New `/api/updates/health` endpoint for restart polling
  - `Run_TWR.bat` now loops and restarts on exit code 75
  - Browser polls health endpoint and auto-refreshes when server is back
- **Installation progress bar**: Shows real-time package installation progress
- **Desktop shortcut icon**: Custom blue document icon (`images/twr_icon.ico`)

**Files Changed:**
- `static/js/app.js` - Fixed property names, added `pollForServerRestart()`
- `update_manager.py` - Added restart and health endpoints
- `INSTALL.ps1` - Added progress bar, icon support, restart loop in Run_TWR.bat
- `templates/index.html` - Removed .txt references, updated auto-restart text
- `images/twr_icon.ico` - New file

### v3.0.50 (2026-01-22)

- Fixed "showNodeInfoPanel is not defined" error
- Added native file extension support in update manager
- Complete package restructure for GitHub distribution

---

*Last updated: 2026-01-23 by Claude*
