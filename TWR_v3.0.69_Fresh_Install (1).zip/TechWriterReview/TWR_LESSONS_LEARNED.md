# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.69

---

## CRITICAL: End of Session Requirements

**At the end of EVERY development session, Claude must provide:**

1. **Complete Fresh Install ZIP** - A full `TWR_v3.0.XX_Fresh_Install.zip` containing:
   - All source files (Python backend, HTML templates, CSS, JS)
   - All fix modules that have been created
   - Updated version.json
   - Updated index.html with all script tags
   - This TWR_LESSONS_LEARNED.md file
   
2. **This ensures continuity** - The next chat session can start with a working, complete codebase rather than having to piece together multiple fixes.

---

## CRITICAL: Version Increment Checklist

**For EVERY version increment, update ALL of these files:**

| File | What to Update |
|------|----------------|
| `version.json` | version, release_date, core_version, add changelog entry |
| `help-docs.js` | Line 5 comment, line 17 version, line 18 lastUpdated, About section (version + build date), Version History section (add new entry), console.log at end |
| `TWR_LESSONS_LEARNED.md` | Version header, add session notes |
| `INSTALL.ps1` | Line 30 `$Version` variable |
| Any fix module headers | Update version in file comment header |

**help-docs.js locations to update:**
1. Line ~5: Comment header version
2. Line ~17: `version: 'X.X.XX'`
3. Line ~18: `lastUpdated: 'YYYY-MM-DD'`
4. Version History section: Add new `<div class="changelog-version changelog-current">` entry
5. About section: Version display and Build Date
6. Last line: `console.log('[HelpDocs] Module loaded vX.X.XX')`

**Failure to update help-docs.js causes version history gaps visible to users!**

---

## CRITICAL: Patch ZIP Structure

**Patches must mirror the app directory structure, NOT be flat files.**

**WRONG (flat structure):**
```
TWR_v3.0.69_Patch.zip
├── scan_history.py       ← User must manually place
├── roles-tabs-fix.js     ← User must manually place
├── help-docs.js          ← User must manually place
└── version.json          ← User must manually place
```

**CORRECT (mirrored structure):**
```
TWR_v3.0.69_Patch.zip
├── UPDATE.ps1            ← Automated installer script
└── TechWriterReview/
    ├── scan_history.py
    ├── version.json
    └── static/
        └── js/
            ├── roles-tabs-fix.js
            └── help-docs.js
```

**To create a proper patch:**
```bash
# Create structure mirroring app layout
mkdir -p patch/TechWriterReview/static/js

# Copy files to correct locations
cp scan_history.py patch/TechWriterReview/
cp version.json patch/TechWriterReview/
cp roles-tabs-fix.js patch/TechWriterReview/static/js/
cp help-docs.js patch/TechWriterReview/static/js/

# Include UPDATE.ps1 at root
cp UPDATE.ps1 patch/

# Create ZIP
cd patch && zip -r ../TWR_vX.X.XX_Patch.zip .
```

**UPDATE.ps1 applies patches to:** `$InstallPath/app/` (e.g., `C:\TWR\app\`)

---

## Smart Installer: INSTALL.ps1 v3.0.69

The installer now handles both fresh installs AND upgrades automatically.

### Upgrade Detection

When run, the installer:
1. Checks if `$InstallPath/app/` exists
2. Reads `version.json` to get current version
3. If found, prompts for upgrade confirmation

### User Data Preserved During Upgrades

| File/Folder | Purpose |
|-------------|---------|
| `scan_history.db` | All scan history and role extractions |
| `role_dictionary_master.json` | Custom role dictionary |
| `config.json` | User settings |
| `backups/` | User backups folder |
| `data/` | User data folder |
| `*.db` | Any other database files |

### Upgrade Process

1. **Backup** - Copies user data to `$InstallPath/upgrade_backup_YYYYMMDD-HHMMSS/`
2. **Remove** - Deletes old `app/` folder and `.venv/`
3. **Install** - Fresh copy from ZIP
4. **Restore** - Copies user data back to new installation
5. **Verify** - Checks critical files and directory structure

### Parameters

| Parameter | Purpose |
|-----------|---------|
| `-InstallPath "D:\TWR"` | Custom install location |
| `-ForceClean` | Delete all user data (no backup) |
| `-SkipCleanup` | Keep installer files after install |

---

## Session: v3.0.69 (January 26, 2026) - Responsibility Count Display Fix

### THE PROBLEM

**Overview tab "Top Roles by Responsibility Count" section was displaying incorrect data:**
1. Document tag showed total scan count (11) instead of unique document count
2. Right-side number showed `total_mentions` instead of actual responsibility count
3. Sorting was based on mentions, not responsibilities

### THE FIX

**Backend (scan_history.py):**
- Modified `get_all_roles()` to return two new fields:
  - `unique_document_count`: Count of deduplicated documents
  - `responsibility_count`: Sum of responsibilities from `responsibilities_json` across all document_roles
- Used `GROUP_CONCAT(DISTINCT d.filename)` for proper deduplication
- Parse and count JSON responsibilities from concatenated `responsibilities_json` data

**Frontend (roles-tabs-fix.js):**
- Updated tag to show: `${uniqueDocCount} unique doc${uniqueDocCount !== 1 ? 's' : ''}`
- Updated right-side to show: `${respCount}` with tooltip
- Changed sorting: primary by `responsibility_count`, secondary by `unique_document_count`
- Updated summary cards to sum `responsibility_count` instead of `total_mentions`

### Key Insight

The database stores responsibilities as JSON in `document_roles.responsibilities_json`. Each entry is an array of responsibility objects. To get total responsibility count per role, we must:
1. Concatenate all `responsibilities_json` entries for that role across documents
2. Parse each JSON chunk
3. Sum the array lengths

---

## Session: v3.0.68 (January 26, 2026) - FINAL FIX: CSS !important Override

### THE ACTUAL ROOT CAUSE ✅

**The Problem:** Tabs showed blank white boxes despite JavaScript rendering content correctly.

**Discovery Process:**
1. v3.0.66: Added fadeIn keyframes - didn't fix it
2. v3.0.67: Tried re-applying display:block after render - didn't fix it
3. Diagnostic script revealed the truth:
   ```
   Inline style display: block     ← We set this correctly
   Computed display: none          ← But CSS overrides it!
   ```

**Root Cause:** CSS uses `!important` which **cannot be overridden by inline styles**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

**The Fix:**
```javascript
// WRONG - gets overridden by !important
targetSection.style.display = 'block';

// CORRECT - matches the CSS rule
targetSection.classList.add('active');
```

### Critical CSS Specificity Lesson

**Inline styles DO NOT override `!important` CSS rules.**

Priority order (highest to lowest):
1. `!important` CSS rules
2. Inline styles (normally highest, but NOT vs !important)
3. ID selectors
4. Class selectors
5. Element selectors

When debugging visibility issues:
1. Check computed style vs inline style
2. If they differ, look for `!important` in CSS rules
3. Match what the CSS expects (classes, not inline styles)

### Diagnostic Script That Found It

```javascript
const section = document.getElementById('roles-overview');
console.log('Inline style display:', section.style.display);
console.log('Computed display:', getComputedStyle(section).display);

const rules = [];
for (const sheet of document.styleSheets) {
    try {
        for (const rule of sheet.cssRules) {
            if (rule.selectorText?.includes('roles-section')) {
                rules.push({selector: rule.selectorText, display: rule.style.display});
            }
        }
    } catch(e) {}
}
console.log('CSS rules:', rules);
```

---

## Session: v3.0.66 (January 25, 2026) - CSS Animation Fix

Added missing `@keyframes fadeIn` - good fix but not the main visibility issue.

---

## Session: v3.0.65 (January 24, 2026) - Graph Controls Fixed

Fixed all graph control dropdowns, search, slider, and buttons.

---

## Key Development Patterns

### 1. Section Visibility
Use `classList.add('active')` not `style.display` - CSS uses `!important` rules.

### 2. Modal Visibility  
Use `modal.classList.add('active')` for pointer-events.

### 3. Control Initialization
Use `_tabsFixInitialized` flag to prevent duplicate handlers.

### 4. API Namespace
Export functions via `window.TWR.RolesTabs = {...}`.

### 5. File Locations

| File Type | Production Location |
|-----------|---------------------|
| Python backend | TechWriterReview/*.py |
| HTML templates | TechWriterReview/templates/*.html |
| CSS | TechWriterReview/static/css/*.css |
| JavaScript | TechWriterReview/static/js/*.js |
| Fix modules | TechWriterReview/static/js/*-fix.js |

---

## Fix Modules Added Since v3.0.52

| Module | Version | Purpose |
|--------|---------|---------|
| button-fixes.js | v3.0.52 | Missing button handlers |
| run-state-fixes.js | v3.0.53 | Run state updates |
| history-fixes.js | v3.0.54b | Scan history rendering |
| update-functions.js | v3.0.52 | Update system helpers |
| roles-dictionary-fix.js | v3.0.52 | Dictionary tab functionality |
| roles-tabs-fix.js | v3.0.69 | Tab switching + responsibility count display |
