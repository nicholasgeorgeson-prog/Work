#!/usr/bin/env python3
"""
Role Extraction Integration Layer v1.0.0
=========================================
Integrates role extraction into TechWriterReview v2.4.0

This is a STANDALONE module that:
1. Does NOT modify any existing TechWriterReview code
2. Can be called from core.py or app.py with minimal additions
3. Handles all errors gracefully (never breaks existing functionality)
4. Returns data in a format compatible with existing review results

Usage:
    from role_integration import RoleIntegration
    role_module = RoleIntegration()
    
    # In review_document or after document extraction:
    role_result = role_module.extract_roles(filepath, extractor.full_text, extractor.paragraphs)

Author: Nicholas Georgeson
"""

import os
import json
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

__version__ = "2.5.0"
MODULE_VERSION = __version__

# Structured logging support
try:
    from config_logging import get_logger
    _logger = get_logger('role_integration')
except ImportError:
    _logger = None

def _log(message: str, level: str = 'info', **kwargs):
    """Internal logging helper with fallback to print."""
    if _logger:
        getattr(_logger, level)(message, **kwargs)
    elif level in ('warning', 'error', 'critical'):
        print(f"[RoleIntegration] {level.upper()}: {message}")


@dataclass
class RoleIssue:
    """Review issue for role-related findings (compatible with ReviewIssue format)."""
    category: str
    severity: str
    message: str
    paragraph_index: int = 0
    paragraph_text: str = ""
    flagged_text: str = ""
    suggestion: str = ""
    start_offset: int = 0
    end_offset: int = 0
    
    def to_dict(self) -> dict:
        return asdict(self)


class RoleIntegration:
    """
    Wrapper class that integrates role extraction with TechWriterReview.
    
    Features:
    - Extract roles from document text
    - Store in shared database (optional)
    - Check for duplicate/similar roles
    - Generate role-related review issues
    - Export for external visualization tools
    """
    
    def __init__(self, database_path: Optional[str] = None, enabled: bool = True):
        """
        Initialize the role integration module.
        
        Args:
            database_path: Optional path to shared role database JSON file
            enabled: Whether role extraction is enabled (can be toggled)
        """
        self.enabled = enabled
        self.database_path = database_path
        self._extractor = None
        self._database = None
        self._consolidation = None
        self._load_modules()
    
    def _load_modules(self):
        """Lazy load role extraction modules (doesn't fail if not present)."""
        if not self.enabled:
            return
        
        # Try to import role extraction modules
        try:
            from role_extractor_v3 import RoleExtractor
            self._extractor = RoleExtractor()
            _log("Loaded RoleExtractor v3")
        except ImportError as e:
            _log(f"RoleExtractor not available: {e}", level='debug')
            self._extractor = None
        
        # Try to import database (optional)
        if self.database_path:
            try:
                from role_management_studio_v3 import RoleDatabase, StudioSettings
                settings = StudioSettings()
                settings.database_path = self.database_path
                self._database = RoleDatabase(settings)
                _log(f"Loaded RoleDatabase: {self.database_path}")
            except ImportError as e:
                _log(f"RoleDatabase not available: {e}", level='debug')
                self._database = None
        
        # Try to import consolidation engine (optional)
        try:
            from role_consolidation_engine import check_role_similarity
            self._consolidation = check_role_similarity
            _log("Loaded consolidation engine")
        except ImportError as e:
            _log(f"Consolidation engine not available: {e}", level='debug')
            self._consolidation = None
    
    def is_available(self) -> bool:
        """Check if role extraction is available."""
        return self.enabled and self._extractor is not None
    
    def extract_roles(self, 
                      filepath: str,
                      full_text: str,
                      paragraphs: List[Tuple[int, str]],
                      store_in_database: bool = True) -> Dict[str, Any]:
        """
        Extract roles from document text.
        
        Args:
            filepath: Path to the source document
            full_text: Full document text
            paragraphs: List of (index, text) tuples
            store_in_database: Whether to store results in database
        
        Returns:
            Dictionary with role extraction results:
            {
                'success': bool,
                'roles_found': int,
                'roles': {...},  # Role name -> ExtractedRole data (all entities)
                'entities': {    # v3.0.12: Separated by kind
                    'roles': [...],        # kind === 'role' only
                    'deliverables': [...]  # kind === 'deliverable' only
                },
                'issues': [...],  # Role-related review issues
                'duplicates_detected': int,
                'error': str or None
            }
        """
        result = {
            'success': False,
            'roles_found': 0,
            'roles': {},
            'entities': {  # v3.0.12: Separated entity lists
                'roles': [],
                'deliverables': [],
                'unknown': []  # v3.0.12b: Unknowns separate for review
            },
            'issues': [],
            'duplicates_detected': 0,
            'error': None
        }
        
        if not self.is_available():
            result['error'] = "Role extraction module not available"
            return result
        
        try:
            # Extract roles using the core extractor
            extracted = self._extractor.extract_from_text(full_text, filepath)
            
            result['success'] = True
            result['roles_found'] = len(extracted)
            
            # Convert to serializable format
            for role_name, role_data in extracted.items():
                # Get sample context sentences (up to 3)
                sample_contexts = []
                if hasattr(role_data, 'occurrences') and role_data.occurrences:
                    seen_contexts = set()
                    for occ in role_data.occurrences[:10]:  # Check first 10 occurrences
                        if hasattr(occ, 'context') and occ.context:
                            ctx = occ.context.strip()
                            # Truncate long contexts
                            if len(ctx) > 150:
                                ctx = ctx[:147] + '...'
                            # Avoid duplicates
                            ctx_key = ctx[:50].lower()
                            if ctx_key not in seen_contexts:
                                seen_contexts.add(ctx_key)
                                sample_contexts.append(ctx)
                                if len(sample_contexts) >= 3:
                                    break
                
                # v3.0.12: Include entity classification
                entity_kind = 'unknown'
                kind_confidence = 0.0
                kind_reason = ''
                if hasattr(role_data, 'entity_kind'):
                    entity_kind = role_data.entity_kind.value if hasattr(role_data.entity_kind, 'value') else str(role_data.entity_kind)
                    kind_confidence = getattr(role_data, 'kind_confidence', 0.0)
                    kind_reason = getattr(role_data, 'kind_reason', '')
                
                serialized_entry = {
                    'canonical_name': role_data.canonical_name,
                    'entity_kind': entity_kind,  # v3.0.12: Added
                    'kind_confidence': kind_confidence,  # v3.0.12: Added
                    'kind_reason': kind_reason,  # v3.0.12: Added
                    'frequency': role_data.frequency,
                    'confidence': role_data.avg_confidence,
                    'responsibilities': list(role_data.responsibilities),
                    'action_types': dict(role_data.action_types),
                    'variants': list(role_data.variants),
                    'occurrence_count': len(role_data.occurrences),
                    'sample_contexts': sample_contexts
                }
                
                # Store in main roles dict (backward compat)
                result['roles'][role_name] = serialized_entry
                
                # v3.0.12: Also add to separated entity lists
                # v3.0.12b: unknowns excluded from roles export per guidance
                if entity_kind == 'role':
                    result['entities']['roles'].append(serialized_entry)
                elif entity_kind == 'deliverable':
                    result['entities']['deliverables'].append(serialized_entry)
                else:
                    # Unknown goes to separate list for manual review
                    serialized_entry['needs_review'] = True
                    result['entities']['unknown'].append(serialized_entry)
            
            # Generate review issues for role-related findings
            result['issues'] = self._generate_role_issues(extracted, paragraphs)
            
            # Check for duplicate roles if consolidation is available
            if self._consolidation and len(extracted) > 1:
                duplicates = self._check_for_duplicates(list(extracted.keys()))
                result['duplicates_detected'] = len(duplicates)
                
                # Add duplicate issues
                for dup in duplicates:
                    result['issues'].append(RoleIssue(
                        category='Roles',
                        severity='Low',
                        message=f"Potential duplicate roles: '{dup['role1']}' and '{dup['role2']}' ({dup['similarity']:.0%} similar)",
                        suggestion=f"Consider standardizing to one role name",
                        flagged_text=f"{dup['role1']} / {dup['role2']}"
                    ).to_dict())
            
            # Store in database if enabled
            if store_in_database and self._database:
                self._store_in_database(filepath, extracted)
        
        except Exception as e:
            result['error'] = str(e)
            _log(f"Error extracting roles: {e}", level='error')
        
        return result
    
    def _generate_role_issues(self, 
                              extracted: Dict,
                              paragraphs: List[Tuple[int, str]]) -> List[Dict]:
        """Generate review issues for role-related findings."""
        issues = []
        
        for role_name, role_data in extracted.items():
            # Issue: Role with no responsibilities found
            if not role_data.responsibilities:
                # Find first occurrence paragraph
                para_idx = 0
                para_text = ""
                if role_data.occurrences:
                    # Use context from first occurrence since RoleOccurrence doesn't have paragraph_index
                    para_text = role_data.occurrences[0].context[:100] if role_data.occurrences[0].context else ""
                    # Try to find the paragraph that contains this context
                    for idx, text in paragraphs:
                        if role_data.occurrences[0].context and role_data.occurrences[0].context[:50] in text:
                            para_idx = idx
                            break
                
                issues.append(RoleIssue(
                    category='Roles',
                    severity='Info',
                    message=f"Role '{role_name}' mentioned but no specific responsibilities identified",
                    paragraph_index=para_idx,
                    paragraph_text=para_text,
                    flagged_text=role_name,
                    suggestion="Consider adding explicit responsibilities for this role"
                ).to_dict())
            
            # Issue: Low confidence role extraction
            if role_data.avg_confidence < 0.5:
                issues.append(RoleIssue(
                    category='Roles',
                    severity='Info',
                    message=f"Role '{role_name}' detected with low confidence ({role_data.avg_confidence:.0%})",
                    flagged_text=role_name,
                    suggestion="Verify this is an actual role reference"
                ).to_dict())
        
        return issues
    
    def _check_for_duplicates(self, role_names: List[str]) -> List[Dict]:
        """Check for duplicate/similar role names."""
        duplicates = []
        checked_pairs = set()
        
        for i, name1 in enumerate(role_names):
            for name2 in role_names[i+1:]:
                pair_key = tuple(sorted([name1, name2]))
                if pair_key in checked_pairs:
                    continue
                checked_pairs.add(pair_key)
                
                try:
                    result = self._consolidation(name1, name2)
                    if result.get('are_similar', False):
                        duplicates.append({
                            'role1': name1,
                            'role2': name2,
                            'similarity': result.get('overall_similarity', 0),
                            'should_merge': result.get('should_merge', False)
                        })
                except Exception:
                    pass
        
        return duplicates
    
    def _store_in_database(self, filepath: str, extracted: Dict):
        """Store extracted roles in the database."""
        if not self._database:
            return
        
        try:
            # Register document
            from role_management_studio_v3 import SourceDocument, StandardRole
            
            doc = SourceDocument(
                id=os.path.basename(filepath),
                name=os.path.basename(filepath),
                path=filepath,
                doc_type="Technical",
                status="active",
                upload_date=datetime.now().isoformat(),
                processed_date=datetime.now().isoformat(),
                version="1.0",
                notes="Processed via TechWriterReview"
            )
            self._database.add_document(doc)
            
            # Add roles
            for role_name, role_data in extracted.items():
                role = StandardRole(
                    id=f"role_{hash(role_name) % 100000:05d}",
                    canonical_name=role_data.canonical_name,
                    category=self._categorize_role(role_name),
                    subcategory="",
                    description="",
                    typical_responsibilities=list(role_data.responsibilities)[:10],
                    typical_actions=list(role_data.action_types.keys())[:5],
                    aliases=list(role_data.variants),
                    reports_to=[],
                    coordinates_with=[],
                    supervises=[],
                    required_skills=[],
                    certifications=[],
                    created_date=datetime.now().isoformat(),
                    modified_date=datetime.now().isoformat(),
                    usage_count=role_data.frequency,
                    confidence_avg=role_data.avg_confidence,
                    is_approved=False,
                    approved_by="",
                    notes=f"Extracted from {os.path.basename(filepath)}",
                    last_modified_by="TechWriterReview",
                    source_document_ids=[doc.id],
                    active_document_count=1,
                    custom_fields={}
                )
                self._database.add_role(role)
            
            _log(f"Stored {len(extracted)} roles from {os.path.basename(filepath)}")
        
        except Exception as e:
            _log(f"Error storing in database: {e}", level='error')
    
    def _categorize_role(self, role_name: str) -> str:
        """Categorize a role based on its name."""
        name_lower = role_name.lower()
        
        if any(x in name_lower for x in ['engineer', 'developer', 'architect', 'designer']):
            return "Engineering"
        elif any(x in name_lower for x in ['manager', 'director', 'lead', 'supervisor', 'chief']):
            return "Management"
        elif any(x in name_lower for x in ['quality', 'qa', 'qc', 'inspector', 'auditor']):
            return "Quality"
        elif any(x in name_lower for x in ['test', 'verification', 'validation']):
            return "Test"
        elif any(x in name_lower for x in ['safety', 'security', 'compliance']):
            return "Safety"
        elif any(x in name_lower for x in ['program', 'project', 'contract']):
            return "Program"
        elif any(x in name_lower for x in ['logistics', 'supply', 'procurement']):
            return "Logistics"
        else:
            return "Other"
    
    def get_role_summary(self, role_name: str) -> Optional[Dict]:
        """Get summary for a specific role from the database."""
        if not self._database:
            return None
        
        try:
            role = self._database.get_role_by_name(role_name)
            if role:
                return self._database.get_aggregated_role_data(role.id)
        except Exception as e:
            _log(f"Error getting role summary: {e}", level='error')
        
        return None
    
    def export_roles_for_visualization(self, filepath: str) -> bool:
        """
        Export all roles to JSON format for external visualization tool.
        
        Args:
            filepath: Output JSON file path
        
        Returns:
            True if successful, False otherwise
        """
        if not self._database:
            _log("No database available for export", level='warning')
            return False
        
        try:
            self._database.export_for_external_tool(filepath)
            _log(f"Exported roles to {filepath}")
            return True
        except Exception as e:
            _log(f"Export error: {e}", level='error')
            return False
    
    def generate_consolidation_report(self, format: str = "html") -> Optional[str]:
        """
        Generate a report of potential role consolidations.
        
        Args:
            format: "text", "markdown", or "html"
        
        Returns:
            Report string or None if not available
        """
        if not self._database:
            return None
        
        try:
            from role_consolidation_engine import RoleConsolidationEngine
            
            engine = RoleConsolidationEngine(self._database)
            candidates = engine.find_consolidation_candidates()
            return engine.generate_consolidation_report(candidates, format)
        except Exception as e:
            _log(f"Error generating report: {e}", level='error')
            return None


# =============================================================================
# STATEMENT FORGE INTEGRATION (v3.0.41)
# =============================================================================

    def map_statements_to_roles(
        self,
        statements: List[Dict],
        extracted_roles: Dict
    ) -> Dict[str, Any]:
        """
        Map Statement Forge statements to extracted roles.
        
        v3.0.41: Batch H - Statement Forge → Role Responsibilities mapping.
        
        This creates a bidirectional mapping:
        - role → list of statements that mention/relate to that role
        - statement → list of roles it mentions
        
        Args:
            statements: List of statement dicts from Statement Forge
                       (each has 'id', 'description', 'role', 'directive', etc.)
            extracted_roles: Dict from role extraction
                            {'roles': {role_name: {variants, responsibilities, ...}}}
        
        Returns:
            {
                'role_to_statements': {role_name: [statement_info, ...]},
                'statement_to_roles': {statement_id: [role_names]},
                'unmapped_statements': [statement_ids with no role match],
                'stats': {
                    'total_statements': N,
                    'mapped_statements': N,
                    'coverage_percent': N.N
                }
            }
        """
        if not self.is_available():
            return {
                'role_to_statements': {},
                'statement_to_roles': {},
                'unmapped_statements': [],
                'stats': {'total_statements': 0, 'mapped_statements': 0, 'coverage_percent': 0},
                'error': 'Role extraction module not available'
            }
        
        role_to_statements = {}
        statement_to_roles = {}
        unmapped_statements = []
        
        # Get role data
        roles_dict = extracted_roles.get('roles', {})
        if not roles_dict:
            _log("No roles available for mapping", level='warning')
            return {
                'role_to_statements': {},
                'statement_to_roles': {},
                'unmapped_statements': [s.get('id', '') for s in statements],
                'stats': {
                    'total_statements': len(statements),
                    'mapped_statements': 0,
                    'coverage_percent': 0
                }
            }
        
        # Build role name lookup (canonical + variants)
        role_lookup = {}  # lowercase name → canonical name
        for role_name, role_data in roles_dict.items():
            canonical = role_name.lower().strip()
            role_lookup[canonical] = role_name
            # Add variants
            for variant in role_data.get('variants', []):
                role_lookup[variant.lower().strip()] = role_name
        
        # Initialize role_to_statements
        for role_name in roles_dict.keys():
            role_to_statements[role_name] = []
        
        # Process each statement
        for stmt in statements:
            stmt_id = stmt.get('id', '')
            description = stmt.get('description', '')
            explicit_role = stmt.get('role', '')  # SF may have extracted a role
            directive = stmt.get('directive', '')
            number = stmt.get('number', '')
            
            found_roles = set()
            
            # 1. Check explicit role field from Statement Forge
            if explicit_role:
                explicit_lower = explicit_role.lower().strip()
                if explicit_lower in role_lookup:
                    found_roles.add(role_lookup[explicit_lower])
                else:
                    # Try partial match
                    for lookup_name, canonical in role_lookup.items():
                        if lookup_name in explicit_lower or explicit_lower in lookup_name:
                            found_roles.add(canonical)
                            break
            
            # 2. Search description for role mentions
            desc_lower = description.lower()
            for lookup_name, canonical in role_lookup.items():
                # Avoid very short matches (< 3 chars) causing false positives
                if len(lookup_name) >= 3 and lookup_name in desc_lower:
                    # Verify it's a word boundary match (not substring of another word)
                    import re
                    pattern = r'\b' + re.escape(lookup_name) + r'\b'
                    if re.search(pattern, desc_lower):
                        found_roles.add(canonical)
            
            # Record mapping
            if found_roles:
                statement_to_roles[stmt_id] = list(found_roles)
                stmt_info = {
                    'id': stmt_id,
                    'number': number,
                    'description': description[:200] + ('...' if len(description) > 200 else ''),
                    'directive': directive,
                    'full_description': description
                }
                for role_name in found_roles:
                    if role_name in role_to_statements:
                        role_to_statements[role_name].append(stmt_info)
            else:
                unmapped_statements.append(stmt_id)
        
        # Calculate stats
        total = len(statements)
        mapped = total - len(unmapped_statements)
        coverage = (mapped / total * 100) if total > 0 else 0
        
        _log(f"Statement-to-role mapping complete: {mapped}/{total} statements mapped ({coverage:.1f}%)")
        
        return {
            'role_to_statements': role_to_statements,
            'statement_to_roles': statement_to_roles,
            'unmapped_statements': unmapped_statements,
            'stats': {
                'total_statements': total,
                'mapped_statements': mapped,
                'coverage_percent': round(coverage, 1)
            }
        }


# =============================================================================
# CONVENIENCE FUNCTIONS (for direct use without instantiation)
# =============================================================================

_default_integration = None

def get_integration(database_path: Optional[str] = None) -> RoleIntegration:
    """Get or create a default RoleIntegration instance."""
    global _default_integration
    if _default_integration is None:
        _default_integration = RoleIntegration(database_path)
    return _default_integration


def extract_roles_from_document(filepath: str, full_text: str, paragraphs: List[Tuple[int, str]]) -> Dict:
    """
    Convenience function to extract roles without managing instance.
    
    Usage in core.py:
        from role_integration import extract_roles_from_document
        role_result = extract_roles_from_document(filepath, extractor.full_text, extractor.paragraphs)
    """
    return get_integration().extract_roles(filepath, full_text, paragraphs)


# =============================================================================
# CHECKER CLASS (for seamless integration with TechWriterReview checker system)
# =============================================================================

class RoleChecker:
    """
    Role checker that follows TechWriterReview's BaseChecker pattern.
    Can be added to core.py's checkers dict like any other checker.
    """
    
    CATEGORY = "Roles"
    SEVERITY_DEFAULT = "Info"
    
    def __init__(self, database_path: Optional[str] = None):
        self.integration = RoleIntegration(database_path)
        self.enabled = True
    
    def check(self, paragraphs: List[Tuple[int, str]], full_text: str = "",
              filepath: str = "", **kwargs) -> List[Dict]:
        """
        Check method compatible with TechWriterReview's checker interface.
        
        Returns list of issue dictionaries.
        """
        if not self.enabled or not self.integration.is_available():
            return []
        
        try:
            result = self.integration.extract_roles(filepath, full_text, paragraphs, store_in_database=False)
            return result.get('issues', [])
        except Exception as e:
            _log(f"RoleChecker error: {e}", level='error')
            return []
    
    def safe_check(self, **kwargs) -> List[Dict]:
        """Safe wrapper that catches all exceptions."""
        try:
            return self.check(**kwargs)
        except Exception as e:
            _log(f"RoleChecker safe check error: {e}", level='error')
            return []


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    print(f"Role Integration Module v{__version__}")
    print("=" * 50)
    
    integration = RoleIntegration()
    print(f"Available: {integration.is_available()}")
    
    # Test with sample text
    test_text = """
    The Systems Engineer shall review all design documents.
    The Quality Manager approves all test procedures.
    The Program Manager coordinates with all stakeholders.
    The Configuration Manager maintains the baseline.
    """
    
    if integration.is_available():
        result = integration.extract_roles("test.docx", test_text, [(0, test_text)])
        print(f"\nRoles found: {result['roles_found']}")
        for name, data in result['roles'].items():
            print(f"  - {name}: {data['frequency']} occurrences")
        print(f"\nIssues: {len(result['issues'])}")
        print(f"Duplicates detected: {result['duplicates_detected']}")
    else:
        print("\nRole extraction modules not installed.")
        print("To enable, copy these files to the TechWriterReview directory:")
        print("  - role_extractor_v3.py")
        print("  - role_management_studio_v3.py (optional)")
        print("  - role_consolidation_engine.py (optional)")
