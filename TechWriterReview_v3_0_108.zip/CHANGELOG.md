# TechWriterReview Changelog

All notable changes to TechWriterReview are documented in this file.

## [3.0.108] - 2026-01-28

### Fixed
- **BUG-009**: Document filter dropdown now populates with scanned document names
- Added `source_documents` field to role extraction data for proper filtering

## [3.0.107] - 2026-01-28

### Fixed
- **BUG-007**: Role Details tab now shows `sample_contexts` from documents
- **BUG-008**: Role-Doc Matrix shows helpful guidance when empty instead of stuck on "Loading"

### Improved
- Matrix tab explains how to populate cross-document data
- Better empty state messaging throughout Role Studio

## [3.0.106] - 2026-01-28

### Fixed
- **BUG-006**: Fix Assistant v2 Document Viewer was empty (0 paragraphs) - `paragraphs`, `page_map`, and `headings` now returned from `core.py` review results
- **BUG-M01**: Remaining deprecated `datetime.utcnow()` calls in `config_logging.py` replaced with `datetime.now(timezone.utc)`

## [3.0.105] - 2026-01-28

### Fixed
- **BUG-001**: Report generator API signature mismatch - `generate()` now returns bytes when `output_path` not provided
- **BUG-002**: Learner stats endpoint now uses standard `{success, data}` response envelope
- **BUG-003**: Acronym checker mode handling - strict mode now properly flags common acronyms like NASA
- **BUG-004**: Role classification tiebreak - "Report Engineer" now correctly classified as role
- **BUG-005**: Comment pack now includes location hints from `hyperlink_info`

### Maintenance
- Updated deprecated `datetime.utcnow()` calls to `datetime.now(timezone.utc)` (partial - completed in 3.0.106)

## [3.0.104] - 2026-01-28

### Fixed
- Fix Assistant v2 load failure - BodyText style conflict resolved
- Logger reserved keyword conflict in static file security endpoint

### Tests
- Updated test expectations for static file security responses
- Fixed CSS test locations for modularized stylesheets

## [3.0.103] - 2026-01-28

### Security
- innerHTML safety audit - all 143 usages documented and verified (Task A)

### Refactored
- CSS modularized into 10 logical files for maintainability (Task B)

### Quality
- Test suite modernized with docstrings (Task C)
- Exception handling refined with specific catches (Task D)
- Added comprehensive code comments throughout JavaScript

### Tests
- Added `TestFixAssistantV2API` class
- Added `TestBatchLimits` class  
- Added `TestSessionCleanup` class

## [3.0.102] - 2026-01-28 *(reconstructed)*

### Added
- Intermediate stabilization release between 3.0.101 and 3.0.103

## [3.0.101] - 2026-01-28

### Refactored
- Standardized API error responses with correlation IDs (ISSUE-004)
- Centralized document type detection into `get_document_extractor()` helper (ISSUE-008)
- Centralized user-facing strings into `STRINGS` constant (ISSUE-009)

### Documentation
- Added comprehensive JSDoc comments to feature modules (ISSUE-010)
- Completed remaining 4 of 12 issues from comprehensive code review audit

## [3.0.100] - 2026-01-28

### Security
- Added ReDoS protection with safe regex wrappers (ISSUE-001)
- Enhanced input validation on learner dictionary API (ISSUE-005)

### Performance
- Enabled WAL mode for SQLite with `busy_timeout` for concurrent access (ISSUE-002)
- Added file size validation for large document protection (ISSUE-003)

### Fixed
- `State.entities` now properly reset on new document load (ISSUE-006)
- Added `cleanup()` function to `FixAssistantState` to prevent memory leaks (ISSUE-007)
- Addressed 7 of 12 issues from comprehensive code review audit

## [3.0.99] - 2026-01-28 *(reconstructed)*

### Added
- Intermediate release with bug fixes between 3.0.98 and 3.0.100

## [3.0.98] - 2026-01-28

### Fixed
- **BUG-001**: Double browser tab on startup
- **BUG-002**: Export modal crash
- **BUG-003**: Context highlighting showing wrong text
- **BUG-004**: Restored hyperlink status panel
- **BUG-005**: Version history gaps in Help modal
- **BUG-009**: Restored Role-Document matrix tab

### Improved
- **BUG-006**: Comprehensive `TWR_LESSONS_LEARNED.md` updates
- **BUG-007**: Role Details tab with context preview
- **BUG-008**: Document filter dropdown in Role Studio

## [3.0.97] - 2026-01-28

### Added - Fix Assistant v2 (Major Feature)
- Two-panel document viewer with page navigation and highlighting
- Mini-map showing document overview with fix position markers
- Undo/redo capability for all review decisions
- Search and filter fixes by text, category, or confidence
- Save progress and continue later (localStorage persistence)
- Learning from user decisions (pattern tracking, no AI)
- Custom dictionary for terms to always skip
- Live preview mode showing changes inline
- Split-screen view (original vs fixed document)
- PDF summary report generation
- Accessibility features (high contrast, screen reader support)
- Enhanced keyboard shortcuts (A=accept, R=reject, S=skip, U=undo)
- Optional sound effects for actions (Web Audio API)
- Rejected fixes exported as document comments with reviewer notes

### Improved
- Export now handles both accepted fixes (track changes) and rejected fixes (comments)

### API
- Added `/api/learner/*` endpoints for pattern learning
- Added `/api/report/generate` endpoint for PDF reports

## [3.0.96] - 2026-01-27

### Added - Fix Assistant v1
- Premium triage-style interface for reviewing automatic fixes
- Keyboard shortcuts (A=accept, R=reject, S=skip, arrows=nav)
- Confidence tiers (Safe/Review/Caution) for each proposed fix
- Context display showing surrounding text with highlighted change
- Before/After comparison with clear visual distinction
- Bulk actions (Accept All Safe, Accept All, Reject All)

### Improved
- Export now uses Fix Assistant selections instead of all fixes
- Progress tracking shows reviewed/total count

### UI
- Premium styling with confidence badges, progress bar, keyboard hints

## [3.0.95] - 2026-01-27

### Fixed
- Version display consistency - all UI components now show same version
- About section simplified - shows only author name
- Heatmap clicking - Category × Severity heatmap now filters issues on click

### Added
- Hyperlink status panel - visual display of checked hyperlinks and validation status

### Improved
- Section heatmap click feedback with toast messages

## [3.0.94] - 2026-01-27 *(reconstructed)*

### Added
- Intermediate release with improvements between 3.0.93 and 3.0.95

## [3.0.93] - 2026-01-27

### Improved - Acronym Detection
- Added 100+ common ALL CAPS words to `COMMON_CAPS_SKIP`
- Added PDF word fragment detection

### Testing
- Reduced false positive acronym flagging by ~55%

## [3.0.92] - 2026-01-27

### Fixed
- PDF punctuation false positives
- Acronym false positives

### Added
- PDF hyperlink extraction via PyMuPDF

---

## Version Numbering

TechWriterReview uses semantic versioning: `MAJOR.MINOR.PATCH`

- **MAJOR** (3): Major architectural changes
- **MINOR** (0): Feature additions
- **PATCH** (92-108): Bug fixes and improvements

---

## Links

- [Bug Tracker](TWR_BUG_TRACKER.md)
- [Project State](docs/TWR_PROJECT_STATE.md)
- [Lessons Learned](TWR_LESSONS_LEARNED.md)
