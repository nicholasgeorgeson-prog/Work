"""
TechWriterReview - Scan Recall Routes Extension
===============================================
Version: 3.0.53

This module adds scan recall and history management endpoints.
It should be imported and registered with the Flask app.

Usage in app.py:
    # Add near other imports at top of file
    try:
        from scan_recall_routes import register_scan_recall_routes
        SCAN_RECALL_AVAILABLE = True
    except ImportError:
        SCAN_RECALL_AVAILABLE = False

    # Add after app is created (after `app = Flask(__name__)`)
    if SCAN_RECALL_AVAILABLE:
        register_scan_recall_routes(app)
"""

import sqlite3
import json
import os
from flask import jsonify, request


def register_scan_recall_routes(app):
    """Register scan recall and history management routes with the Flask app."""
    
    # Get references to existing decorators and functions
    # These should already exist in app.py
    handle_api_errors = app.config.get('HANDLE_API_ERRORS') or (lambda f: f)
    require_csrf = app.config.get('REQUIRE_CSRF') or (lambda f: f)
    
    # Try to get the decorator from the app's view functions
    # or use a passthrough if not available
    def get_decorator(name):
        """Try to find existing decorator or return passthrough."""
        if hasattr(app, name):
            return getattr(app, name)
        return lambda f: f
    
    # Import from app's context
    try:
        from scan_history import get_scan_history_db
        SCAN_HISTORY_AVAILABLE = True
    except ImportError:
        SCAN_HISTORY_AVAILABLE = False
        def get_scan_history_db():
            return None

    @app.route('/api/scan-history/<int:scan_id>/recall', methods=['GET'])
    def recall_scan(scan_id):
        """Recall a previous scan's full results."""
        if not SCAN_HISTORY_AVAILABLE:
            return jsonify({'success': False, 'error': 'Scan history not available'})
        
        db = get_scan_history_db()
        if not db:
            return jsonify({'success': False, 'error': 'Database not available'})
        
        conn = sqlite3.connect(db.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT s.id, s.document_id, s.scan_time, s.options_json, s.issue_count, 
                       s.score, s.grade, s.word_count, s.paragraph_count, s.results_json,
                       d.filename, d.filepath
                FROM scans s
                JOIN documents d ON s.document_id = d.id
                WHERE s.id = ?
            ''', (scan_id,))
            
            row = cursor.fetchone()
            
            if not row:
                return jsonify({'success': False, 'error': 'Scan not found'})
            
            options = json.loads(row[3]) if row[3] else {}
            results = json.loads(row[9]) if row[9] else {}
            
            return jsonify({
                'success': True,
                'data': {
                    'scan_id': row[0],
                    'document_id': row[1],
                    'scan_time': row[2],
                    'options': options,
                    'issue_count': row[4],
                    'score': row[5],
                    'grade': row[6],
                    'word_count': row[7],
                    'paragraph_count': row[8],
                    'results': results,
                    'filename': row[10],
                    'filepath': row[11]
                }
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            conn.close()

    @app.route('/api/scan-history/stats', methods=['GET'])
    def get_history_stats():
        """Get scan history storage statistics."""
        if not SCAN_HISTORY_AVAILABLE:
            return jsonify({'success': False, 'error': 'Scan history not available'})
        
        db = get_scan_history_db()
        if not db:
            return jsonify({'success': False, 'error': 'Database not available'})
        
        conn = sqlite3.connect(db.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT COUNT(*) FROM documents')
            doc_count = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM scans')
            scan_count = cursor.fetchone()[0]
            
            cursor.execute('SELECT MIN(scan_time), MAX(scan_time) FROM scans')
            dates = cursor.fetchone()
            
            cursor.execute('SELECT SUM(LENGTH(results_json)) FROM scans')
            results_size = cursor.fetchone()[0] or 0
            
            db_size = os.path.getsize(db.db_path) if os.path.exists(db.db_path) else 0
            
            return jsonify({
                'success': True,
                'data': {
                    'document_count': doc_count,
                    'scan_count': scan_count,
                    'oldest_scan': dates[0],
                    'newest_scan': dates[1],
                    'results_storage_bytes': results_size,
                    'database_size_bytes': db_size,
                    'database_size_mb': round(db_size / (1024 * 1024), 2)
                }
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            conn.close()

    @app.route('/api/scan-history/clear', methods=['POST'])
    def clear_scan_history_data():
        """Clear scan history with options."""
        if not SCAN_HISTORY_AVAILABLE:
            return jsonify({'success': False, 'error': 'Scan history not available'})
        
        db = get_scan_history_db()
        if not db:
            return jsonify({'success': False, 'error': 'Database not available'})
        
        data = request.get_json() or {}
        clear_all = data.get('clear_all', False)
        older_than_days = data.get('older_than_days')
        keep_per_document = data.get('keep_per_document')
        document_id = data.get('document_id')
        
        conn = sqlite3.connect(db.db_path)
        cursor = conn.cursor()
        deleted_count = 0
        
        try:
            if clear_all:
                cursor.execute('DELETE FROM issue_changes')
                cursor.execute('DELETE FROM scans')
                cursor.execute('DELETE FROM document_roles')
                cursor.execute('DELETE FROM documents')
                deleted_count = cursor.rowcount
                
            elif older_than_days:
                cursor.execute('''
                    DELETE FROM scans 
                    WHERE scan_time < datetime('now', '-' || ? || ' days')
                ''', (older_than_days,))
                deleted_count = cursor.rowcount
                cursor.execute('DELETE FROM issue_changes WHERE scan_id NOT IN (SELECT id FROM scans)')
                
            elif keep_per_document:
                cursor.execute('''
                    DELETE FROM scans WHERE id IN (
                        SELECT id FROM (
                            SELECT id, ROW_NUMBER() OVER (
                                PARTITION BY document_id ORDER BY scan_time DESC
                            ) as rn FROM scans
                        ) WHERE rn > ?
                    )
                ''', (keep_per_document,))
                deleted_count = cursor.rowcount
                cursor.execute('DELETE FROM issue_changes WHERE scan_id NOT IN (SELECT id FROM scans)')
                
            elif document_id:
                cursor.execute('DELETE FROM issue_changes WHERE document_id = ?', (document_id,))
                cursor.execute('DELETE FROM scans WHERE document_id = ?', (document_id,))
                deleted_count = cursor.rowcount
            
            conn.commit()
            cursor.execute('VACUUM')
            
            return jsonify({
                'success': True,
                'data': {
                    'deleted_scans': deleted_count,
                    'message': f'Cleared {deleted_count} scan records'
                }
            })
            
        except Exception as e:
            conn.rollback()
            return jsonify({'success': False, 'error': str(e)})
        finally:
            conn.close()

    print('[TWR] Scan recall routes registered successfully')
    return True
