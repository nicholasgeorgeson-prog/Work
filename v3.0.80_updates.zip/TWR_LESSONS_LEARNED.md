# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.80

---

## Session: v3.0.80 (January 26, 2026) - ROLES EXPORT FUNCTIONALITY

### The Problem
User needed to export roles data to CSV with options for all documents or a selected document. The export button in Roles & Responsibilities Studio wasn't functional.

### The Solution
Added comprehensive export dropdown with multiple options:

1. **Export All Roles (CSV)** - Aggregated roles across all scanned documents
2. **Export Current Document (CSV)** - Roles from the currently loaded document
3. **Export Selected Document...** - Document picker to export from a specific historical scan
4. **Export All Roles (JSON)** - Full data export in JSON format

### Implementation Details

**Frontend (roles.js):**
- Added `initExportDropdown()` to set up dropdown menu handlers
- `exportAllRolesCSV()` - Calls `/api/roles/aggregated` endpoint
- `exportCurrentDocumentCSV()` - Uses State.roles data
- `showDocumentExportPicker()` - Loads document list, shows picker modal
- `exportDocumentRolesById()` - Calls new `/api/scan-history/document/<id>/roles` endpoint

**Backend (scan_history.py + app.py):**
- Added `get_document_roles(document_id)` method to ScanHistoryDB class
- Added `/api/scan-history/document/<int:doc_id>/roles` API endpoint

**HTML (index.html):**
- Replaced single export button with dropdown menu
- Added dropdown items for each export option

**CSS (style.css):**
- Added `.dropdown-menu.show` display class
- Added document picker styling

### Lesson
**Export functionality should offer multiple scopes.** Users need to export data at different granularities - all data, current context, or historical selections. A dropdown menu provides clean access to these options without cluttering the interface.

---

## Session: v3.0.79 (January 26, 2026) - DIMMED NODE VISIBILITY FIX

### The Problem
Nodes were still nearly invisible, even after v3.0.78 SVG opacity fix.

### Root Cause
The CSS `.dimmed` class (applied when a node is selected to fade unrelated nodes) had `opacity: 0.3` - far too low to see. Multiple places in CSS defined this:
- `.graph-node.dimmed { opacity: 0.3; }`
- `.graph-node.dimmed circle { opacity: 0.3; }`
- `.graph-node.dimmed .graph-node-label { opacity: 0 !important; }` (completely hidden!)
- `.graph-link.dimmed { stroke-opacity: 0.1; }`

### The Fix (style.css)
Increased all dimmed opacities to visible levels:
- Node: 0.3 → 0.5
- Circle: 0.3 → 0.5
- Label: 0 → 0.4
- Link: 0.1 → 0.3

### Lesson
**Check CSS for classes that might override inline styles.** The `.dimmed` class was being applied by JavaScript when selecting nodes, and its CSS had very low opacity values that made nodes nearly invisible.

---

## Session: v3.0.78 (January 26, 2026) - WEAK NODE VISIBILITY FIX

### The Problem
v3.0.77 added styling for weak nodes, but they were still nearly invisible. The peripheral nodes appeared as very faint gray circles.

### Root Cause
The code used hex opacity suffix (`#4A90D980`) which doesn't work in SVG. SVG requires proper attributes like `fill-opacity`.

### The Fix (roles.js)
Changed from hex opacity to proper SVG attributes:

```javascript
// WRONG - doesn't work in SVG
.attr('fill', d => baseColor + '80')

// CORRECT - use SVG opacity attribute
.attr('fill', d => colorScale[d.type] || '#888')
.attr('fill-opacity', d => d.connectionCount <= 2 ? 0.5 : 1)
.attr('stroke-width', d => d.connectionCount <= 2 ? 2.5 : 1)
.attr('stroke-opacity', 1)
.attr('stroke-dasharray', d => d.connectionCount <= 2 ? '4,2' : 'none')
```

Also increased minimum node size from 8px to 10px.

### Lesson
**SVG doesn't support hex opacity suffixes.** Use proper SVG attributes (`fill-opacity`, `stroke-opacity`) instead of CSS-style hex opacity.

---

## Session: v3.0.77 (January 26, 2026) - SELF-EXPLANATORY GRAPH

### The Problem
Users couldn't understand the graph visualization without training. Questions included:
- What does node size mean?
- What do the lines represent?
- Why are some nodes faded/invisible?
- What's the difference between line types?

### The Solution
Instead of hiding weak connections, **make them visible but visually distinct**:

1. **All connected nodes shown** - reverted to orphan-only filtering (>=1 connection)
2. **Weak nodes styled differently** - dashed outline, semi-transparent fill
3. **Distinct line types**:
   - Solid blue lines = "Role appears in Document"
   - Dashed purple lines = "Roles co-occur in same document(s)"
4. **Enhanced legend** with visual examples:
   - Node size scale (small → large = few → many mentions)
   - Line thickness scale (thin → thick = weak → strong connection)
   - Weak vs strong node visual
   - Line type meanings
5. **First-time hint banner** - "Click any node to see details. Drag to rearrange. Scroll to zoom."

### Key Code Changes

**roles.js:**
- Reverted MIN_CONNECTIONS to 1 (show all connected nodes)
- Added `connectionCount` property to each node
- Added `weak-connection` class for nodes with ≤2 connections
- Updated node circle creation with minimum 8px size
- Added stroke to all nodes
- Weak nodes get semi-transparent fill (`color + '80'`)
- Updated LINK_STYLES: role-role now has `dashArray: '6,3'` and distinct color

**style.css:**
- Added `.graph-node.weak-connection` styles
- Added `.graph-first-time-hint` banner styles
- Added legend visual example styles (`.legend-node-small`, `.legend-line-solid`, etc.)

**index.html:**
- Replaced old legend with enhanced self-explanatory version
- Added first-time hint banner
- Added visual examples in legend

### Lesson
**Don't hide data - style it differently.** Users need to see all their data, just with visual cues about significance. A good visualization should be self-explanatory without requiring training or documentation.

---

## Session: v3.0.76 (January 26, 2026) - PHANTOM LINES FIX + DOCUMENT LOG FIX

### Problem 1: Phantom Lines in Graph
After v3.0.75, faded circles were removed but "phantom lines" still appeared - faint lines extending from the main cluster to barely-visible nodes at the periphery.

### Root Cause
v3.0.75 only removed TRUE orphans (nodes with 0 connections). But nodes with just 1 connection:
1. Pass the "has connections" filter
2. Get pushed to the periphery by D3's force simulation
3. Their single connection line appears as a "phantom line" to distant space

### The Fix (roles.js)
Replaced simple orphan filtering with **iterative peripheral node pruning**:

```javascript
const MIN_CONNECTIONS = 2; // Nodes need at least 2 connections

let nodesRemoved = true;
while (nodesRemoved && pruneIterations < 10) {
    // Count connections per node
    const connectionCount = new Map();
    nodes.forEach(n => connectionCount.set(n.id, 0));
    links.forEach(link => {
        connectionCount.set(sourceId, connectionCount.get(sourceId) + 1);
        connectionCount.set(targetId, connectionCount.get(targetId) + 1);
    });
    
    // Filter nodes with insufficient connections
    nodes = nodes.filter(n => connectionCount.get(n.id) >= MIN_CONNECTIONS);
    
    // Re-filter links after removing nodes
    // (removing a node may leave another node with fewer connections)
}
```

### Why Iterative?
Removing a node can cascade:
1. Node A has 2 connections (passes filter)
2. Node B has 2 connections (passes filter)  
3. One of A's connections is TO B
4. Remove another node → A now has 1 connection → Remove A → B now has 1 connection → Remove B

The iterative approach continues until no more nodes need removal (stable state).

---

### Problem 2: Document Log Shows 0 Roles
The Document Log tab in Roles & Responsibilities was showing "0" for role count on all historical scans.

### Root Cause
The backend `get_scan_history()` function in `scan_history.py` did NOT include `role_count` in its SQL query or results. The frontend was looking for `scan.role_count` which didn't exist, defaulting to 0.

### The Fix (scan_history.py)
Added a subquery to count roles per document:

```sql
SELECT s.id, d.filename, s.scan_time, ...
       (SELECT COUNT(*) FROM document_roles dr WHERE dr.document_id = d.id) as role_count
FROM scans s
JOIN documents d ON s.document_id = d.id
...
```

And added `'role_count': row[9] or 0` to the results dict.

### Lesson
**Always verify backend API returns all fields the frontend expects.** When debugging "0 values", check if the field actually exists in the API response.

---

## Session: v3.0.75 (January 26, 2026) - ORPHAN NODES FIX

### The Problem
In the Relationship Graph, faded circles appeared scattered around the canvas with no connections - floating orphan nodes that cluttered the visualization.

### Root Cause
The backend returns nodes based on `max_nodes` limit, but:
1. Their links might be below the `min_weight` threshold
2. Their connected nodes didn't make the `max_nodes` cut
3. Result: nodes exist in the data but have no visible edges

### The Fix (roles.js)
Filter nodes to only include those with at least one connection:

```javascript
// Build set of node IDs that are actually connected
const connectedNodeIds = new Set();
links.forEach(link => {
    const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
    const targetId = typeof link.target === 'object' ? link.target.id : link.target;
    connectedNodeIds.add(sourceId);
    connectedNodeIds.add(targetId);
});

// Filter nodes to only include connected ones
nodes = nodes.filter(n => connectedNodeIds.has(n.id));
```

### Lesson
**Graph visualizations should filter orphan nodes client-side.** Even if the backend returns nodes within limits, not all will have visible connections after link filtering.

---

## Session: v3.0.74 (January 26, 2026) - ENHANCED INFO PANEL + TICK HANDLER FIX

### Changes
1. **Tick Handler Safety** - Added `isFinite()` checks on coordinates, hide invalid links with `display:none`
2. **Enhanced Info Panel** - Visual progress bars, separate document/role sections, built-in legend
3. **New CSS** - `.info-stats-grid`, `.info-conn-bar`, `.info-legend` styles

---

## Session: v3.0.73 (January 26, 2026) - GRAPH INFO PANEL BUTTON FIX + UPDATE MANAGER v1.2

### The Problem
Tab content areas (Graph, Adjudication, RACI Matrix) had fixed heights or max-heights, leaving white space at the bottom of the modal.

### Root Causes
1. `.graph-container { height: 500px; }` - fixed height
2. `.adjudication-list { max-height: 400px; }` - constrained
3. `#responsibility-matrix { max-height: 400px; }` - constrained
4. SVG had `height="500"` HTML attribute

### The Fix
1. Changed `.roles-main` to flex container with `display: flex; flex-direction: column;`
2. Changed `.roles-section.active` to `display: flex !important` with `flex: 1`
3. Changed `.graph-container` to `flex: 1; min-height: 400px;` (not fixed)
4. Removed `max-height` constraints from content areas
5. Added `height: 100% !important` to SVG to override HTML attribute
6. Added flex rules for all tab sections

### Lesson
**For full-height content in modals:**
1. Use `display: flex; flex-direction: column;` on container
2. Use `flex: 1` on child elements that should expand
3. Use `min-height` instead of fixed `height`
4. Remove `max-height` constraints
5. Use `!important` on height to override HTML attributes
6. Add `min-height: 0` to allow flex shrinking

---

## Session: v3.0.71 (January 26, 2026) - HORIZONTAL TABS FIX

### The Problem
After v3.0.70 CSS fix, tabs displayed content but navigation was vertical sidebar instead of horizontal tabs.

### Root Cause
CSS had `.roles-sidebar { width: 220px; }` which forced vertical sidebar layout.
Additionally, responsive breakpoint at 1200px had `width: 200px` override.

### The Fix
Changed `.roles-sidebar` to:
- `width: 100%` (full width)
- `flex-direction: row` (horizontal layout)
- `display: flex` with horizontal alignment

Changed `.roles-nav-item` to:
- `width: auto` (not 100%)
- `white-space: nowrap` (prevent wrapping)
- Bottom border for active state (tab style)

Removed `width: 200px` from @media (max-width: 1200px) breakpoint.

### Lesson
**When converting sidebar to horizontal tabs:**
1. Remove fixed width constraints
2. Set flex-direction: row
3. Change nav items from width: 100% to width: auto
4. Use bottom borders for active indicators (not background)
5. Check ALL responsive breakpoints for conflicting rules

---

## Session: v3.0.70 (January 26, 2026) - CRITICAL CSS FIX

### The Problem
Roles & Responsibilities tabs showed blank content after v3.0.69 fresh install.

### Root Cause
v3.0.68 changed the JS to use `.active` class for section visibility:
```javascript
targetSection.classList.add('active');  // Instead of style.display = 'block'
```

But the **CSS rules that respond to this class were NEVER ADDED**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

### The Fix
Added the missing CSS rules to style.css (around line 2106).

### Lesson
**When changing JS from inline styles to class-based visibility, MUST add corresponding CSS rules.**

Always verify both sides of the equation:
1. JS adds/removes the class ✓
2. CSS responds to the class ✗ (was missing!)

---

## CRITICAL: End of Session Requirements

**At the end of EVERY development session, Claude must provide:**

1. **Complete Fresh Install ZIP** - A full `TWR_v3.0.XX_Fresh_Install.zip` containing:
   - All source files (Python backend, HTML templates, CSS, JS)
   - All fix modules that have been created
   - Updated version.json
   - Updated index.html with all script tags
   - This TWR_LESSONS_LEARNED.md file
   
2. **This ensures continuity** - The next chat session can start with a working, complete codebase rather than having to piece together multiple fixes.

---

## CRITICAL: Version Increment Checklist

**For EVERY version increment, update ALL of these files:**

| File | What to Update |
|------|----------------|
| `version.json` | version, release_date, core_version, add changelog entry |
| `help-docs.js` | Line 5 comment, line 17 version, line 18 lastUpdated, About section (version + build date), Version History section (add new entry), console.log at end |
| `TWR_LESSONS_LEARNED.md` | Version header, add session notes |
| `INSTALL.ps1` | Line 30 `$Version` variable |
| Any fix module headers | Update version in file comment header |

**help-docs.js locations to update:**
1. Line ~5: Comment header version
2. Line ~17: `version: 'X.X.XX'`
3. Line ~18: `lastUpdated: 'YYYY-MM-DD'`
4. Version History section: Add new `<div class="changelog-version changelog-current">` entry
5. About section: Version display and Build Date
6. Last line: `console.log('[HelpDocs] Module loaded vX.X.XX')`

**Failure to update help-docs.js causes version history gaps visible to users!**

---

## CRITICAL: Patch ZIP Structure

**Patches must mirror the app directory structure, NOT be flat files.**

**WRONG (flat structure):**
```
TWR_v3.0.69_Patch.zip
├── scan_history.py       ← User must manually place
├── roles-tabs-fix.js     ← User must manually place
├── help-docs.js          ← User must manually place
└── version.json          ← User must manually place
```

**CORRECT (mirrored structure):**
```
TWR_v3.0.69_Patch.zip
├── UPDATE.ps1            ← Automated installer script
└── TechWriterReview/
    ├── scan_history.py
    ├── version.json
    └── static/
        └── js/
            ├── roles-tabs-fix.js
            └── help-docs.js
```

**To create a proper patch:**
```bash
# Create structure mirroring app layout
mkdir -p patch/TechWriterReview/static/js

# Copy files to correct locations
cp scan_history.py patch/TechWriterReview/
cp version.json patch/TechWriterReview/
cp roles-tabs-fix.js patch/TechWriterReview/static/js/
cp help-docs.js patch/TechWriterReview/static/js/

# Include UPDATE.ps1 at root
cp UPDATE.ps1 patch/

# Create ZIP
cd patch && zip -r ../TWR_vX.X.XX_Patch.zip .
```

**UPDATE.ps1 applies patches to:** `$InstallPath/app/` (e.g., `C:\TWR\app\`)

---

## Smart Installer: INSTALL.ps1 v3.0.69

The installer now handles both fresh installs AND upgrades automatically.

### Upgrade Detection

When run, the installer:
1. Checks if `$InstallPath/app/` exists
2. Reads `version.json` to get current version
3. If found, prompts for upgrade confirmation

### User Data Preserved During Upgrades

| File/Folder | Purpose |
|-------------|---------|
| `scan_history.db` | All scan history and role extractions |
| `role_dictionary_master.json` | Custom role dictionary |
| `config.json` | User settings |
| `backups/` | User backups folder |
| `data/` | User data folder |
| `*.db` | Any other database files |

### Upgrade Process

1. **Backup** - Copies user data to `$InstallPath/upgrade_backup_YYYYMMDD-HHMMSS/`
2. **Remove** - Deletes old `app/` folder and `.venv/`
3. **Install** - Fresh copy from ZIP
4. **Restore** - Copies user data back to new installation
5. **Verify** - Checks critical files and directory structure

### Parameters

| Parameter | Purpose |
|-----------|---------|
| `-InstallPath "D:\TWR"` | Custom install location |
| `-ForceClean` | Delete all user data (no backup) |
| `-SkipCleanup` | Keep installer files after install |

---

## Session: v3.0.69 (January 26, 2026) - Responsibility Count Display Fix

### THE PROBLEM

**Overview tab "Top Roles by Responsibility Count" section was displaying incorrect data:**
1. Document tag showed total scan count (11) instead of unique document count
2. Right-side number showed `total_mentions` instead of actual responsibility count
3. Sorting was based on mentions, not responsibilities

### THE FIX

**Backend (scan_history.py):**
- Modified `get_all_roles()` to return two new fields:
  - `unique_document_count`: Count of deduplicated documents
  - `responsibility_count`: Sum of responsibilities from `responsibilities_json` across all document_roles
- Used `GROUP_CONCAT(DISTINCT d.filename)` for proper deduplication
- Parse and count JSON responsibilities from concatenated `responsibilities_json` data

**Frontend (roles-tabs-fix.js):**
- Updated tag to show: `${uniqueDocCount} unique doc${uniqueDocCount !== 1 ? 's' : ''}`
- Updated right-side to show: `${respCount}` with tooltip
- Changed sorting: primary by `responsibility_count`, secondary by `unique_document_count`
- Updated summary cards to sum `responsibility_count` instead of `total_mentions`

### Key Insight

The database stores responsibilities as JSON in `document_roles.responsibilities_json`. Each entry is an array of responsibility objects. To get total responsibility count per role, we must:
1. Concatenate all `responsibilities_json` entries for that role across documents
2. Parse each JSON chunk
3. Sum the array lengths

---

## Session: v3.0.68 (January 26, 2026) - FINAL FIX: CSS !important Override

### THE ACTUAL ROOT CAUSE ✅

**The Problem:** Tabs showed blank white boxes despite JavaScript rendering content correctly.

**Discovery Process:**
1. v3.0.66: Added fadeIn keyframes - didn't fix it
2. v3.0.67: Tried re-applying display:block after render - didn't fix it
3. Diagnostic script revealed the truth:
   ```
   Inline style display: block     ← We set this correctly
   Computed display: none          ← But CSS overrides it!
   ```

**Root Cause:** CSS uses `!important` which **cannot be overridden by inline styles**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

**The Fix:**
```javascript
// WRONG - gets overridden by !important
targetSection.style.display = 'block';

// CORRECT - matches the CSS rule
targetSection.classList.add('active');
```

### Critical CSS Specificity Lesson

**Inline styles DO NOT override `!important` CSS rules.**

Priority order (highest to lowest):
1. `!important` CSS rules
2. Inline styles (normally highest, but NOT vs !important)
3. ID selectors
4. Class selectors
5. Element selectors

When debugging visibility issues:
1. Check computed style vs inline style
2. If they differ, look for `!important` in CSS rules
3. Match what the CSS expects (classes, not inline styles)

### Diagnostic Script That Found It

```javascript
const section = document.getElementById('roles-overview');
console.log('Inline style display:', section.style.display);
console.log('Computed display:', getComputedStyle(section).display);

const rules = [];
for (const sheet of document.styleSheets) {
    try {
        for (const rule of sheet.cssRules) {
            if (rule.selectorText?.includes('roles-section')) {
                rules.push({selector: rule.selectorText, display: rule.style.display});
            }
        }
    } catch(e) {}
}
console.log('CSS rules:', rules);
```

---

## Session: v3.0.66 (January 25, 2026) - CSS Animation Fix

Added missing `@keyframes fadeIn` - good fix but not the main visibility issue.

---

## Session: v3.0.65 (January 24, 2026) - Graph Controls Fixed

Fixed all graph control dropdowns, search, slider, and buttons.

---

## Key Development Patterns

### 1. Section Visibility
Use `classList.add('active')` not `style.display` - CSS uses `!important` rules.

### 2. Modal Visibility  
Use `modal.classList.add('active')` for pointer-events.

### 3. Control Initialization
Use `_tabsFixInitialized` flag to prevent duplicate handlers.

### 4. API Namespace
Export functions via `window.TWR.RolesTabs = {...}`.

### 5. File Locations

| File Type | Production Location |
|-----------|---------------------|
| Python backend | TechWriterReview/*.py |
| HTML templates | TechWriterReview/templates/*.html |
| CSS | TechWriterReview/static/css/*.css |
| JavaScript | TechWriterReview/static/js/*.js |
| Fix modules | TechWriterReview/static/js/*-fix.js |

---

## Fix Modules Added Since v3.0.52

| Module | Version | Purpose |
|--------|---------|---------|
| button-fixes.js | v3.0.52 | Missing button handlers |
| run-state-fixes.js | v3.0.53 | Run state updates |
| history-fixes.js | v3.0.54b | Scan history rendering |
| update-functions.js | v3.0.52 | Update system helpers |
| roles-dictionary-fix.js | v3.0.52 | Dictionary tab functionality |
| roles-tabs-fix.js | v3.0.73 | Tab switching + graph info panel buttons |
