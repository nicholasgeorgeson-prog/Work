# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.86

---

## 🆕 Session: v3.0.86 (January 27, 2026) - TABLE EXTRACTION & AIR-GAPPED DEPLOYMENT

### What Was Added
1. **table_processor.py** - Extracts roles from RACI matrices and responsibility tables in PDFs/DOCX
2. **Automated setup.bat** - One-click development environment setup
3. **Air-gapped deployment** - Complete offline installation support

### Package Structure
```
TechWriterReview/
├── setup.bat                    # Run this for development setup
├── deployment/
│   ├── package_for_distribution.bat  # Creates offline installer
│   └── install.bat              # Air-gapped installation
├── table_processor.py           # NEW - PDF/DOCX table extraction
├── role_integration.py          # Updated - uses table_processor
├── role_extractor_v3.py         # Existing - regex-based extraction
└── ...
```

### Development Workflow
```batch
# Development (with internet)
1. Unzip TWR_v3_0_86_Complete.zip
2. Run setup.bat
3. Run start_twr.bat

# Creating distribution for others
1. Run deployment\package_for_distribution.bat
2. Give them dist\TWR_Distribution.zip
3. They run install.bat - no internet needed
```

### Key Design Decisions
- **pdfplumber over Docling**: 80MB vs 1.5GB, sufficient for structured tables
- **Graceful degradation**: Works without pdfplumber (just text extraction)
- **Confidence boost**: Roles found in tables get +15% confidence
- **No app.py changes**: All integration via role_integration.py

---

## Session: v3.0.85 (January 26, 2026) - ROLE EXPORT FIX (CONFIRMED WORKING)

### The Problem
"Export" button in Roles & Responsibilities Studio showed "No roles data to export" even when Role Details tab displayed 110 roles.

### Root Cause Discovery
Console log revealed: `button-fixes.js:102 [TWR] btn-export-roles-report clicked`
- Export button was handled by **button-fixes.js**, NOT roles.js
- All fixes to roles.js were being ignored
- Role Details tab gets data from `/api/roles/aggregated`, not window.State

### The Fix
Created `roles-export-fix.js` that:
1. Uses capture phase to intercept clicks BEFORE button-fixes.js
2. Fetches from `/api/roles/aggregated` (same API as Role Details)
3. Converts to CSV and downloads

### Lesson
**Check console logs to see which file actually handles an event.** Don't assume based on file names.

---

## Session: v3.0.76-79 (January 26, 2026) - GRAPH VISUALIZATION FIXES

### v3.0.76: Phantom Lines Fix
- **Problem**: Lines connecting to invisible nodes
- **Fix**: Iterative pruning - nodes need 2+ connections
- **Lesson**: Filter nodes AND links, then iterate until stable

### v3.0.77: Self-Explanatory Graph
- Added visible weak nodes with dashed outlines
- Added legend explaining node sizes and line types
- Role-Role links dashed, Role-Document links solid

### v3.0.78-79: Node Visibility
- Increased dimmed node opacity from 0.3 to 0.5
- Used `fill-opacity` instead of hex color opacity
- Minimum node size 10px for visibility

---

## Session: v3.0.75 (January 26, 2026) - ORPHAN NODES FIX

### The Problem
Faded circles appeared scattered around the canvas with no connections.

### Root Cause
Backend returns nodes based on `max_nodes` limit, but links might be filtered out.

### The Fix
Filter nodes to only include those with connections:
```javascript
const connectedNodeIds = new Set();
links.forEach(link => {
    connectedNodeIds.add(link.source.id || link.source);
    connectedNodeIds.add(link.target.id || link.target);
});
nodes = nodes.filter(n => connectedNodeIds.has(n.id));
```

---

## Session: v3.0.73-74 (January 26, 2026) - INFO PANEL + TICK HANDLER

### v3.0.73: Info Panel Buttons
- Pin/Close buttons weren't working
- Root cause: Module takeover pattern missed handlers
- Fix: Clone all button handlers in takeover code

### v3.0.74: Tick Handler Safety
- Added `isFinite()` checks on coordinates
- Hide invalid links with `display:none`
- Enhanced info panel with visual progress bars

---

## Session: v3.0.70-72 (January 26, 2026) - LAYOUT FIXES

### v3.0.70: Tab Content Display
- **Problem**: Tabs showed blank content
- **Fix**: Added `.roles-section { display: none }` and `.roles-section.active { display: block }`

### v3.0.71: Horizontal Tabs
- **Problem**: Vertical sidebar instead of horizontal tabs
- **Fix**: Changed `.roles-sidebar` to `flex-direction: row`

### v3.0.72: Full-Height Content
- **Problem**: Fixed heights caused white space
- **Fix**: Used `flex: 1` and `min-height` instead of fixed `height`

---

## ⚠️ MANDATORY: Version Update Checklist

**EVERY version bump MUST update ALL of these:**

| File | What to Update |
|------|----------------|
| `version.json` | `version`, `core_version`, add changelog entry |
| `help-docs.js` | Line 5, Line 17, About section, changelog HTML, console.log |
| `TWR_LESSONS_LEARNED.md` | Version at top, document the fix |
| `TWR_SESSION_HANDOFF.md` | Update current version |

---

## Known Patterns & Gotchas

### 1. Module Takeover Pattern
When fix modules take over from main modules, they MUST copy ALL handlers including click events.

### 2. getState() Priority
Always check `window.State` FIRST, not `window.TWR?.State?.State`.

### 3. Graph Filtering Order
1. Filter links (remove invalid endpoints)
2. Filter nodes (remove orphans)
3. Validate coordinates in tick handler

### 4. CSS !important
Modal content often needs `!important` to override inline styles and HTML attributes.

### 5. Event Handler Location
Check console logs to find which file actually handles an event - don't assume based on file names.

---

## File Structure Reference

```
TechWriterReview/
├── app.py                    # Main Flask application
├── core.py                   # Document processing engine
├── role_integration.py       # Role extraction integration layer
├── role_extractor_v3.py      # Regex-based role extraction
├── table_processor.py        # PDF/DOCX table extraction (v3.0.86)
├── scan_history.py           # Database for tracking scans
├── config_logging.py         # Logging configuration
├── pdf_extractor.py          # PDF text extraction
├── pdf_extractor_v2.py       # Enhanced PDF extraction
├── static/
│   ├── css/style.css
│   └── js/
│       ├── features/roles.js     # Role graph, RACI matrix
│       ├── roles-export-fix.js   # v3.0.85: Export functionality
│       ├── roles-tabs-fix.js     # Tab system
│       ├── button-fixes.js       # Button handlers
│       └── help-docs.js          # Help system + version
├── templates/index.html
├── setup.bat                 # Development setup (v3.0.86)
└── deployment/               # Air-gapped deployment (v3.0.86)
    ├── package_for_distribution.bat
    └── install.bat
```
