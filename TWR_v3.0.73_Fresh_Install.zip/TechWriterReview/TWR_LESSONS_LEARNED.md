# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.73

---

## Session: v3.0.73 (January 26, 2026) - GRAPH INFO PANEL BUTTON FIX + UPDATE MANAGER v1.2

### Issue 1: Graph Info Panel Buttons Not Working

**The Problem:** In the Relationship Graph tab, clicking a node shows an info panel in the top right. The panel has an X (close) button and a pin icon button, but neither worked.

**Root Cause:** When `roles-tabs-fix.js` took over graph control initialization in v3.0.63, it created its own `initGraphControls()` function but forgot to include handlers for `btn-pin-selection` and `btn-close-info-panel`.

**The Fix:** Added the missing handlers to `initGraphControls()` in `roles-tabs-fix.js`.

### Issue 2: Update Manager Missing File Type Support

**The Problem:** The built-in update system couldn't handle all file types and directory structures.

**Missing Support:**
- `.md` and `.ico` file extensions
- `static/js/ui/`, `static/js/api/`, `static/js/features/`, `static/js/utils/` flat-file routing
- `tools/` and `data/` directory routing
- `index.html` routed to app root instead of `templates/`
- `style.css` routed to app root instead of `static/css/`

**The Fix (update_manager.py v1.2):**
1. Added `.md` and `.ico` to supported extensions
2. Added flat-file prefixes: `static_js_ui_`, `static_js_api_`, `static_js_features_`, `static_js_utils_`
3. Added flat-file prefixes: `tools_`, `templates_`, `images_`, `data_`, `statement_forge_`
4. Fixed `index.html` special case to route to `templates/`
5. Fixed `style.css` special case to route to `static/css/`
6. Added directory routing for `tools/` and `data/`
7. Added skip for runtime directories (`logs/`, `temp/`, `backups/`)

### Lesson
**When taking over initialization from another module, audit ALL handlers in the original.**
**When building update systems, ensure ALL file types and directory structures are covered.**

---

## Session: v3.0.72 (January 26, 2026) - FULL HEIGHT CONTENT FIX

### The Problem
Tab content areas (Graph, Adjudication, RACI Matrix) had fixed heights or max-heights, leaving white space at the bottom of the modal.

### Root Causes
1. `.graph-container { height: 500px; }` - fixed height
2. `.adjudication-list { max-height: 400px; }` - constrained
3. `#responsibility-matrix { max-height: 400px; }` - constrained
4. SVG had `height="500"` HTML attribute

### The Fix
1. Changed `.roles-main` to flex container with `display: flex; flex-direction: column;`
2. Changed `.roles-section.active` to `display: flex !important` with `flex: 1`
3. Changed `.graph-container` to `flex: 1; min-height: 400px;` (not fixed)
4. Removed `max-height` constraints from content areas
5. Added `height: 100% !important` to SVG to override HTML attribute
6. Added flex rules for all tab sections

### Lesson
**For full-height content in modals:**
1. Use `display: flex; flex-direction: column;` on container
2. Use `flex: 1` on child elements that should expand
3. Use `min-height` instead of fixed `height`
4. Remove `max-height` constraints
5. Use `!important` on height to override HTML attributes
6. Add `min-height: 0` to allow flex shrinking

---

## Session: v3.0.71 (January 26, 2026) - HORIZONTAL TABS FIX

### The Problem
After v3.0.70 CSS fix, tabs displayed content but navigation was vertical sidebar instead of horizontal tabs.

### Root Cause
CSS had `.roles-sidebar { width: 220px; }` which forced vertical sidebar layout.
Additionally, responsive breakpoint at 1200px had `width: 200px` override.

### The Fix
Changed `.roles-sidebar` to:
- `width: 100%` (full width)
- `flex-direction: row` (horizontal layout)
- `display: flex` with horizontal alignment

Changed `.roles-nav-item` to:
- `width: auto` (not 100%)
- `white-space: nowrap` (prevent wrapping)
- Bottom border for active state (tab style)

Removed `width: 200px` from @media (max-width: 1200px) breakpoint.

### Lesson
**When converting sidebar to horizontal tabs:**
1. Remove fixed width constraints
2. Set flex-direction: row
3. Change nav items from width: 100% to width: auto
4. Use bottom borders for active indicators (not background)
5. Check ALL responsive breakpoints for conflicting rules

---

## Session: v3.0.70 (January 26, 2026) - CRITICAL CSS FIX

### The Problem
Roles & Responsibilities tabs showed blank content after v3.0.69 fresh install.

### Root Cause
v3.0.68 changed the JS to use `.active` class for section visibility:
```javascript
targetSection.classList.add('active');  // Instead of style.display = 'block'
```

But the **CSS rules that respond to this class were NEVER ADDED**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

### The Fix
Added the missing CSS rules to style.css (around line 2106).

### Lesson
**When changing JS from inline styles to class-based visibility, MUST add corresponding CSS rules.**

Always verify both sides of the equation:
1. JS adds/removes the class ✓
2. CSS responds to the class ✗ (was missing!)

---

## CRITICAL: End of Session Requirements

**At the end of EVERY development session, Claude must provide:**

1. **Complete Fresh Install ZIP** - A full `TWR_v3.0.XX_Fresh_Install.zip` containing:
   - All source files (Python backend, HTML templates, CSS, JS)
   - All fix modules that have been created
   - Updated version.json
   - Updated index.html with all script tags
   - This TWR_LESSONS_LEARNED.md file
   
2. **This ensures continuity** - The next chat session can start with a working, complete codebase rather than having to piece together multiple fixes.

---

## CRITICAL: Version Increment Checklist

**For EVERY version increment, update ALL of these files:**

| File | What to Update |
|------|----------------|
| `version.json` | version, release_date, core_version, add changelog entry |
| `help-docs.js` | Line 5 comment, line 17 version, line 18 lastUpdated, About section (version + build date), Version History section (add new entry), console.log at end |
| `TWR_LESSONS_LEARNED.md` | Version header, add session notes |
| `INSTALL.ps1` | Line 30 `$Version` variable |
| Any fix module headers | Update version in file comment header |

**help-docs.js locations to update:**
1. Line ~5: Comment header version
2. Line ~17: `version: 'X.X.XX'`
3. Line ~18: `lastUpdated: 'YYYY-MM-DD'`
4. Version History section: Add new `<div class="changelog-version changelog-current">` entry
5. About section: Version display and Build Date
6. Last line: `console.log('[HelpDocs] Module loaded vX.X.XX')`

**Failure to update help-docs.js causes version history gaps visible to users!**

---

## CRITICAL: Patch ZIP Structure

**Patches must mirror the app directory structure, NOT be flat files.**

**WRONG (flat structure):**
```
TWR_v3.0.69_Patch.zip
├── scan_history.py       ← User must manually place
├── roles-tabs-fix.js     ← User must manually place
├── help-docs.js          ← User must manually place
└── version.json          ← User must manually place
```

**CORRECT (mirrored structure):**
```
TWR_v3.0.69_Patch.zip
├── UPDATE.ps1            ← Automated installer script
└── TechWriterReview/
    ├── scan_history.py
    ├── version.json
    └── static/
        └── js/
            ├── roles-tabs-fix.js
            └── help-docs.js
```

**To create a proper patch:**
```bash
# Create structure mirroring app layout
mkdir -p patch/TechWriterReview/static/js

# Copy files to correct locations
cp scan_history.py patch/TechWriterReview/
cp version.json patch/TechWriterReview/
cp roles-tabs-fix.js patch/TechWriterReview/static/js/
cp help-docs.js patch/TechWriterReview/static/js/

# Include UPDATE.ps1 at root
cp UPDATE.ps1 patch/

# Create ZIP
cd patch && zip -r ../TWR_vX.X.XX_Patch.zip .
```

**UPDATE.ps1 applies patches to:** `$InstallPath/app/` (e.g., `C:\TWR\app\`)

---

## Smart Installer: INSTALL.ps1 v3.0.69

The installer now handles both fresh installs AND upgrades automatically.

### Upgrade Detection

When run, the installer:
1. Checks if `$InstallPath/app/` exists
2. Reads `version.json` to get current version
3. If found, prompts for upgrade confirmation

### User Data Preserved During Upgrades

| File/Folder | Purpose |
|-------------|---------|
| `scan_history.db` | All scan history and role extractions |
| `role_dictionary_master.json` | Custom role dictionary |
| `config.json` | User settings |
| `backups/` | User backups folder |
| `data/` | User data folder |
| `*.db` | Any other database files |

### Upgrade Process

1. **Backup** - Copies user data to `$InstallPath/upgrade_backup_YYYYMMDD-HHMMSS/`
2. **Remove** - Deletes old `app/` folder and `.venv/`
3. **Install** - Fresh copy from ZIP
4. **Restore** - Copies user data back to new installation
5. **Verify** - Checks critical files and directory structure

### Parameters

| Parameter | Purpose |
|-----------|---------|
| `-InstallPath "D:\TWR"` | Custom install location |
| `-ForceClean` | Delete all user data (no backup) |
| `-SkipCleanup` | Keep installer files after install |

---

## Session: v3.0.69 (January 26, 2026) - Responsibility Count Display Fix

### THE PROBLEM

**Overview tab "Top Roles by Responsibility Count" section was displaying incorrect data:**
1. Document tag showed total scan count (11) instead of unique document count
2. Right-side number showed `total_mentions` instead of actual responsibility count
3. Sorting was based on mentions, not responsibilities

### THE FIX

**Backend (scan_history.py):**
- Modified `get_all_roles()` to return two new fields:
  - `unique_document_count`: Count of deduplicated documents
  - `responsibility_count`: Sum of responsibilities from `responsibilities_json` across all document_roles
- Used `GROUP_CONCAT(DISTINCT d.filename)` for proper deduplication
- Parse and count JSON responsibilities from concatenated `responsibilities_json` data

**Frontend (roles-tabs-fix.js):**
- Updated tag to show: `${uniqueDocCount} unique doc${uniqueDocCount !== 1 ? 's' : ''}`
- Updated right-side to show: `${respCount}` with tooltip
- Changed sorting: primary by `responsibility_count`, secondary by `unique_document_count`
- Updated summary cards to sum `responsibility_count` instead of `total_mentions`

### Key Insight

The database stores responsibilities as JSON in `document_roles.responsibilities_json`. Each entry is an array of responsibility objects. To get total responsibility count per role, we must:
1. Concatenate all `responsibilities_json` entries for that role across documents
2. Parse each JSON chunk
3. Sum the array lengths

---

## Session: v3.0.68 (January 26, 2026) - FINAL FIX: CSS !important Override

### THE ACTUAL ROOT CAUSE ✅

**The Problem:** Tabs showed blank white boxes despite JavaScript rendering content correctly.

**Discovery Process:**
1. v3.0.66: Added fadeIn keyframes - didn't fix it
2. v3.0.67: Tried re-applying display:block after render - didn't fix it
3. Diagnostic script revealed the truth:
   ```
   Inline style display: block     ← We set this correctly
   Computed display: none          ← But CSS overrides it!
   ```

**Root Cause:** CSS uses `!important` which **cannot be overridden by inline styles**:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

**The Fix:**
```javascript
// WRONG - gets overridden by !important
targetSection.style.display = 'block';

// CORRECT - matches the CSS rule
targetSection.classList.add('active');
```

### Critical CSS Specificity Lesson

**Inline styles DO NOT override `!important` CSS rules.**

Priority order (highest to lowest):
1. `!important` CSS rules
2. Inline styles (normally highest, but NOT vs !important)
3. ID selectors
4. Class selectors
5. Element selectors

When debugging visibility issues:
1. Check computed style vs inline style
2. If they differ, look for `!important` in CSS rules
3. Match what the CSS expects (classes, not inline styles)

### Diagnostic Script That Found It

```javascript
const section = document.getElementById('roles-overview');
console.log('Inline style display:', section.style.display);
console.log('Computed display:', getComputedStyle(section).display);

const rules = [];
for (const sheet of document.styleSheets) {
    try {
        for (const rule of sheet.cssRules) {
            if (rule.selectorText?.includes('roles-section')) {
                rules.push({selector: rule.selectorText, display: rule.style.display});
            }
        }
    } catch(e) {}
}
console.log('CSS rules:', rules);
```

---

## Session: v3.0.66 (January 25, 2026) - CSS Animation Fix

Added missing `@keyframes fadeIn` - good fix but not the main visibility issue.

---

## Session: v3.0.65 (January 24, 2026) - Graph Controls Fixed

Fixed all graph control dropdowns, search, slider, and buttons.

---

## Key Development Patterns

### 1. Section Visibility
Use `classList.add('active')` not `style.display` - CSS uses `!important` rules.

### 2. Modal Visibility  
Use `modal.classList.add('active')` for pointer-events.

### 3. Control Initialization
Use `_tabsFixInitialized` flag to prevent duplicate handlers.

### 4. API Namespace
Export functions via `window.TWR.RolesTabs = {...}`.

### 5. File Locations

| File Type | Production Location |
|-----------|---------------------|
| Python backend | TechWriterReview/*.py |
| HTML templates | TechWriterReview/templates/*.html |
| CSS | TechWriterReview/static/css/*.css |
| JavaScript | TechWriterReview/static/js/*.js |
| Fix modules | TechWriterReview/static/js/*-fix.js |

---

## Fix Modules Added Since v3.0.52

| Module | Version | Purpose |
|--------|---------|---------|
| button-fixes.js | v3.0.52 | Missing button handlers |
| run-state-fixes.js | v3.0.53 | Run state updates |
| history-fixes.js | v3.0.54b | Scan history rendering |
| update-functions.js | v3.0.52 | Update system helpers |
| roles-dictionary-fix.js | v3.0.52 | Dictionary tab functionality |
| roles-tabs-fix.js | v3.0.73 | Tab switching + graph info panel buttons |
