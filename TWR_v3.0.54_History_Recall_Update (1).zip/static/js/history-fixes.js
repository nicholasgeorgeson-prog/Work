/**
 * TechWriterReview History Tab Fix + Scan Recall
 * ===============================================
 * Fixes the History tab in top nav not loading data, and adds
 * the ability to recall/load previous scan results.
 * 
 * Version: 3.0.54
 * 
 * Features:
 * 1. Loads history data when History tab is clicked
 * 2. Adds "Load" button to recall previous scans
 * 3. Shows storage statistics
 * 4. Displays recalled scans with visual indicator
 */

(function() {
    'use strict';
    
    console.log('[TWR] Loading history-fixes v3.0.54...');
    
    let initAttempts = 0;
    const maxAttempts = 50;
    
    // Track if we're viewing a recalled scan
    let isViewingRecalledScan = false;
    let recalledScanInfo = null;
    
    function initHistoryFixes() {
        initAttempts++;
        
        const navHistory = document.getElementById('nav-history');
        
        if (!navHistory) {
            if (initAttempts < maxAttempts) {
                setTimeout(initHistoryFixes, 100);
                return;
            }
            console.warn('[TWR] History fixes: nav-history button not found');
            return;
        }
        
        // Add capturing phase listener for loading data
        navHistory.addEventListener('click', async function(e) {
            console.log('[TWR] History tab clicked - loading data...');
            
            try {
                if (typeof window.loadScanHistory === 'function') {
                    await window.loadScanHistory();
                } else {
                    await fetchAndRenderHistory();
                }
            } catch (err) {
                console.error('[TWR] Error loading history:', err);
            }
        }, true);
        
        // Fix the refresh button
        const refreshBtn = document.getElementById('btn-refresh-history');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', async function() {
                try {
                    if (typeof window.loadScanHistory === 'function') {
                        await window.loadScanHistory();
                    } else {
                        await fetchAndRenderHistory();
                    }
                } catch (err) {
                    console.error('[TWR] Error refreshing history:', err);
                }
            });
        }
        
        // Add event delegation for Load buttons (will be added to table)
        const historyModal = document.getElementById('modal-scan-history');
        if (historyModal) {
            historyModal.addEventListener('click', async function(e) {
                const loadBtn = e.target.closest('[data-action="load-scan"]');
                if (loadBtn) {
                    const scanId = parseInt(loadBtn.dataset.scanId, 10);
                    const filename = loadBtn.dataset.filename;
                    if (scanId) {
                        await recallScan(scanId, filename);
                    }
                }
            });
        }
        
        // Expose functions globally
        window.recallScan = recallScan;
        window.clearRecalledScanBanner = clearRecalledScanBanner;
        
        console.log('[TWR] History fixes applied successfully');
    }
    
    /**
     * Fetch and render history data
     */
    async function fetchAndRenderHistory() {
        try {
            let response;
            if (typeof window.api === 'function') {
                response = await window.api('/scan-history', 'GET');
            } else {
                const res = await fetch('/api/scan-history');
                response = await res.json();
            }
            
            if (response && response.success && response.data) {
                renderHistoryTable(response.data);
            } else {
                showEmptyState();
            }
        } catch (err) {
            console.error('[TWR] Failed to fetch history:', err);
            showEmptyState();
        }
    }
    
    /**
     * Show empty state
     */
    function showEmptyState() {
        const emptyMsg = document.getElementById('scan-history-empty');
        const table = document.querySelector('.scan-history-table');
        if (emptyMsg) emptyMsg.style.display = 'block';
        if (table) table.style.display = 'none';
    }
    
    /**
     * Render history table with Load buttons
     */
    function renderHistoryTable(history) {
        const tbody = document.getElementById('scan-history-body');
        const emptyMsg = document.getElementById('scan-history-empty');
        const table = document.querySelector('.scan-history-table');
        
        if (!history || history.length === 0) {
            showEmptyState();
            return;
        }
        
        if (emptyMsg) emptyMsg.style.display = 'none';
        if (table) table.style.display = 'block';
        
        if (!tbody) {
            console.error('[TWR] scan-history-body not found');
            return;
        }
        
        tbody.innerHTML = history.map(scan => {
            const scanDate = new Date(scan.scan_time);
            const dateStr = scanDate.toLocaleDateString() + ' ' + 
                           scanDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            
            let changeHtml = '<span class="change-indicator unchanged">First scan</span>';
            if (scan.issues_added > 0 || scan.issues_removed > 0) {
                changeHtml = `
                    <span class="change-indicator added">+${scan.issues_added}</span>
                    <span class="change-indicator removed">-${scan.issues_removed}</span>
                `;
            }
            
            const filename = escapeHtml(scan.filename || '');
            const scanId = scan.scan_id || scan.id;
            
            return `
                <tr data-scan-id="${scanId}">
                    <td><strong>${filename}</strong></td>
                    <td>${dateStr}</td>
                    <td>${scan.issue_count}</td>
                    <td>${scan.score}</td>
                    <td><span class="grade-badge grade-${scan.grade}">${scan.grade}</span></td>
                    <td>${changeHtml}</td>
                    <td>
                        <div style="display: flex; gap: 4px;">
                            <button class="btn btn-ghost btn-sm" 
                                    data-action="load-scan"
                                    data-scan-id="${scanId}"
                                    data-filename="${filename}"
                                    title="Load this scan's results">
                                <i data-lucide="upload"></i>
                            </button>
                            <button class="btn btn-ghost btn-sm btn-delete-scan" 
                                    data-action="delete-scan"
                                    data-scan-id="${scanId}"
                                    data-filename="${filename}"
                                    title="Delete this scan">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
        
        // Refresh Lucide icons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
    }
    
    /**
     * Recall a scan from history
     */
    async function recallScan(scanId, filename) {
        console.log(`[TWR] Recalling scan ${scanId}: ${filename}`);
        
        // Show loading indicator
        if (typeof window.setLoading === 'function') {
            window.setLoading(true, 'Loading scan...');
        }
        
        try {
            let response;
            if (typeof window.api === 'function') {
                response = await window.api(`/scan-history/${scanId}/recall`, 'GET');
            } else {
                const res = await fetch(`/api/scan-history/${scanId}/recall`);
                response = await res.json();
            }
            
            if (response && response.success && response.data) {
                const scanData = response.data;
                
                // Close the history modal
                if (typeof window.hideModal === 'function') {
                    window.hideModal('modal-scan-history');
                } else {
                    const modal = document.getElementById('modal-scan-history');
                    if (modal) modal.classList.remove('show');
                }
                
                // Populate the UI with recalled results
                await populateRecalledScan(scanData);
                
                // Show success message
                if (typeof window.toast === 'function') {
                    window.toast('success', `Loaded scan from ${new Date(scanData.scan_time).toLocaleDateString()}`);
                }
                
            } else {
                const errorMsg = response?.error || 'Failed to recall scan';
                console.error('[TWR] Recall failed:', errorMsg);
                if (typeof window.toast === 'function') {
                    window.toast('error', errorMsg);
                } else {
                    alert(errorMsg);
                }
            }
        } catch (err) {
            console.error('[TWR] Error recalling scan:', err);
            if (typeof window.toast === 'function') {
                window.toast('error', 'Failed to load scan. The recall feature may not be available on this version.');
            } else {
                alert('Failed to load scan. Please ensure you have the latest backend update.');
            }
        } finally {
            if (typeof window.setLoading === 'function') {
                window.setLoading(false);
            }
        }
    }
    
    /**
     * Populate the UI with recalled scan data
     */
    async function populateRecalledScan(scanData) {
        console.log('[TWR] Populating recalled scan:', scanData.filename);
        
        const results = scanData.results;
        if (!results) {
            console.error('[TWR] No results in scan data');
            return;
        }
        
        // Store recalled scan info
        isViewingRecalledScan = true;
        recalledScanInfo = {
            scanId: scanData.scan_id,
            filename: scanData.filename,
            scanTime: scanData.scan_time
        };
        
        // Update filename display
        const filenameEl = document.getElementById('current-filename');
        if (filenameEl) {
            filenameEl.textContent = scanData.filename;
        }
        
        // Show the recalled scan banner
        showRecalledScanBanner(scanData);
        
        // Update summary stats
        updateSummaryStats(results);
        
        // Render issues
        if (results.issues && typeof window.renderIssues === 'function') {
            window.renderIssues(results.issues);
        } else if (results.issues) {
            // Fallback: try to render manually
            renderIssuesFallback(results.issues);
        }
        
        // Update score display
        if (results.score !== undefined) {
            const scoreEl = document.getElementById('quality-score');
            if (scoreEl) scoreEl.textContent = results.score;
            
            const gradeEl = document.getElementById('quality-grade');
            if (gradeEl) gradeEl.textContent = results.grade || '';
        }
        
        // Switch to review view
        const navReview = document.getElementById('nav-review');
        if (navReview) {
            navReview.click();
        }
    }
    
    /**
     * Show banner indicating we're viewing a historical scan
     */
    function showRecalledScanBanner(scanData) {
        // Remove existing banner if any
        clearRecalledScanBanner();
        
        const scanDate = new Date(scanData.scan_time);
        const dateStr = scanDate.toLocaleDateString() + ' ' + 
                       scanDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        const banner = document.createElement('div');
        banner.id = 'recalled-scan-banner';
        banner.className = 'recalled-scan-banner';
        banner.innerHTML = `
            <div class="recalled-scan-content">
                <i data-lucide="history" style="width:16px;height:16px;"></i>
                <span>Viewing historical scan from <strong>${dateStr}</strong></span>
                <button class="btn btn-sm btn-ghost" onclick="window.clearRecalledScanBanner()" title="Dismiss">
                    <i data-lucide="x" style="width:14px;height:14px;"></i>
                </button>
            </div>
        `;
        
        // Add styles if not present
        if (!document.getElementById('recalled-scan-styles')) {
            const styles = document.createElement('style');
            styles.id = 'recalled-scan-styles';
            styles.textContent = `
                .recalled-scan-banner {
                    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
                    color: white;
                    padding: 8px 16px;
                    position: sticky;
                    top: 0;
                    z-index: 100;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                }
                .recalled-scan-content {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    max-width: 1200px;
                    margin: 0 auto;
                }
                .recalled-scan-content .btn-ghost {
                    color: white;
                    margin-left: auto;
                }
                .recalled-scan-content .btn-ghost:hover {
                    background: rgba(255,255,255,0.1);
                }
            `;
            document.head.appendChild(styles);
        }
        
        // Insert at top of main content area
        const mainContent = document.querySelector('.main-content') || 
                           document.querySelector('.app-container') ||
                           document.body;
        mainContent.insertBefore(banner, mainContent.firstChild);
        
        // Refresh icons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
    }
    
    /**
     * Clear the recalled scan banner
     */
    function clearRecalledScanBanner() {
        const banner = document.getElementById('recalled-scan-banner');
        if (banner) {
            banner.remove();
        }
        isViewingRecalledScan = false;
        recalledScanInfo = null;
    }
    
    /**
     * Update summary statistics
     */
    function updateSummaryStats(results) {
        // Issue count
        const issueCountEl = document.getElementById('issue-count');
        if (issueCountEl) {
            issueCountEl.textContent = results.issue_count || (results.issues?.length || 0);
        }
        
        // Word count
        const wordCountEl = document.getElementById('word-count');
        if (wordCountEl && results.word_count) {
            wordCountEl.textContent = results.word_count.toLocaleString();
        }
        
        // Paragraph count
        const paraCountEl = document.getElementById('paragraph-count');
        if (paraCountEl && results.paragraph_count) {
            paraCountEl.textContent = results.paragraph_count;
        }
    }
    
    /**
     * Fallback issue renderer if window.renderIssues is not available
     */
    function renderIssuesFallback(issues) {
        const container = document.getElementById('issues-container') || 
                         document.getElementById('issues-list');
        if (!container) {
            console.warn('[TWR] Issues container not found');
            return;
        }
        
        if (!issues || issues.length === 0) {
            container.innerHTML = '<div class="empty-state">No issues found</div>';
            return;
        }
        
        container.innerHTML = issues.map((issue, idx) => `
            <div class="issue-card" data-index="${idx}">
                <div class="issue-header">
                    <span class="issue-type">${escapeHtml(issue.check_type || issue.type || 'Issue')}</span>
                    <span class="issue-severity severity-${(issue.severity || 'info').toLowerCase()}">${issue.severity || 'Info'}</span>
                </div>
                <div class="issue-message">${escapeHtml(issue.message || '')}</div>
                ${issue.context ? `<div class="issue-context">${escapeHtml(issue.context)}</div>` : ''}
            </div>
        `).join('');
    }
    
    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/[&<>"']/g, c => 
            ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
    }
    
    // Start initialization
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(initHistoryFixes, 200);
        });
    } else {
        setTimeout(initHistoryFixes, 200);
    }
    
})();

console.log('[TWR] History fixes module loaded v3.0.54');
