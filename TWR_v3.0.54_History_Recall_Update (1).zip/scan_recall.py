#!/usr/bin/env python3
"""
TechWriterReview Scan Recall Module
===================================
Provides API endpoint to recall/load previous scan results from history.

Version: 3.0.54

This module adds the ability to load historical scan results back into the UI,
allowing users to review past analyses without re-scanning documents.

The scan_history.py module already stores full results in results_json column,
this module provides the retrieval endpoint.
"""

import json
import sqlite3
from pathlib import Path
from flask import Blueprint, jsonify

# Create blueprint
scan_recall_bp = Blueprint('scan_recall', __name__, url_prefix='/api')

# Try to import scan history
SCAN_HISTORY_AVAILABLE = False
_scan_history_db = None

try:
    from scan_history import get_scan_history_db
    SCAN_HISTORY_AVAILABLE = True
except ImportError:
    pass


def get_scan_by_id(scan_id: int) -> dict:
    """
    Get full scan record including stored results.
    
    Args:
        scan_id: The ID of the scan to retrieve
        
    Returns:
        Dict with scan details and full results, or None if not found
    """
    if not SCAN_HISTORY_AVAILABLE:
        return None
    
    try:
        db = get_scan_history_db()
        db_path = db.db_path
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.id, d.filename, d.filepath, s.scan_time, 
                   s.issue_count, s.score, s.grade,
                   s.word_count, s.paragraph_count,
                   s.results_json, s.options_json
            FROM scans s
            JOIN documents d ON s.document_id = d.id
            WHERE s.id = ?
        ''', (scan_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            results_json = row[9]
            options_json = row[10]
            
            return {
                'scan_id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'scan_time': row[3],
                'issue_count': row[4],
                'score': row[5],
                'grade': row[6],
                'word_count': row[7],
                'paragraph_count': row[8],
                'results': json.loads(results_json) if results_json else None,
                'options': json.loads(options_json) if options_json else None
            }
        return None
        
    except Exception as e:
        print(f"[ScanRecall] Error retrieving scan {scan_id}: {e}")
        return None


@scan_recall_bp.route('/scan-history/<int:scan_id>/recall', methods=['GET'])
def recall_scan(scan_id):
    """
    Recall/retrieve full scan results for loading into UI.
    
    GET /api/scan-history/<scan_id>/recall
    
    Returns:
        JSON with success status and full scan data including results
    """
    if not SCAN_HISTORY_AVAILABLE:
        return jsonify({
            'success': False, 
            'error': 'Scan history module not available'
        }), 503
    
    scan_data = get_scan_by_id(scan_id)
    
    if scan_data:
        # Check if results were actually stored
        if scan_data.get('results') is None:
            return jsonify({
                'success': False,
                'error': 'Scan found but results were not stored. Only scans from v3.0+ store full results.',
                'scan_id': scan_id,
                'filename': scan_data.get('filename'),
                'scan_time': scan_data.get('scan_time')
            }), 404
        
        return jsonify({
            'success': True,
            'data': scan_data
        })
    
    return jsonify({
        'success': False,
        'error': f'Scan with ID {scan_id} not found'
    }), 404


@scan_recall_bp.route('/scan-history/stats', methods=['GET'])
def get_scan_stats():
    """
    Get scan history statistics for storage management.
    
    GET /api/scan-history/stats
    
    Returns:
        JSON with document count, scan count, and estimated storage size
    """
    if not SCAN_HISTORY_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'Scan history module not available'
        }), 503
    
    try:
        db = get_scan_history_db()
        db_path = db.db_path
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Count documents
        cursor.execute('SELECT COUNT(*) FROM documents')
        doc_count = cursor.fetchone()[0]
        
        # Count scans
        cursor.execute('SELECT COUNT(*) FROM scans')
        scan_count = cursor.fetchone()[0]
        
        # Estimate storage (sum of results_json lengths)
        cursor.execute('SELECT SUM(LENGTH(results_json)) FROM scans WHERE results_json IS NOT NULL')
        result = cursor.fetchone()[0]
        results_size = result if result else 0
        
        conn.close()
        
        # Get actual database file size
        db_file = Path(db_path)
        db_size = db_file.stat().st_size if db_file.exists() else 0
        
        return jsonify({
            'success': True,
            'data': {
                'document_count': doc_count,
                'scan_count': scan_count,
                'results_storage_bytes': results_size,
                'database_size_bytes': db_size,
                'results_storage_mb': round(results_size / (1024 * 1024), 2),
                'database_size_mb': round(db_size / (1024 * 1024), 2)
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def register_scan_recall_routes(app):
    """
    Register scan recall API routes with a Flask app.
    
    Usage in app.py:
        try:
            from scan_recall import register_scan_recall_routes
            register_scan_recall_routes(app)
        except ImportError:
            pass
    """
    app.register_blueprint(scan_recall_bp)
    print("[ScanRecall] Scan recall routes registered successfully")
