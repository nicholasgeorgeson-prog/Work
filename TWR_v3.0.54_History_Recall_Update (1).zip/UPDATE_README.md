# TechWriterReview v3.0.54 Update

## What's New
This update adds two features:
1. **History Tab Fix** - The History tab in the top nav now properly loads data when clicked
2. **Scan Recall** - You can now load/recall previous scan results from history

## Files Changed

| File | Change Type | Description |
|------|-------------|-------------|
| `scan_recall.py` | **NEW** | Backend module with recall endpoint |
| `app.py` | Modified | Added 9 lines to register scan_recall routes |
| `static/js/history-fixes.js` | **NEW** | Frontend fixes + recall UI |
| `templates/index.html` | Modified | Added script tag for history-fixes.js |
| `version.json` | Modified | Version bump to 3.0.54 |

## How Scan Recall Works

1. Your scan results are already being stored in the database (since v3.0+)
2. The new `/api/scan-history/<scan_id>/recall` endpoint retrieves stored results
3. Click the upload icon (⬆) next to any scan in History to load it
4. A blue banner appears indicating you're viewing a historical scan

## API Endpoints Added

### GET /api/scan-history/{scan_id}/recall
Returns full scan results for loading into UI.

**Response:**
```json
{
  "success": true,
  "data": {
    "scan_id": 123,
    "filename": "document.docx",
    "scan_time": "2026-01-23T10:30:00",
    "results": { /* full scan results */ },
    "options": { /* scan options used */ }
  }
}
```

### GET /api/scan-history/stats
Returns storage statistics.

**Response:**
```json
{
  "success": true,
  "data": {
    "document_count": 15,
    "scan_count": 47,
    "database_size_mb": 2.5
  }
}
```

## Installation

1. Extract ZIP contents to `C:\TWR\updates\` (files directly in updates folder, not in a subdirectory)
2. Open TechWriterReview and click the Update button
3. Apply the update and restart when prompted

## Rollback

If anything goes wrong:
1. Go to Settings > Updates > Backups
2. Select the most recent backup
3. Click Rollback

## Compatibility

- Requires TechWriterReview v3.0.52 or later
- Scan recall only works for scans made with v3.0+ (earlier versions didn't store full results)
