@echo off
REM ============================================================================
REM TechWriterReview - Air-Gapped Installer
REM ============================================================================
REM Run this on the target machine to install TWR and all dependencies.
REM No internet connection required.
REM ============================================================================
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo TechWriterReview v3.0.86 - Installer
echo ============================================================
echo.

REM Check Python version
python --version 2>nul | findstr "3.12" >nul
if errorlevel 1 (
    echo ERROR: Python 3.12 is required but not found.
    echo.
    echo Please install Python 3.12:
    echo   1. Download from python.org
    echo   2. During install, check "Add Python to PATH"
    echo   3. Run this installer again
    echo.
    pause
    exit /b 1
)

echo [OK] Python 3.12 detected
echo.

REM Get script directory (where TWR files are)
set SCRIPT_DIR=%~dp0

REM Check for wheels
if not exist "%SCRIPT_DIR%wheels" (
    echo ERROR: wheels folder not found.
    echo Make sure you extracted the complete distribution package.
    pause
    exit /b 1
)

echo [OK] Package files found
echo.

REM ============================================================================
REM Get installation path
REM ============================================================================
echo Where would you like to install TechWriterReview?
echo.
echo Default: C:\TWR
echo.
set /p INSTALL_PATH="Enter path (or press Enter for default): "

if "%INSTALL_PATH%"=="" set INSTALL_PATH=C:\TWR

echo.
echo Installing to: %INSTALL_PATH%
echo.

REM Create directory if needed
if not exist "%INSTALL_PATH%" (
    mkdir "%INSTALL_PATH%"
    if errorlevel 1 (
        echo ERROR: Could not create directory. Try running as Administrator.
        pause
        exit /b 1
    )
    echo [OK] Created installation directory
)

REM ============================================================================
REM Install Python packages
REM ============================================================================
echo.
echo ============================================================
echo Installing Python packages...
echo ============================================================
echo This may take a few minutes.
echo.

echo [1/4] Installing pdfplumber...
pip install --no-index --find-links="%SCRIPT_DIR%wheels" pdfplumber 2>nul
if errorlevel 1 pip install --no-index --find-links="%SCRIPT_DIR%wheels" --user pdfplumber

echo [2/4] Installing python-docx...
pip install --no-index --find-links="%SCRIPT_DIR%wheels" python-docx 2>nul
if errorlevel 1 pip install --no-index --find-links="%SCRIPT_DIR%wheels" --user python-docx

echo [3/4] Installing spaCy...
pip install --no-index --find-links="%SCRIPT_DIR%wheels" spacy 2>nul
if errorlevel 1 pip install --no-index --find-links="%SCRIPT_DIR%wheels" --user spacy

echo [4/4] Installing spaCy English model...
pip install --no-index --find-links="%SCRIPT_DIR%wheels" en_core_web_sm 2>nul
if errorlevel 1 pip install --no-index --find-links="%SCRIPT_DIR%wheels" --user en_core_web_sm

REM ============================================================================
REM Verify package installation
REM ============================================================================
echo.
echo Verifying packages...
echo.

set PACKAGES_OK=1

python -c "import pdfplumber" 2>nul
if errorlevel 1 (echo   [FAIL] pdfplumber & set PACKAGES_OK=0) else (echo   [OK] pdfplumber)

python -c "from docx import Document" 2>nul
if errorlevel 1 (echo   [FAIL] python-docx & set PACKAGES_OK=0) else (echo   [OK] python-docx)

python -c "import spacy" 2>nul
if errorlevel 1 (echo   [FAIL] spacy & set PACKAGES_OK=0) else (echo   [OK] spacy)

python -c "import spacy; spacy.load('en_core_web_sm')" 2>nul
if errorlevel 1 (echo   [FAIL] en_core_web_sm & set PACKAGES_OK=0) else (echo   [OK] en_core_web_sm)

if %PACKAGES_OK%==0 (
    echo.
    echo WARNING: Some packages failed. Try running as Administrator.
)

REM ============================================================================
REM Copy application files
REM ============================================================================
echo.
echo ============================================================
echo Installing TechWriterReview files...
echo ============================================================
echo.

REM Copy Python files
copy /Y "%SCRIPT_DIR%app.py" "%INSTALL_PATH%\" >nul && echo   [OK] app.py
copy /Y "%SCRIPT_DIR%scan_history.py" "%INSTALL_PATH%\" >nul && echo   [OK] scan_history.py
copy /Y "%SCRIPT_DIR%role_integration.py" "%INSTALL_PATH%\" >nul && echo   [OK] role_integration.py
copy /Y "%SCRIPT_DIR%role_extractor_v3.py" "%INSTALL_PATH%\" >nul && echo   [OK] role_extractor_v3.py
copy /Y "%SCRIPT_DIR%table_processor.py" "%INSTALL_PATH%\" >nul && echo   [OK] table_processor.py
copy /Y "%SCRIPT_DIR%version.json" "%INSTALL_PATH%\" >nul && echo   [OK] version.json
copy /Y "%SCRIPT_DIR%README.md" "%INSTALL_PATH%\" >nul && echo   [OK] README.md

REM Copy static files
if exist "%SCRIPT_DIR%static" (
    xcopy /E /I /Y /Q "%SCRIPT_DIR%static" "%INSTALL_PATH%\static\" >nul && echo   [OK] static/
)

REM Copy templates
if exist "%SCRIPT_DIR%templates" (
    xcopy /E /I /Y /Q "%SCRIPT_DIR%templates" "%INSTALL_PATH%\templates\" >nul && echo   [OK] templates/
)

REM Copy docs
if exist "%SCRIPT_DIR%docs" (
    xcopy /E /I /Y /Q "%SCRIPT_DIR%docs" "%INSTALL_PATH%\docs\" >nul && echo   [OK] docs/
)

REM ============================================================================
REM Test role extraction
REM ============================================================================
echo.
echo ============================================================
echo Testing role extraction...
echo ============================================================
echo.

pushd "%INSTALL_PATH%"
python -c "from role_integration import RoleIntegration; r = RoleIntegration(); s = r.get_status(); print('  Available:', s['available']); print('  spaCy NLP:', s['spacy_available']); print('  Table extraction:', s['table_processor_available'])" 2>nul
if errorlevel 1 (
    echo   [WARNING] Role extraction test failed
    echo   The application may still work - try starting it.
) else (
    echo.
    echo   [OK] Role extraction working!
)
popd

REM ============================================================================
REM Create start script
REM ============================================================================
echo.
echo Creating start script...

(
echo @echo off
echo cd /d "%INSTALL_PATH%"
echo echo Starting TechWriterReview...
echo echo.
echo echo Open your browser to: http://localhost:5000
echo echo Press Ctrl+C to stop the server.
echo echo.
echo python app.py
echo pause
) > "%INSTALL_PATH%\start_twr.bat"

echo   [OK] start_twr.bat

REM ============================================================================
REM Create desktop shortcut (optional)
REM ============================================================================
set /p CREATE_SHORTCUT="Create desktop shortcut? (Y/N): "
if /i "%CREATE_SHORTCUT%"=="Y" (
    set DESKTOP=%USERPROFILE%\Desktop
    
    (
    echo [InternetShortcut]
    echo URL=file:///%INSTALL_PATH:\=/%/start_twr.bat
    echo IconIndex=0
    ) > "%DESKTOP%\TechWriterReview.url"
    
    echo   [OK] Desktop shortcut created
)

REM ============================================================================
REM Summary
REM ============================================================================
echo.
echo ============================================================
echo Installation Complete!
echo ============================================================
echo.
echo TechWriterReview installed to: %INSTALL_PATH%
echo.
echo To start TechWriterReview:
echo   1. Open Command Prompt
echo   2. cd %INSTALL_PATH%
echo   3. python app.py
echo   4. Open browser to http://localhost:5000
echo.
echo Or run: %INSTALL_PATH%\start_twr.bat
echo.
echo Features enabled:
echo   - Document review and compliance checking
echo   - Role extraction with NLP (spaCy)
echo   - Table extraction from PDFs
echo   - RACI matrix generation
echo.
pause
