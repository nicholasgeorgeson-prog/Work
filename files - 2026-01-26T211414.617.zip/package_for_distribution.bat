@echo off
REM ============================================================================
REM TechWriterReview - Distribution Packager
REM ============================================================================
REM Run this on a CONNECTED Windows machine to create a distributable package
REM that includes all dependencies for air-gapped installation.
REM
REM Output: TWR_v3_0_86_Distribution.zip (ready to transfer and install)
REM ============================================================================
setlocal enabledelayedexpansion

echo.
echo ============================================================
echo TechWriterReview - Distribution Packager
echo ============================================================
echo.
echo This creates a complete package for air-gapped deployment.
echo Requirements: Python 3.12, pip, internet connection
echo.

REM Check Python version
python --version 2>nul | findstr "3.12" >nul
if errorlevel 1 (
    echo ERROR: Python 3.12 is required but not found.
    echo Please install Python 3.12 and add it to PATH.
    pause
    exit /b 1
)

echo [OK] Python 3.12 detected
echo.

REM Get script directory
set SCRIPT_DIR=%~dp0
set TWR_ROOT=%SCRIPT_DIR%..

REM Create output directory
set OUTPUT_DIR=%TWR_ROOT%\dist
set PACKAGE_NAME=TWR_v3_0_86_Distribution

if exist "%OUTPUT_DIR%\%PACKAGE_NAME%" (
    echo Removing existing package...
    rmdir /s /q "%OUTPUT_DIR%\%PACKAGE_NAME%"
)

mkdir "%OUTPUT_DIR%"
mkdir "%OUTPUT_DIR%\%PACKAGE_NAME%"
mkdir "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels"

echo Created output directory: %OUTPUT_DIR%\%PACKAGE_NAME%
echo.

REM ============================================================================
REM Download Python dependencies
REM ============================================================================
echo ============================================================
echo Downloading Python dependencies...
echo ============================================================
echo.

echo [1/4] Downloading spaCy and dependencies...
pip download spacy -d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels" --only-binary=:all: --python-version 3.12 --platform win_amd64 2>nul
if errorlevel 1 (
    echo Trying without platform restriction...
    pip download spacy -d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels"
)

echo.
echo [2/4] Downloading pdfplumber...
pip download pdfplumber -d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels" --only-binary=:all: --python-version 3.12 --platform win_amd64 2>nul
if errorlevel 1 (
    pip download pdfplumber -d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels"
)

echo.
echo [3/4] Downloading python-docx...
pip download python-docx -d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels"

echo.
echo [4/4] Downloading spaCy English model...
curl -L -o "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels\en_core_web_sm-3.8.0-py3-none-any.whl" https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl
if errorlevel 1 (
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl' -OutFile '%OUTPUT_DIR%\%PACKAGE_NAME%\wheels\en_core_web_sm-3.8.0-py3-none-any.whl'"
)

REM ============================================================================
REM Copy TWR application files
REM ============================================================================
echo.
echo ============================================================
echo Copying TWR application files...
echo ============================================================
echo.

REM Core Python files
copy "%TWR_ROOT%\app.py" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] app.py
copy "%TWR_ROOT%\scan_history.py" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] scan_history.py
copy "%TWR_ROOT%\role_integration.py" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] role_integration.py
copy "%TWR_ROOT%\role_extractor_v3.py" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] role_extractor_v3.py
copy "%TWR_ROOT%\table_processor.py" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] table_processor.py
copy "%TWR_ROOT%\version.json" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] version.json

REM Static files
xcopy "%TWR_ROOT%\static" "%OUTPUT_DIR%\%PACKAGE_NAME%\static\" /E /I /Q >nul && echo   [OK] static/

REM Templates
xcopy "%TWR_ROOT%\templates" "%OUTPUT_DIR%\%PACKAGE_NAME%\templates\" /E /I /Q >nul && echo   [OK] templates/

REM Documentation
xcopy "%TWR_ROOT%\docs" "%OUTPUT_DIR%\%PACKAGE_NAME%\docs\" /E /I /Q >nul && echo   [OK] docs/
copy "%TWR_ROOT%\README.md" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] README.md

REM Copy install script
copy "%SCRIPT_DIR%install.bat" "%OUTPUT_DIR%\%PACKAGE_NAME%\" >nul && echo   [OK] install.bat

REM ============================================================================
REM Create package README
REM ============================================================================
echo.
echo Creating package documentation...

(
echo # TechWriterReview v3.0.86 - Distribution Package
echo.
echo ## Quick Install
echo.
echo 1. Extract this folder to the target machine
echo 2. Open Command Prompt as Administrator
echo 3. Navigate to this folder
echo 4. Run: install.bat
echo.
echo ## What's Included
echo.
echo - Complete TWR application
echo - All Python dependencies ^(wheels/^)
echo - Role extraction with NLP support
echo - Table extraction from PDFs
echo.
echo ## Requirements
echo.
echo - Windows 10/11
echo - Python 3.12
echo - No internet connection needed
echo.
echo ## After Installation
echo.
echo Start TWR with: python app.py
echo Open browser to: http://localhost:5000
) > "%OUTPUT_DIR%\%PACKAGE_NAME%\README.md"

echo   [OK] README.md

REM ============================================================================
REM Create ZIP archive
REM ============================================================================
echo.
echo ============================================================
echo Creating distribution archive...
echo ============================================================
echo.

cd "%OUTPUT_DIR%"

REM Try PowerShell compression
powershell -Command "Compress-Archive -Path '%PACKAGE_NAME%\*' -DestinationPath '%PACKAGE_NAME%.zip' -Force" 2>nul
if errorlevel 1 (
    echo PowerShell compression failed, trying tar...
    tar -a -c -f "%PACKAGE_NAME%.zip" "%PACKAGE_NAME%"
)

if exist "%PACKAGE_NAME%.zip" (
    echo [OK] Created: %OUTPUT_DIR%\%PACKAGE_NAME%.zip
) else (
    echo [WARNING] Could not create ZIP. Package is in: %OUTPUT_DIR%\%PACKAGE_NAME%\
)

REM ============================================================================
REM Summary
REM ============================================================================
echo.
echo ============================================================
echo Packaging Complete!
echo ============================================================
echo.
echo Distribution package: %OUTPUT_DIR%\%PACKAGE_NAME%.zip
echo.

REM Count wheels
for /f %%a in ('dir /b /a-d "%OUTPUT_DIR%\%PACKAGE_NAME%\wheels\*.whl" 2^>nul ^| find /c /v ""') do set WHEEL_COUNT=%%a
echo   Wheels included: %WHEEL_COUNT%

REM Get size
for %%A in ("%OUTPUT_DIR%\%PACKAGE_NAME%.zip") do set SIZE=%%~zA
set /a SIZE_MB=%SIZE% / 1048576
echo   Package size: ~%SIZE_MB% MB
echo.
echo To distribute:
echo   1. Copy %PACKAGE_NAME%.zip to the target machine
echo   2. Extract and run install.bat
echo.
pause
