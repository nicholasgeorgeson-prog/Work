TechWriterReview Update - v3.0.50 Patch 1
=========================================

Fixed: "showNodeInfoPanel is not defined" error

INSTALLATION:
1. Copy ALL files from this folder to: C:\TWR\updates\
   (Keep the folder structure: static/js/features/roles.js.txt)

2. Open TechWriterReview in your browser

3. Go to Settings (gear icon) → Updates tab

4. Click "Check for Updates" - you should see 1 file

5. Click "Apply Updates"

6. Hard refresh browser (Ctrl+Shift+R)

Done!
