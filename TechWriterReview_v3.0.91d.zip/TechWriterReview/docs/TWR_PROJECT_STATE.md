# TechWriterReview - Project State
## Version: 3.0.91 (January 27, 2026)

---

## Project Overview

**TechWriterReview (TWR)** is a Flask-based document analysis tool for technical writers working in government contracting and aerospace documentation environments. It's designed for **air-gapped Windows networks** with no internet access.

### Core Capabilities
- **Document Analysis**: Grammar, compliance, spelling, punctuation checking
- **Role Extraction**: Identifies roles, responsibilities, and organizational entities from documents
- **RACI Matrix Generation**: Automatically generates RACI matrices from document content
- **Relationship Graph**: D3.js visualization showing role-document relationships
- **Statement Forge**: 1000+ action verbs for technical writing assistance
- **Scan History**: Tracks document scans and aggregates roles across documents
- **Docling Integration** (v3.0.91): Advanced AI-powered document extraction

### Technology Stack
- **Backend**: Python 3.x, Flask
- **Frontend**: Vanilla JS, D3.js, Chart.js, Lucide icons
- **Database**: SQLite (scan_history.db)
- **Document Processing**: Docling (preferred), python-docx, pdfplumber, PyMuPDF
- **AI Models**: Docling layout/table models (optional)

---

## Installation Path

```
C:\TWR\
├── app\                    # Application files (TechWriterReview folder)
├── updates\                # Extract update ZIPs here
├── backups\                # Automatic backups before updates
└── logs\                   # Application logs
```

### Quick Start
1. Extract `TWR_v3_0_90_Complete.zip` to `C:\TWR\app\`
2. Run `setup.bat` to create virtual environment
3. Run `python app.py` to start server
4. Open `http://localhost:5000` in browser

---

## Current Version Features (v3.0.90)

### Relationship Graph
| Feature | Status | Notes |
|---------|--------|-------|
| Iterative pruning | ✅ | Nodes need MIN 2 connections |
| Dashed role-role lines | ✅ | Purple (#7c3aed), dashArray 6,3 |
| Solid role-document lines | ✅ | Blue (#4A90D9) |
| Distinct link colors | ✅ | 8 link types with unique colors |
| Dimmed node visibility | ✅ | Opacity 0.5 (was 0.3) |
| Dimmed label visibility | ✅ | Opacity 0.4 (was 0) |
| Dimmed link visibility | ✅ | Opacity 0.3 (was 0.1) |
| Min node size | ✅ | 10px minimum |
| Performance mode | ✅ | Activates >50 nodes |

### Export Functionality
| Feature | Status | Notes |
|---------|--------|-------|
| Export dropdown | ✅ | In Roles Studio header |
| Export All Roles (CSV) | ✅ | Aggregated from all documents |
| Export Current Doc (CSV) | ✅ | From current session |
| Export All Roles (JSON) | ✅ | Full data export |
| roles-export-fix.js | ✅ | Loaded in index.html |

### Backend APIs
| Endpoint | Purpose |
|----------|---------|
| `/api/roles/aggregated` | All roles across all documents |
| `/api/roles/export` | Session-based role export |
| `/api/scan-history/document/<id>/roles` | Per-document roles |
| `/api/graph-data` | Graph nodes and links |

---

## File Structure

```
TechWriterReview/
├── app.py                      # Main Flask application
├── scan_history.py             # Database + role aggregation
├── role_extractor_v3.py        # Pattern-based role extraction
├── role_integration.py         # Combines table + text extraction
├── table_processor.py          # RACI table extraction (PDF/DOCX)
├── config_logging.py           # Centralized logging config
├── version.json                # Version info
│
├── static/
│   ├── css/style.css          # All styles (10,900+ lines)
│   └── js/
│       ├── features/roles.js   # Roles + Graph (2,500+ lines)
│       ├── roles-tabs-fix.js   # Tab navigation fixes
│       ├── roles-export-fix.js # Export button handler
│       ├── help-docs.js        # Help documentation
│       └── vendor/             # D3, Chart.js, Lucide
│
├── templates/
│   └── index.html             # Main UI (2,800+ lines)
│
├── statement_forge/           # Action verbs module
├── deployment/                # Air-gapped install scripts
└── tools/                     # PowerShell utilities
```

---

## Key Constants (roles.js)

```javascript
// Graph pruning
const MIN_CONNECTIONS = 2;  // Nodes need 2+ connections

// Link styles (v3.0.77+)
const LINK_STYLES = {
    'role-role': { dashArray: '6,3', color: '#7c3aed' },      // Dashed purple
    'role-document': { dashArray: 'none', color: '#4A90D9' }, // Solid blue
    'role-deliverable': { dashArray: '8,4', color: '#F59E0B' },
    'approval': { dashArray: '4,4', color: '#EC4899' },
    // ...
};

// Performance thresholds
const GRAPH_PERFORMANCE = {
    nodeThreshold: 50,
    linkThreshold: 100,
    glowThreshold: 40
};
```

---

## Recent Development History

| Version | Date | Key Changes |
|---------|------|-------------|
| 3.0.90 | Jan 27 | Comprehensive merge of all v3.0.76-89 fixes |
| 3.0.86 | Jan 26 | table_processor.py, deployment scripts |
| 3.0.85 | Jan 26 | roles-export-fix.js module |
| 3.0.80 | Jan 26 | Export dropdown with All/Current/JSON |
| 3.0.79 | Jan 26 | CSS dimmed opacity fixes |
| 3.0.77 | Jan 26 | Dashed lines for role-role, legend |
| 3.0.76 | Jan 26 | Iterative pruning, Document Log fix |
| 3.0.75 | Jan 26 | Orphan nodes filter |
| 3.0.74 | Jan 26 | Dangling links fix |
| 3.0.73 | Jan 26 | Pin/Close buttons, update manager |

---

## Known Issues / Future Work

1. **Role consolidation**: Similar roles (e.g., "Engineer" vs "Engineers") not yet merged
2. **Multi-document comparison**: Not yet implemented
3. **Role dictionary export**: Team sharing workflow incomplete
4. **Graph export**: PNG/SVG export not implemented

---

## Testing Checklist

After installation, verify:

- [ ] Help → About shows version 3.0.90
- [ ] Review a document → roles extracted
- [ ] Open Roles & Responsibilities Studio
- [ ] Graph shows nodes with dashed (role-role) and solid (role-document) lines
- [ ] Click Export button → dropdown appears with 3 options
- [ ] Export All Roles (CSV) → downloads file
- [ ] Select a node → other nodes dim but remain visible
- [ ] Console shows `[TWR Graph] Pruned in X iterations...`

---

## Contact / Support

This tool is developed for internal use at SAIC/Northrop Grumman. For issues, use the thumbs down button in Claude.ai to provide feedback, or document issues in TWR_LESSONS_LEARNED.md.
