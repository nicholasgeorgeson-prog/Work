@echo off
REM ============================================================================
REM TechWriterReview - Optional NLP Enhancement Setup
REM ============================================================================
REM
REM This script installs OPTIONAL packages that improve TWR's accuracy:
REM - spaCy: Named Entity Recognition (+15% role detection accuracy)
REM - PyMuPDF: Better PDF text extraction with font analysis
REM - textstat: Advanced readability metrics
REM - pdf2image: Required for OCR of scanned PDFs
REM - language-tool-python: Enhanced grammar checking
REM
REM None of these are required - TWR works without them.
REM Install what you need based on your documents.
REM
REM ============================================================================

echo.
echo ============================================================
echo TechWriterReview - Optional Enhancement Setup
echo ============================================================
echo.
echo This installs OPTIONAL packages for improved accuracy.
echo TWR works without these - only install what you need.
echo.
echo Available enhancements:
echo   1. spaCy         - Better role detection (+15%% accuracy)
echo   2. PyMuPDF       - Better PDF text extraction
echo   3. textstat      - Advanced readability metrics
echo   4. pdf2image     - OCR for scanned PDFs
echo   5. ALL           - Install everything
echo   6. SKIP          - Don't install anything
echo.

set /p CHOICE="Enter choice (1-6): "

if "%CHOICE%"=="6" goto :done
if "%CHOICE%"=="1" goto :spacy
if "%CHOICE%"=="2" goto :pymupdf
if "%CHOICE%"=="3" goto :textstat
if "%CHOICE%"=="4" goto :pdf2image
if "%CHOICE%"=="5" goto :all

echo Invalid choice.
goto :done

:spacy
echo.
echo Installing spaCy and English model...
pip install spacy --user
python -m spacy download en_core_web_sm
echo [OK] spaCy installed
goto :done

:pymupdf
echo.
echo Installing PyMuPDF...
pip install pymupdf --user
echo [OK] PyMuPDF installed
goto :done

:textstat
echo.
echo Installing textstat...
pip install textstat --user
echo [OK] textstat installed
goto :done

:pdf2image
echo.
echo Installing pdf2image for OCR support...
pip install pdf2image --user
echo.
echo NOTE: You also need to install Poppler for pdf2image to work:
echo   Windows: Download from https://github.com/osber/poppler-windows/releases
echo            Extract and add bin folder to PATH
echo   Mac: brew install poppler
echo   Linux: apt install poppler-utils
echo.
echo [OK] pdf2image installed (Poppler still needed)
goto :done

:all
echo.
echo Installing all optional enhancements...
echo.

echo [1/5] Installing spaCy...
pip install spacy --user
python -m spacy download en_core_web_sm

echo [2/5] Installing PyMuPDF...
pip install pymupdf --user

echo [3/5] Installing textstat...
pip install textstat --user

echo [4/5] Installing pdf2image...
pip install pdf2image --user

echo [5/5] Installing language-tool-python...
pip install language-tool-python --user

echo.
echo ============================================================
echo All enhancements installed!
echo ============================================================
echo.
echo NOTE: For OCR (pdf2image), you also need Poppler:
echo   Windows: https://github.com/osber/poppler-windows/releases
echo   Mac: brew install poppler
echo   Linux: apt install poppler-utils
echo.
echo NOTE: For Tesseract OCR:
echo   Windows: https://github.com/UB-Mannheim/tesseract/wiki
echo   Mac: brew install tesseract
echo   Linux: apt install tesseract-ocr
echo.
goto :done

:done
echo.
echo Setup complete. Restart TWR to use new features.
pause
