# TechWriterReview v3.0.91

Document analysis and review tool for technical writers in aerospace and government contracting.

## Quick Start

### Basic Setup (With Internet)

```batch
1. Unzip this package
2. Double-click: setup.bat
3. Double-click: start_twr.bat
4. Open browser to: http://localhost:5000
```

That's it! `setup.bat` installs all dependencies automatically.

### Optional: Enhanced Extraction with Docling AI

For superior document parsing with AI-powered table recognition:

```batch
# After basic setup:
setup_docling.bat
```

This installs Docling (~2.7GB) with:
- AI table structure recognition (95% vs 70% accuracy)
- Layout understanding and reading order preservation
- Section/heading detection without style dependencies
- 100% offline operation after setup

### Air-Gapped Deployment (No Internet)

For machines without internet access:

```batch
# On a machine WITH internet:
1. Run: powershell -ExecutionPolicy Bypass -File bundle_for_airgap.ps1
2. Wait for downloads (~3GB with Docling, ~500MB without)
3. Copy the bundle folder to target machine

# On the AIR-GAPPED machine:
1. Run: INSTALL_AIRGAP.bat
2. Follow prompts
```

## Features

- **Document Review**: Analyze technical documents for compliance, grammar, and consistency
- **Role Extraction**: Automatically identify roles and responsibilities using pattern matching
- **AI Table Detection**: Extract roles from RACI matrices with AI-powered recognition (Docling)
- **RACI Matrix Generation**: Build responsibility matrices from extracted data
- **Scan History**: Track document reviews over time
- **Statement Forge**: Generate compliant requirement statements
- **100% Offline**: Operates on air-gapped networks with no data leaving your machine

## File Structure

```
TechWriterReview/
├── app.py                    # Main Flask application
├── core.py                   # Document processing engine
├── role_integration.py       # Role extraction integration (v2.6.0)
├── role_extractor_v3.py      # Pattern-based role extraction
├── docling_extractor.py      # AI document extraction (v1.1.0)
├── table_processor.py        # PDF/DOCX table extraction
├── scan_history.py           # Database for tracking scans
├── setup.bat                 # Development setup script
├── setup_docling.bat         # Docling installation script
├── bundle_for_airgap.ps1     # Air-gap deployment packaging
├── static/                   # CSS, JavaScript
├── templates/                # HTML templates
└── TWR_LESSONS_LEARNED.md    # Development patterns & fixes
```

## Requirements

- Python 3.10+ (3.12 recommended)
- Windows 10/11 (for batch scripts)
- ~200 MB disk space (base installation)
- ~2.7 GB additional disk space (with Docling)

## Air-Gap Security

TechWriterReview is designed for sensitive environments:

- **No network calls** during document processing
- **Docling offline mode**: Environment variables block all network access
- **Local AI models**: All AI runs on your machine
- **No telemetry**: Analytics and tracking disabled

## Version History

See `version.json` for complete changelog.

### v3.0.91 (2026-01-27)
- NEW: Docling AI integration for superior document extraction
- NEW: Air-gapped deployment with bundle_for_airgap.ps1
- NEW: Memory optimization (image processing disabled)
- NEW: /api/docling/status endpoint
- IMPROVED: Role extraction with table confidence boosting

### v3.0.90 (2026-01-27)
- MERGED: All fixes from v3.0.76-v3.0.89 consolidated
- INCLUDES: Graph visualization improvements
- INCLUDES: Export dropdown with All/Current/JSON options

### v3.0.86 (2026-01-27)
- Added table extraction from PDFs/DOCX
- Added automated setup.bat for development
- Added air-gapped deployment support

## Support

For issues or questions, see `TWR_LESSONS_LEARNED.md` for known patterns and fixes.

Access in-app help: Click Help → Documentation or press F1.
