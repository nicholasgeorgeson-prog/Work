# TechWriterReview v3.0.68 - Deployment Instructions

## Files to Deploy

| File | Destination | Description |
|------|-------------|-------------|
| `style.css` | `static/css/style.css` | Contains fadeIn keyframes fix |
| `roles-tabs-fix.js` | `static/js/roles-tabs-fix.js` | Contains .active class fix for tab visibility |
| `version.json` | `static/version.json` or root | Version tracking |

## What Was Fixed

**Issue:** Overview, Role Details, RACI Matrix, Cross-Reference, and Document Log tabs showed blank white boxes.

**Root Cause:** The CSS uses `!important` rules:
```css
#modal-roles .roles-section { display: none !important; }
#modal-roles .roles-section.active { display: block !important; }
```

The JavaScript was setting `style.display = 'block'` but inline styles **cannot override** `!important` CSS rules.

**Solution:** Changed JavaScript to use `classList.add('active')` instead of inline display styles.

## After Deployment

1. Hard refresh your browser (Ctrl+Shift+R or Cmd+Shift+R)
2. Open the Roles & Responsibilities Studio
3. All tabs should now display content correctly

## Console Verification

You should see in the console:
```
[TWR RolesTabs] Loading v3.0.68 (.active class fix)...
[TWR RolesTabs] Activated section: roles-overview
```
