/**
 * TechWriterReview - Roles Tabs Fix (Robust Version)
 * v3.0.55c - Direct tab handling and content rendering
 * 
 * ISSUES FIXED:
 * 1. Tabs not switching properly
 * 2. No data loading when State.roles is empty
 * 3. Missing empty states for tabs without data
 */

(function() {
    'use strict';
    
    console.log('[TWR RolesTabs] Loading...');
    
    // Cache for API data
    const Cache = {
        aggregated: null,
        matrix: null,
        scanHistory: null
    };
    
    /**
     * Escape HTML special characters
     */
    function escapeHtml(str) {
        if (str == null) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    
    /**
     * Show toast notification
     */
    function showToast(type, message) {
        if (typeof window.toast === 'function') {
            window.toast(type, message);
        } else if (window.TWR?.Modals?.toast) {
            window.TWR.Modals.toast(type, message);
        } else {
            console.log(`[TWR ${type}] ${message}`);
        }
    }
    
    /**
     * Fetch aggregated roles from API
     */
    async function fetchAggregatedRoles() {
        if (Cache.aggregated !== null) return Cache.aggregated;
        
        try {
            const response = await fetch('/api/roles/aggregated?include_deliverables=true');
            const result = await response.json();
            
            if (result.success) {
                Cache.aggregated = result.data || [];
                console.log('[TWR RolesTabs] Loaded', Cache.aggregated.length, 'aggregated roles');
            } else {
                console.warn('[TWR RolesTabs] API returned error:', result.error);
                Cache.aggregated = [];
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Fetch error:', error);
            Cache.aggregated = [];
        }
        
        return Cache.aggregated;
    }
    
    /**
     * Fetch role-document matrix from API
     */
    async function fetchMatrix() {
        if (Cache.matrix !== null) return Cache.matrix;
        
        try {
            const response = await fetch('/api/roles/matrix');
            const result = await response.json();
            
            if (result.success) {
                Cache.matrix = result.data || {};
                console.log('[TWR RolesTabs] Loaded matrix data');
            } else {
                Cache.matrix = {};
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Matrix fetch error:', error);
            Cache.matrix = {};
        }
        
        return Cache.matrix;
    }
    
    /**
     * Fetch scan history from API
     */
    async function fetchScanHistory() {
        if (Cache.scanHistory !== null) return Cache.scanHistory;
        
        try {
            const response = await fetch('/api/scan-history?limit=50');
            const result = await response.json();
            
            if (result.success) {
                Cache.scanHistory = result.data || [];
                console.log('[TWR RolesTabs] Loaded', Cache.scanHistory.length, 'scan history items');
            } else {
                Cache.scanHistory = [];
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Scan history fetch error:', error);
            Cache.scanHistory = [];
        }
        
        return Cache.scanHistory;
    }
    
    /**
     * Create empty state HTML
     */
    function emptyState(icon, title, message) {
        return `
            <div class="empty-state" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;text-align:center;color:var(--text-muted);">
                <i data-lucide="${icon}" style="width:48px;height:48px;margin-bottom:16px;opacity:0.5;"></i>
                <h4 style="margin:0 0 8px 0;color:var(--text-secondary);">${title}</h4>
                <p style="margin:0;max-width:400px;">${message}</p>
            </div>
        `;
    }
    
    // =========================================================================
    // TAB RENDERERS
    // =========================================================================
    
    /**
     * Render Overview tab
     */
    async function renderOverview() {
        console.log('[TWR RolesTabs] Rendering Overview...');
        
        const roles = await fetchAggregatedRoles();
        const history = await fetchScanHistory();
        
        // Update stat cards
        const totalRoles = roles.length;
        const totalMentions = roles.reduce((sum, r) => sum + (r.total_mentions || 1), 0);
        const totalDocs = history.length || 1;
        
        // Get unique document count from roles
        const docsWithRoles = new Set();
        roles.forEach(r => {
            if (r.documents) {
                r.documents.forEach(d => docsWithRoles.add(d));
            }
        });
        
        // Update elements
        const els = {
            roles: document.getElementById('total-roles-count'),
            resp: document.getElementById('total-responsibilities-count'),
            docs: document.getElementById('total-documents-count'),
            interactions: document.getElementById('total-interactions-count'),
            sidebarRoles: document.getElementById('sidebar-roles-count'),
            sidebarResp: document.getElementById('sidebar-resp-count')
        };
        
        if (els.roles) els.roles.textContent = totalRoles;
        if (els.resp) els.resp.textContent = totalMentions;
        if (els.docs) els.docs.textContent = totalDocs;
        if (els.interactions) els.interactions.textContent = docsWithRoles.size;
        if (els.sidebarRoles) els.sidebarRoles.textContent = totalRoles;
        if (els.sidebarResp) els.sidebarResp.textContent = totalMentions;
        
        // Render top roles list
        const topRolesList = document.getElementById('top-roles-list');
        if (topRolesList) {
            if (roles.length > 0) {
                const sorted = [...roles].sort((a, b) => (b.total_mentions || 0) - (a.total_mentions || 0));
                topRolesList.innerHTML = sorted.slice(0, 10).map((role, i) => `
                    <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:var(--bg-secondary);border-radius:6px;margin-bottom:8px;">
                        <span style="font-weight:bold;color:var(--accent);min-width:24px;">${i + 1}</span>
                        <div style="flex:1;min-width:0;">
                            <div style="font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(role.role_name)}</div>
                            <div style="font-size:11px;color:var(--text-muted);">${role.category || 'Role'} · ${role.document_count || 1} docs</div>
                        </div>
                        <div style="font-size:14px;font-weight:600;color:var(--accent);">${role.total_mentions || 1}</div>
                    </div>
                `).join('');
            } else {
                topRolesList.innerHTML = `<p class="text-muted" style="padding:20px;text-align:center;">No roles found. Enable "Role Extraction" when scanning documents.</p>`;
            }
        }
        
        // Render distribution chart
        const chartContainer = document.getElementById('roles-distribution-chart');
        if (chartContainer && roles.length > 0) {
            const topRoles = roles.slice(0, 10);
            const maxVal = Math.max(...topRoles.map(r => r.total_mentions || 1));
            
            chartContainer.innerHTML = topRoles.map(role => {
                const pct = Math.max(5, ((role.total_mentions || 1) / maxVal * 100));
                const name = role.role_name.length > 20 ? role.role_name.slice(0, 18) + '...' : role.role_name;
                return `
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                        <span style="width:130px;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(role.role_name)}">${escapeHtml(name)}</span>
                        <div style="flex:1;height:18px;background:var(--bg-secondary);border-radius:3px;overflow:hidden;">
                            <div style="width:${pct}%;height:100%;background:var(--accent);transition:width 0.3s;"></div>
                        </div>
                        <span style="width:40px;text-align:right;font-size:12px;color:var(--text-muted);">${role.total_mentions || 1}</span>
                    </div>
                `;
            }).join('');
        } else if (chartContainer) {
            chartContainer.innerHTML = '<p class="text-muted text-center">No data for chart</p>';
        }
        
        refreshIcons();
    }
    
    /**
     * Render Details tab
     */
    async function renderDetails() {
        console.log('[TWR RolesTabs] Rendering Details...');
        
        const container = document.getElementById('roles-report-content');
        if (!container) return;
        
        const roles = await fetchAggregatedRoles();
        
        if (roles.length === 0) {
            container.innerHTML = emptyState('users', 'No Roles Found', 
                'Scan documents with "Role Extraction" enabled to detect organizational roles.');
            refreshIcons();
            return;
        }
        
        const sorted = [...roles].sort((a, b) => (b.document_count || 1) - (a.document_count || 1));
        
        container.innerHTML = sorted.map(role => `
            <div style="border:1px solid var(--border-default);border-radius:8px;padding:16px;margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:8px;">
                    <div>
                        <h4 style="margin:0 0 4px 0;">${escapeHtml(role.role_name)}</h4>
                        <span style="font-size:11px;padding:2px 8px;background:var(--bg-secondary);border-radius:4px;">${escapeHtml(role.category || 'Role')}</span>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:22px;font-weight:bold;color:var(--accent);">${role.document_count || 1}</div>
                        <div style="font-size:11px;color:var(--text-muted);">documents</div>
                    </div>
                </div>
                <div style="font-size:13px;color:var(--text-secondary);">
                    <strong>${role.total_mentions || 1}</strong> total mentions
                    ${role.documents && role.documents.length > 0 ? 
                        ` · Found in: ${role.documents.slice(0, 3).map(d => escapeHtml(d)).join(', ')}${role.documents.length > 3 ? '...' : ''}` : ''}
                </div>
            </div>
        `).join('');
    }
    
    /**
     * Render Matrix tab
     */
    async function renderMatrix() {
        console.log('[TWR RolesTabs] Rendering Matrix...');
        
        const container = document.getElementById('responsibility-matrix');
        if (!container) return;
        
        const matrix = await fetchMatrix();
        
        if (!matrix || !matrix.roles || Object.keys(matrix.roles).length === 0) {
            container.innerHTML = emptyState('grid-3x3', 'No Matrix Data',
                'Scan documents with "Role Extraction" enabled to generate the responsibility matrix.');
            refreshIcons();
            return;
        }
        
        const { documents = {}, roles = {}, connections = {} } = matrix;
        const docList = Object.entries(documents).slice(0, 8);
        const roleList = Object.entries(roles).slice(0, 15);
        
        if (roleList.length === 0 || docList.length === 0) {
            container.innerHTML = emptyState('grid-3x3', 'Insufficient Data', 'Not enough role-document relationships to display matrix.');
            refreshIcons();
            return;
        }
        
        let html = `
            <div style="overflow-x:auto;">
                <table style="width:100%;border-collapse:collapse;font-size:12px;">
                    <thead>
                        <tr>
                            <th style="text-align:left;padding:10px;border-bottom:2px solid var(--border-default);background:var(--bg-surface);position:sticky;left:0;min-width:140px;">Role</th>
                            ${docList.map(([id, name]) => {
                                const shortName = name.length > 12 ? name.slice(0, 10) + '...' : name;
                                return `<th style="padding:10px;border-bottom:2px solid var(--border-default);min-width:70px;max-width:100px;" title="${escapeHtml(name)}">${escapeHtml(shortName)}</th>`;
                            }).join('')}
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        roleList.forEach(([roleId, roleName]) => {
            html += `<tr>
                <td style="padding:10px;border-bottom:1px solid var(--border-default);background:var(--bg-surface);position:sticky;left:0;font-weight:500;">${escapeHtml(roleName)}</td>
            `;
            
            docList.forEach(([docId]) => {
                const count = connections[roleId]?.[docId] || 0;
                const style = count > 0 
                    ? 'background:var(--accent-subtle,#e3f2fd);color:var(--accent);font-weight:bold;' 
                    : 'color:var(--text-muted);';
                html += `<td style="padding:10px;text-align:center;border-bottom:1px solid var(--border-default);${style}">${count || '-'}</td>`;
            });
            
            html += '</tr>';
        });
        
        html += '</tbody></table></div>';
        
        const totalRoles = Object.keys(roles).length;
        const totalDocs = Object.keys(documents).length;
        if (totalRoles > 15 || totalDocs > 8) {
            html += `<p style="margin-top:12px;font-size:12px;color:var(--text-muted);">Showing ${Math.min(15, totalRoles)} of ${totalRoles} roles × ${Math.min(8, totalDocs)} of ${totalDocs} documents</p>`;
        }
        
        container.innerHTML = html;
    }
    
    /**
     * Render Adjudication tab
     */
    async function renderAdjudication() {
        console.log('[TWR RolesTabs] Rendering Adjudication...');
        
        const container = document.getElementById('adjudication-list');
        if (!container) return;
        
        const roles = await fetchAggregatedRoles();
        
        // Update stats
        const pendingEl = document.getElementById('adj-pending-count');
        const confirmedEl = document.getElementById('adj-confirmed-count');
        const deliverableEl = document.getElementById('adj-deliverable-count');
        const rejectedEl = document.getElementById('adj-rejected-count');
        
        if (pendingEl) pendingEl.textContent = roles.length;
        if (confirmedEl) confirmedEl.textContent = '0';
        if (deliverableEl) deliverableEl.textContent = '0';
        if (rejectedEl) rejectedEl.textContent = '0';
        
        if (roles.length === 0) {
            container.innerHTML = emptyState('check-circle', 'No Roles to Adjudicate',
                'Scan documents with "Role Extraction" enabled to detect roles for review.');
            refreshIcons();
            return;
        }
        
        container.innerHTML = roles.slice(0, 50).map(role => `
            <div class="adjudication-item" data-role="${escapeHtml(role.role_name)}" 
                 style="display:flex;align-items:center;gap:12px;padding:12px 16px;border:1px solid var(--border-default);border-radius:8px;margin-bottom:8px;transition:all 0.15s;">
                <input type="checkbox" class="adj-item-checkbox" style="width:18px;height:18px;">
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:500;margin-bottom:2px;">${escapeHtml(role.role_name)}</div>
                    <div style="font-size:12px;color:var(--text-muted);">
                        ${role.document_count || 1} docs · ${role.total_mentions || 1} mentions · 
                        <span style="padding:1px 6px;background:var(--bg-secondary);border-radius:3px;">${role.category || 'Role'}</span>
                    </div>
                </div>
                <div style="display:flex;gap:4px;">
                    <button class="btn btn-ghost btn-xs" title="Confirm as Role" style="color:var(--success);">
                        <i data-lucide="user-check"></i>
                    </button>
                    <button class="btn btn-ghost btn-xs" title="Mark as Deliverable" style="color:var(--info);">
                        <i data-lucide="package"></i>
                    </button>
                    <button class="btn btn-ghost btn-xs" title="Reject" style="color:var(--error);">
                        <i data-lucide="x-circle"></i>
                    </button>
                </div>
            </div>
        `).join('');
        
        if (roles.length > 50) {
            container.innerHTML += `<p style="text-align:center;color:var(--text-muted);font-size:12px;">Showing 50 of ${roles.length} roles</p>`;
        }
        
        refreshIcons();
    }
    
    /**
     * Render Documents tab
     */
    async function renderDocuments() {
        console.log('[TWR RolesTabs] Rendering Documents...');
        
        const tbody = document.getElementById('document-log-body');
        if (!tbody) {
            console.warn('[TWR RolesTabs] document-log-body not found');
            return;
        }
        
        const history = await fetchScanHistory();
        
        if (history.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">
                <i data-lucide="file-text" style="display:block;margin:0 auto 12px;width:32px;height:32px;opacity:0.5;"></i>
                No scan history. Open and scan documents to see them here.
            </td></tr>`;
            refreshIcons();
            return;
        }
        
        tbody.innerHTML = history.map(scan => {
            const date = new Date(scan.scan_time || scan.scanned_at || scan.created_at);
            const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            return `<tr>
                <td style="padding:10px;"><strong>${escapeHtml(scan.filename || 'Unknown')}</strong></td>
                <td style="padding:10px;">${dateStr}</td>
                <td style="padding:10px;text-align:center;">${scan.role_count ?? '-'}</td>
                <td style="padding:10px;text-align:center;">${scan.issue_count ?? '-'}</td>
                <td style="padding:10px;text-align:center;">${scan.grade || '-'}</td>
            </tr>`;
        }).join('');
    }
    
    /**
     * Refresh Lucide icons
     */
    function refreshIcons() {
        if (typeof lucide !== 'undefined' && lucide.createIcons) {
            try { lucide.createIcons(); } catch(e) { console.warn('Icon refresh failed:', e); }
        }
    }
    
    // =========================================================================
    // TAB SWITCHING
    // =========================================================================
    
    /**
     * Switch to a tab and render its content
     */
    async function switchToTab(tabName) {
        console.log('[TWR RolesTabs] === Switching to tab:', tabName, '===');
        
        // Update nav item active states
        const navItems = document.querySelectorAll('.roles-nav-item');
        console.log('[TWR RolesTabs] Updating', navItems.length, 'nav items');
        navItems.forEach(item => {
            const isActive = item.dataset.tab === tabName;
            item.classList.toggle('active', isActive);
            item.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
        
        // Hide ALL sections - remove active class and clear inline display
        const allSections = document.querySelectorAll('#modal-roles .roles-section');
        console.log('[TWR RolesTabs] Hiding', allSections.length, 'sections');
        allSections.forEach(section => {
            section.classList.remove('active');
            section.style.removeProperty('display'); // Let CSS handle it
        });
        
        // Show ONLY the target section by adding active class
        const targetSection = document.getElementById(`roles-${tabName}`);
        if (targetSection) {
            targetSection.classList.add('active');
            console.log('[TWR RolesTabs] Activated section: roles-' + tabName, 'classList:', targetSection.classList.toString());
        } else {
            console.warn('[TWR RolesTabs] Section not found: roles-' + tabName);
        }
        
        // Render tab content
        switch (tabName) {
            case 'overview':
                await renderOverview();
                break;
            case 'details':
                await renderDetails();
                break;
            case 'matrix':
                await renderMatrix();
                break;
            case 'adjudication':
                await renderAdjudication();
                break;
            case 'documents':
                await renderDocuments();
                break;
            case 'graph':
                // Graph uses its own renderer from roles.js
                if (typeof window.TWR?.Roles?.renderRolesGraph === 'function') {
                    window.TWR.Roles.renderRolesGraph();
                }
                break;
            case 'dictionary':
                // Dictionary uses our other fix
                if (typeof window.TWR?.DictFix?.loadDictionary === 'function') {
                    window.TWR.DictFix.loadDictionary();
                }
                break;
        }
        
        console.log('[TWR RolesTabs] === Tab switch complete ===');
    }
    
    /**
     * Initialize tab click handlers using event delegation
     * This is more robust than attaching to individual buttons
     */
    function initTabHandlers() {
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.warn('[TWR RolesTabs] modal-roles not found for tab handlers');
            return;
        }
        
        // Count nav items for debugging
        const navItems = modal.querySelectorAll('.roles-nav-item');
        console.log('[TWR RolesTabs] Found', navItems.length, 'nav items');
        
        // Remove any existing delegation handler
        if (modal._tabDelegationHandler) {
            modal.removeEventListener('click', modal._tabDelegationHandler, true);
        }
        
        // Create delegation handler
        modal._tabDelegationHandler = async function(e) {
            // Find if we clicked on a nav item or inside one
            const navItem = e.target.closest('.roles-nav-item');
            if (!navItem) return;
            
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            
            const tabName = navItem.dataset.tab;
            console.log('[TWR RolesTabs] Tab clicked:', tabName, 'element:', navItem);
            
            if (tabName) {
                await switchToTab(tabName);
            }
        };
        
        // Attach with capture phase to run before other handlers
        modal.addEventListener('click', modal._tabDelegationHandler, true);
        
        console.log('[TWR RolesTabs] Tab delegation handler attached to modal');
    }
    
    /**
     * Initialize when modal opens
     */
    function onModalOpen() {
        console.log('[TWR RolesTabs] Modal opened, loading initial data...');
        
        // Clear cache to get fresh data
        Cache.aggregated = null;
        Cache.matrix = null;
        Cache.scanHistory = null;
        
        // Render the overview tab (default)
        switchToTab('overview');
    }
    
    /**
     * Setup modal observer
     */
    function setupModalObserver() {
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.warn('[TWR RolesTabs] modal-roles not found');
            return;
        }
        
        // Watch for modal visibility changes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes') {
                    const isVisible = modal.style.display !== 'none' && 
                                     !modal.classList.contains('hidden') &&
                                     modal.offsetParent !== null;
                    
                    if (isVisible && !modal._rolesTabsLoaded) {
                        modal._rolesTabsLoaded = true;
                        onModalOpen();
                    } else if (!isVisible) {
                        modal._rolesTabsLoaded = false;
                    }
                }
            });
        });
        
        observer.observe(modal, { attributes: true, attributeFilter: ['style', 'class'] });
        
        // Also check if already visible
        if (modal.style.display !== 'none' && modal.offsetParent !== null) {
            onModalOpen();
        }
    }
    
    /**
     * Setup modal close handlers
     */
    function setupCloseHandlers() {
        const modal = document.getElementById('modal-roles');
        if (!modal) return;
        
        // Close button
        modal.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', function() {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            });
        });
        
        // Click outside to close (on the modal backdrop)
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            }
        });
        
        // Escape key to close
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.style.display !== 'none') {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            }
        });
    }
    
    // =========================================================================
    // INIT
    // =========================================================================
    
    function init() {
        initTabHandlers();
        setupModalObserver();
        setupCloseHandlers();
        console.log('[TWR RolesTabs] Fully initialized');
    }
    
    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Expose API
    window.TWR = window.TWR || {};
    window.TWR.RolesTabs = {
        switchToTab,
        renderOverview,
        renderDetails,
        renderMatrix,
        renderAdjudication,
        renderDocuments,
        fetchAggregatedRoles,
        fetchMatrix,
        fetchScanHistory
    };
    
    // =========================================================================
    // OVERRIDE: Allow opening Roles modal without a scan
    // The original showRolesModal() in roles.js blocks if State.roles is empty
    // =========================================================================
    
    /**
     * Show Roles modal - bypasses the "no roles detected" check
     */
    function showRolesModalOverride() {
        console.log('[TWR RolesTabs] Opening Roles modal (override)...');
        
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.error('[TWR RolesTabs] modal-roles not found');
            return;
        }
        
        // Ensure tab handlers are attached
        initTabHandlers();
        
        // Show the modal
        modal.style.display = 'flex';
        modal.classList.add('active');
        document.body.classList.add('modal-open');
        
        // Clear any inline display styles from sections
        // Let CSS control visibility via .active class
        modal.querySelectorAll('.roles-section').forEach(section => {
            section.style.removeProperty('display');
            section.classList.remove('active');
        });
        
        // Clear cache and trigger data load
        Cache.aggregated = null;
        Cache.matrix = null;
        Cache.scanHistory = null;
        modal._rolesTabsLoaded = true;
        
        // Switch to overview tab and load data
        switchToTab('overview');
        
        // Refresh icons
        refreshIcons();
    }
    
    /**
     * Override the global showRolesModal function
     */
    function installShowModalOverride() {
        // Override the global function
        window.showRolesModal = showRolesModalOverride;
        
        // Also override in TWR.Roles if it exists
        if (window.TWR?.Roles) {
            window.TWR.Roles.showRolesModal = showRolesModalOverride;
        }
        
        // Re-attach click handler to nav-roles button
        const navRoles = document.getElementById('nav-roles');
        if (navRoles) {
            // Remove any existing listeners by cloning
            const newNavRoles = navRoles.cloneNode(true);
            navRoles.parentNode.replaceChild(newNavRoles, navRoles);
            
            newNavRoles.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                showRolesModalOverride();
            });
            
            console.log('[TWR RolesTabs] nav-roles click handler installed');
        }
        
        // Also handle the footer button
        const btnRolesReport = document.getElementById('btn-roles-report');
        if (btnRolesReport) {
            // Enable the button
            btnRolesReport.disabled = false;
            btnRolesReport.removeAttribute('disabled');
            
            // Clone to remove existing handlers
            const newBtn = btnRolesReport.cloneNode(true);
            newBtn.disabled = false;
            btnRolesReport.parentNode.replaceChild(newBtn, btnRolesReport);
            
            newBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                showRolesModalOverride();
            });
            
            console.log('[TWR RolesTabs] btn-roles-report enabled and handler installed');
        }
        
        console.log('[TWR RolesTabs] showRolesModal override installed');
    }
    
    // Install override after a short delay to ensure other scripts have loaded
    setTimeout(installShowModalOverride, 100);
    
})();
