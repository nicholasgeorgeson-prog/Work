# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.97 (Final)

---

## 🔴 Session v3.0.97c - BATCH 4 ENHANCEMENTS & FINAL PACKAGING

### Summary
Completed Batch 4 optional enhancements and final packaging for v3.0.97 deployment.

### Enhancements Implemented (2026-01-28)

#### Issue 4.1: Sound Effects Discovery (DONE ✓)
- **Problem:** Sound effects disabled by default; users unaware feature exists
- **Solution:** Added sound toggle button (🔇/🔊) in FAV2 header
- **Added one-time tooltip** that appears first time modal opens (auto-dismisses after 8s)
- **Files:** `index.html`, `app.js`, `style.css`, `help-docs.js`

#### Issue 4.2: Progress Persistence Key Collision (DONE ✓)
- **Problem:** localStorage key `twr_fav2_${documentId}` used only filename, causing collisions
- **Solution:** Created `generateDocumentId()` function that generates unique hash from:
  - Filename
  - File type
  - Analysis timestamp
- **Key format:** `{filename}_{hash}` - now unique per review session
- **Files:** `app.js`

### Files Modified
- `templates/index.html` - Added sound toggle button to FAV2 header
- `static/js/app.js` - Sound toggle handler, sound discovery tooltip, unique document ID generation
- `static/css/style.css` - Sound tip tooltip animations
- `static/js/help-docs.js` - Updated documentation for sound toggle

### Testing Results
- ✓ Python syntax check: `app.py`, `fix_assistant_api.py`
- ✓ JavaScript syntax check: `app.js`, `help-docs.js`, all feature modules

### Deployment Package
- Created `TechWriterReview_v3.0.97_FINAL.zip`
- Excludes: `*.pyc`, `__pycache__`, `*.db`, `logs/*`, `temp/*`

---

## 🔴 CRITICAL: Session v3.0.97b - POST-INTEGRATION ANALYSIS

### Summary
Analysis of v3.0.97 revealed critical integration gaps: backend doesn't return FAV2 data fields, State.fixes never set, help docs not updated. **ALL CRITICAL ISSUES FIXED.**

### Issues Found & Fixed (2026-01-28)

#### BLOCKERS (FIXED ✓):
1. **State.fixes undefined** - FIXED: Added `State.fixes` assignment in app.js after State.issues is set (line ~1008)
2. **Backend missing FAV2 fields** - FIXED: Added calls to build_document_content(), group_similar_fixes(), etc. in `/api/review` and `/api/review/result/<job_id>` endpoints

#### HIGH (FIXED ✓):
3. Job-based review endpoint - FIXED: Same FAV2 enhancement added
4. Missing method stubs - FIXED: Added acceptCurrent, rejectCurrent, skipCurrent, etc. to FixAssistant public API

#### MEDIUM (FIXED ✓):
5. help-docs.js version - FIXED: Updated to v3.0.97
6. Changelog - FIXED: Added v3.0.97 entry with all new features

### Files Modified
- `app.py` - Added FAV2 data fields to review endpoints
- `static/js/app.js` - Added State.fixes assignment, added method stubs to FixAssistant
- `static/js/help-docs.js` - Updated version to 3.0.97, added changelog entry

### Root Cause
Integration focused on frontend module wiring but missed:
- Backend response enhancement
- State variable naming mismatch (fixes vs fixableIssues)
- Documentation updates

### See Also
- `/docs/FAV2_ISSUES_v3.0.97.md` - Original issue breakdown

---

## 🔴 CRITICAL: Session v3.0.97 - FIX ASSISTANT v2 INTEGRATION

### Summary
Major feature deployment: Fix Assistant v2 - complete premium document review interface with two-panel layout, undo/redo, pattern learning, and progress persistence.

### Task: Integrate 11 Work Package outputs into Fix Assistant v2

### What Worked

1. **Parallel Development Strategy**
   - Breaking the feature into independent work packages allowed parallel development
   - Each module had well-defined public APIs making integration straightforward
   - IIFE pattern used consistently across all modules

2. **State Management Architecture**
   - Centralized state in `FixAssistantState` with event-based communication
   - `onChange` and `onDecision` callbacks cleanly separate concerns
   - Undo/redo implemented at state level, not UI level

3. **Export Interface Preservation**
   - Existing `getSelectedFixes()` API preserved for backward compatibility
   - New `getRejectedFixes()` added without breaking existing code

4. **Module Load Order**
   - All modules have no hard dependencies on each other
   - Integration code initializes modules in correct order at runtime
   - Modules fail gracefully if containers not found

### What to Watch For

1. **DOCX vs PDF Page Handling**
   - PDF files have `page_map` populated
   - DOCX files may have empty `page_map` - code defaults to page 1
   - Test both file types explicitly

2. **State.fixes vs FixAssistantState**
   - Global `State.fixes` is the source of truth from review results
   - `FixAssistantState` wraps this for Fix Assistant operations
   - Don't modify `State.fixes` directly from Fix Assistant

3. **LocalStorage Keys**
   - Progress: `twr_fav2_${documentId}`
   - Sound preference: `twr_sounds_enabled`
   - Clear these during development/testing

4. **CSS Class Prefix**
   - All new classes use `fav2-` prefix
   - Never use unprefixed classes in new code
   - Avoids conflicts with existing TWR styles

5. **CSRF Token**
   - Learner/Report APIs need CSRF token
   - Code checks both `State.csrfToken` and meta tag
   - Verify token is available in air-gapped deployments

### Files Added
- `decision_learner.py` - Pattern learning SQLite database
- `report_generator.py` - PDF report generation (ReportLab)
- `fix_assistant_api.py` - Helper functions
- `static/js/features/document-viewer.js` - Page-based document rendering
- `static/js/features/minimap.js` - Visual document overview
- `static/js/features/fix-assistant-state.js` - State management
- `static/js/features/learner-client.js` - Pattern tracking API client
- `static/js/features/a11y-manager.js` - Accessibility features
- `static/js/features/sound-effects.js` - Optional audio feedback
- `static/js/features/preview-modes.js` - Live preview and split-screen
- `static/js/features/report-client.js` - PDF report client

### Files Modified
- `app.py` - Added Fix Assistant v2 routes and export enhancements
- `static/js/app.js` - Replaced FixAssistant module with v2 integration
- `static/css/style.css` - Appended Fix Assistant v2 CSS
- `templates/index.html` - Replaced modal, added script tags
- `version.json` - Updated to 3.0.97

### New API Endpoints
- `POST /api/learner/record` - Record review decisions
- `POST /api/learner/predict` - Get predictions
- `GET /api/learner/patterns` - Get learned patterns
- `POST /api/learner/patterns/clear` - Clear patterns
- `GET|POST|DELETE /api/learner/dictionary` - Manage custom dictionary
- `GET /api/learner/statistics` - Get learning stats
- `GET /api/learner/export` - Export learning data
- `POST /api/learner/import` - Import learning data
- `POST /api/report/generate` - Generate PDF report

### Key Features
- Two-panel document viewer with page navigation
- Mini-map showing fix locations
- Full undo/redo support
- Search and filter fixes
- Progress persistence (localStorage)
- Pattern learning from decisions
- Custom dictionary
- Live preview and split-screen modes
- PDF summary reports
- Accessibility: screen reader, high contrast
- Keyboard shortcuts throughout

---

## 🔴 CRITICAL: Session v3.0.95 - UI IMPROVEMENTS & CONSISTENCY

### Summary
User-requested improvements to version consistency, about section, hyperlink display, and heatmap interactivity.

### Changes Made

#### 1. Version Display Consistency
- Updated all version references to read from version.json dynamically
- Fixed hardcoded versions in help-docs.js (was 3.0.91d)
- About section now fetches version from /static/version.json on load
- Console log version updated

#### 2. About Section Simplified
- Removed titles and affiliations
- Now shows only: "Nicholas Georgeson"
- Build date and version display remain

#### 3. Hyperlink Status Panel (NEW)
- Added visual display of all checked hyperlinks
- Shows validation status (valid/invalid) with icons
- Color-coded: green for valid, red for invalid
- Collapsible list for documents with many links
- Summary shows count of valid/invalid/total

**Implementation:**
- `core.py`: Captures hyperlink validation results after checker runs
- `templates/index.html`: Added hyperlink-status-container div
- `static/js/app.js`: Added renderHyperlinkStatus() function
- `static/css/style.css`: Added hyperlink panel styles

#### 4. Heatmap Click-to-Filter Fixed
- Category × Severity heatmap now properly filters issues on click
- **Bug fixed**: Was calling `applyChartFilter()` which doesn't exist
- **Fix**: Now calls `setChartFilter('category', cat)` which exists
- Added toast feedback when filtering
- Added visual highlight on selected cell

### Files Modified
1. `version.json` - Updated to 3.0.95
2. `static/js/help-docs.js` - Version consistency, about section, version history
3. `static/js/app.js` - Fixed heatmap click, added hyperlink rendering
4. `static/js/ui/renderers.js` - Version comment update
5. `static/css/style.css` - Hyperlink panel styles, heatmap active state
6. `templates/index.html` - Added hyperlink status container
7. `core.py` - Capture hyperlink validation results

### Pattern: Dynamic Version Display
Rather than hardcoding version in multiple places:
```javascript
// Fetch version dynamically
fetch('/static/version.json')
    .then(r => r.json())
    .then(data => {
        document.getElementById('version-display').textContent = 'Version ' + data.version;
    });
```

---

## 🔴 CRITICAL: Session v3.0.94 - RICH CONTEXT FOR REVIEW ISSUES

### Summary
Implemented comprehensive rich context system for all review issues. Users requested that the "context" shown for flagged issues be more useful - specifically showing the full sentence, page number, and section header where available.

### Problem
- Context for issues was too minimal (e.g., just the acronym "NASA" with no surrounding text)
- No page number or section information shown
- Users couldn't tell WHERE in the document the issue occurred
- Different checkers had inconsistent context quality

### Solution Architecture

#### 1. New Module: `context_utils.py`
Created centralized context extraction utilities:
```python
from context_utils import ContextBuilder, enhance_issue_context

# Build rich context for any issue
ctx = ContextBuilder(paragraphs, page_map, headings)
rich = ctx.build_context(para_idx=5, flagged_text="NASA", match_start=42)
# Returns: {
#     'context': 'The «NASA» program will deliver...',
#     'sentence': 'The NASA program will deliver the payload by Q3.',
#     'page': 3,
#     'section': '2.1 Mission Overview',
#     'flagged_text': 'NASA'
# }
```

#### 2. PDF Page Mapping
Modified `pdf_extractor_v2.py` to track paragraph-to-page mapping:
```python
# Added to PDFExtractorV2.__init__:
self.page_map: Dict[int, int] = {}

# Populated when creating paragraphs:
self.page_map[para_idx] = block.page  # 1-indexed
```

#### 3. Core Integration
Updated `core.py` to:
- Pass `page_map` to checkers via `common_kwargs`
- Post-process all issues through `enhance_issue_context()`

#### 4. Frontend Rendering
Updated `renderers.js` to:
- Parse `«highlight»` markers and convert to `<mark>` tags
- Display page and section in location header
- Apply `context-highlight` CSS class

### Highlight Marker System
Backend uses special markers to indicate what should be highlighted:
- `«` = start of highlight
- `»` = end of highlight

Example: `"The «NASA» program will..."` renders with "NASA" highlighted.

### Files Modified
1. **NEW: `context_utils.py`** - Context extraction utilities (ContextBuilder, RichContext, etc.)
2. **`pdf_extractor_v2.py`** - Added page_map tracking for all extraction methods
3. **`core.py`** - Added page_map to common_kwargs, added context enhancement post-processing
4. **`static/js/ui/renderers.js`** - Added processContextWithHighlights(), location header rendering
5. **`static/css/style.css`** - Added context-highlight, context-location styles
6. **`version.json`** - Updated to 3.0.94

### Pattern: Centralized Context Enhancement
Rather than modifying each checker individually:
1. Checkers continue to create basic issues
2. Post-processing in `review_document()` enhances ALL issues with rich context
3. This approach:
   - Requires no changes to individual checkers
   - Ensures consistent context format
   - Allows future improvements in one place

### Testing Notes
- Page mapping works for PyMuPDF, pdfplumber, and pypdf extraction methods
- Section detection uses existing headings list
- Graceful fallback if context_utils not available (logs warning, continues)

---

## 🔴 CRITICAL: Session v3.0.92 - PDF EXTRACTION & CHECKER FALSE POSITIVE FIX

### Summary
Fixed major issues with document review causing thousands of false positives in punctuation checking and significant false positives in acronym detection.

### Test Results (Before → After)
| Checker | nasa_goddard_sow.pdf | nasa_sow_handbook.pdf |
|---------|---------------------|----------------------|
| Punctuation | 1,479 → **0** | 170 → **5** |
| Acronyms | 52 → **42** | 68 → **53** |

### Root Cause 1: PDF Text Extraction (CRITICAL)
**Location:** `pdf_extractor_v2.py` → `_clean_text()` method

**Problem:** Operations were in the wrong order:
```python
# BUGGY ORDER:
text = re.sub(r' +', ' ', text)  # Remove spaces FIRST
text = re.sub(r'\n(?!\n)', ' ', text)  # Convert newlines LATER → Creates NEW double spaces!
```

When text like `"word \n next"` was processed:
1. Multiple spaces removed → still `"word \n next"` 
2. Newline converted to space → `"word  next"` (double space!)

**Fix:** Reorder operations - remove multiple spaces LAST:
```python
# FIXED ORDER:
text = re.sub(r'-\s*\n\s*', '', text)  # Join hyphenated words
text = re.sub(r'\n(?!\n)', ' ', text)  # Convert newlines to spaces
text = re.sub(r' +', ' ', text)  # Remove multiple spaces LAST
```

### Root Cause 2: Acronym False Positives
**Location:** `acronym_checker.py` → `COMMON_CAPS_SKIP` set

**Problem 1:** Common title/header words missing from skip list:
- SERVICES, TECHNOLOGY, OMNIBUS, DIRECTORATE, ENGINEERING, etc.
- These appeared in ALL CAPS in PDF titles and were flagged as undefined acronyms

**Problem 2:** Well-known acronyms (NASA, ISO, FBI) only in `UNIVERSAL_SKIP`, not `COMMON_CAPS_SKIP`:
- In strict mode (`ignore_common_acronyms=False`), UNIVERSAL_SKIP is bypassed
- NASA was being flagged as "undefined" in strict mode

**Fix:** Added 100+ words to `COMMON_CAPS_SKIP`:
- Common document title words (SERVICES, TECHNOLOGY, ENGINEERING, etc.)
- Well-known government/org acronyms (NASA, FBI, ISO, IEEE, etc.)
- Common short words appearing in caps (OF, FOR, AND, THE, etc.)

### Root Cause 3: Missing PDF Hyperlink Extraction
**Location:** `pdf_extractor_v2.py` → `_extract_with_pymupdf()`

**Problem:** PDF embedded hyperlinks were not being extracted.

**Fix:** Added hyperlink extraction using PyMuPDF's `get_links()`:
```python
links = page.get_links()
for link in links:
    if link_type == 2:  # LINK_URI - external URL
        self.hyperlinks.append({'type': 'uri', 'target': link['uri']})
    elif link_type == 1:  # LINK_GOTO - internal page link
        self.hyperlinks.append({'type': 'internal', 'target': f"page:{link['page']}"})
```

### Files Modified
1. `pdf_extractor_v2.py`:
   - Fixed `_clean_text()` operation order
   - Added `hyperlinks` attribute
   - Added hyperlink extraction in `_extract_with_pymupdf()`

2. `acronym_checker.py`:
   - Added ~100 entries to `COMMON_CAPS_SKIP`
   - Common document words, well-known acronyms, short cap words

### Key Pattern: Order of Operations Matters
When cleaning text with multiple regex transformations, process in this order:
1. Remove special characters (soft hyphens, zero-width spaces, BOM)
2. Join hyphenated line breaks (`word-\n` → `word`)
3. Convert newlines to spaces
4. Remove multiple spaces **LAST**

### Validation
Tested against NASA technical documents:
- nasa_goddard_sow.pdf (64 pages, 14,623 words)
- nasa_sow_handbook.pdf (35 pages, 6,323 words)

Remaining flagged acronyms are legitimate undefined technical terms (GSE, RF, ASIC, etc.) that should be defined in documents.

---

## 🔴 CRITICAL: Session v3.0.91d - DOCUMENTATION OVERHAUL

### Summary
Comprehensive review and update of help-docs.js to ensure alignment with current codebase and functionality.

### Updates Applied
1. **Fixed version references** - All instances updated to 3.0.91d
2. **Fixed directory structure diagram** - Now shows flat layout with updates/backups inside TechWriterReview folder
3. **Fixed API Reference** - Added comprehensive documentation for all endpoints including roles, Statement Forge, and updates
4. **Added Role Extraction technical section** - Full documentation of role_extractor_v3.py including:
   - Extraction pipeline diagram
   - False positive prevention mechanisms
   - Known roles database (158 roles)
   - Performance metrics (94.7% precision)
   - Configuration options
5. **Fixed duplicate version history entries** - Removed duplicate v3.0.70 blocks
6. **Fixed orphaned HTML content** - Cleaned up malformed changelog entries
7. **Updated troubleshooting** - Correct log path references
8. **Added v3.0.91d to version history** with detailed changelog

### Files Updated
- `help-docs.js` - Complete documentation review and updates
- Navigation now includes `tech-roles` section

### Pattern for Documentation Updates
When updating documentation:
1. Search for all version string references
2. Check directory structure diagrams against actual codebase
3. Verify API endpoints exist and match signatures
4. Remove any duplicate or orphaned content
5. Update the version history with new entries at TOP

---

## 🔴 CRITICAL: Session v3.0.91d - UPDATE MANAGER PATH FIX

### Summary
Fixed critical bug where the update manager was non-functional due to hardcoded app folder path.

### Bug Identified
**Root Cause:** The `UpdateConfig` class hardcoded `self.app_dir = self.base_dir / "app"`, but the actual folder is named "TechWriterReview". This path mismatch caused:
1. Update files wouldn't route to correct destinations
2. Backups wouldn't be created in the right location
3. The entire update system was effectively broken

### Fixes Applied
1. **update_manager.py (UpdateConfig class):**
   - Added `app_dir` parameter to `__init__` for direct specification
   - Added `_find_app_dir()` method for auto-detection
   - Supports both flat mode (updates inside app folder) and nested mode
   - No longer hardcodes "app" as the folder name

2. **app.py (line ~173):**
   - Changed from `UpdateManager(config.base_dir.parent)` 
   - To `UpdateManager(base_dir=config.base_dir, app_dir=config.base_dir)`
   - This uses "flat mode" where updates/ lives inside the app folder

3. **Created missing folders:**
   - `updates/` folder with UPDATE_README.md
   - `backups/` folder with .gitkeep

4. **Updated help-docs.js:**
   - Expanded Settings → Updates documentation
   - Removed hardcoded `C:\TWR\` path references
   - Added documentation for all update methods

### Folder Structure (Flat Mode - Now Default)
```
TechWriterReview/
├── app.py
├── updates/                <- NEW: Drop update files here
│   └── UPDATE_README.md    <- NEW: Documentation
├── backups/                <- NEW: Auto-created before updates
│   └── .gitkeep
└── ...other files
```

### Key Pattern for Future Reference
When creating path-based systems, NEVER hardcode folder names. Always:
1. Accept paths as parameters
2. Provide auto-detection fallbacks
3. Log the resolved paths for debugging

```python
# BAD: Hardcoded
self.app_dir = self.base_dir / "app"

# GOOD: Configurable with auto-detection
def __init__(self, base_dir=None, app_dir=None):
    if app_dir:
        self.app_dir = Path(app_dir)
    else:
        self.app_dir = self._find_app_dir(base_dir)
```

---

## 🔴 CRITICAL: Session v3.0.91d - FALSE POSITIVE FILTERING BUG FIX

### Summary
Fixed critical bug where false positives were bypassing filtering due to check ordering and canonical name resolution.

### Bug Identified
**Root Cause:** False positives like "Verification Engineer" and "Mission Assurance" were being extracted despite being in the FALSE_POSITIVES set because:
1. The `_is_valid_role()` check for false_positives happened AFTER the `known_roles` check
2. The `_scan_for_known_roles()` method bypassed `_is_valid_role()` entirely when matching role aliases
3. Aliases like "Verification" → "Verification Engineer" caused canonical names to be extracted even when the canonical was in false_positives

### Fixes Applied
1. **Line ~817:** Moved false_positives check BEFORE known_roles check in `_is_valid_role()`
2. **Line ~1411:** Added false_positives check in `_scan_for_known_roles()` for raw known_role
3. **Line ~1430:** Added canonical form false_positives check after `_get_canonical_role()` resolution

### Final Validation Results (4-Document Test Suite)

| Document | Precision | Recall | F1 Score |
|----------|-----------|--------|----------|
| NASA ATOM-4 SOW | 100% | 85.71% | 92.31% |
| DoD SEP Outline | 100% | 87.50% | 93.33% |
| Smart Columbus SEMP | 100% | 100% | 100% |
| INCOSE/APM SEPM Guide | 84.62% | 84.62% | 84.62% |
| **OVERALL** | **94.74%** | **90.00%** | **92.31%** |

### Key Achievement
✅ **~95% Precision achieved** across diverse document types
- Government contracts (NASA SOW)
- Defense systems engineering (DoD SEP)
- Smart city/Agile projects (Smart Columbus)
- Industry standards (INCOSE/APM)

### False Positives Successfully Filtered
- "Mission Assurance" - BLOCKED
- "Verification Engineer" - BLOCKED  
- "Chief Innovation" - BLOCKED
- "Staffing Integrated Product Team" - BLOCKED

### Code Pattern for Future Reference
When adding false positive filtering, always check in this order:
1. Check explicit false_positives set FIRST (before any role matching)
2. After canonical name resolution, check canonical form against false_positives
3. Strong role suffixes should NOT override explicit false_positives

---

## 🔴 CRITICAL: Session v3.0.91c+ - 5-DOCUMENT COMPREHENSIVE TESTING

### Summary
Extended testing across 5 diverse document domains to validate role extraction accuracy and expand domain coverage.

### Test Results (5 Documents)

| Document Type | Roles Found | Key Roles Detected |
|--------------|-------------|-------------------|
| NASA-style SOW | 14 | CO, COR, Test Director, Program Manager |
| DoD SEP | 8 | Chief Engineer, LSE, IPT, Config Manager |
| Agile/IT Project | 15 | CTO, CISO, Scrum Master, Product Owner |
| Transportation | 2 | Operations Manager, Systems Integrator |
| Healthcare/Clinical | 12 | Medical Monitor, CRA, IRB, PI |

**Total: 51 roles across 5 documents (avg 10.2/doc)**

### Domain Expansions Added (v3.0.91c+)

**IT Security Domain:**
- chief information security officer, ciso
- security officer, information security officer
- cybersecurity analyst

**Healthcare/Clinical Domain:**
- medical monitor, medical director, clinical director
- study coordinator, clinical research associate (cra)
- data safety monitoring board, institutional review board
- ethics committee, sponsor medical director

**New Acronyms:**
- `ciso` → chief information security officer
- `cra` → clinical research associate
- `irb` → institutional review board
- `dsmb` → data safety monitoring board

### False Positive Prevention Verified
✅ "Test Readiness Review" - NOT detected (correct)
✅ "Progress" - NOT detected (correct)
✅ "Requirements" - NOT detected (correct)
✅ "Responsible for" - NOT detected (correct)

### Changelog Fixed
- Moved v3.0.91c/v3.0.91b entries to TOP of version history
- Removed duplicate entries at bottom
- Proper chronological ordering restored

---

## 🔴 CRITICAL: Session v3.0.91c - CROSS-DOCUMENT VERIFICATION

### Summary
Validated role extraction accuracy across different document types to ensure the improvements generalize.

### Test Results

**NASA SOW (Government Contract Document):**
| Metric | Result |
|--------|--------|
| Recall | 100% |
| Precision | 100% |
| F1 Score | 100% |
| False Positives | 0 |

**Smart Columbus SEMP (Systems Engineering Management Plan):**
| Metric | Result |
|--------|--------|
| Recall | 100% |
| Precision | 90% |
| False Positives | 3 (minor) |

### Additional Roles Added (v3.0.91c)
1. **Agile/Scrum roles**: scrum master, scrum team, product owner, product manager, agile team
2. **Executive roles**: chief innovation officer, cino, cto, cio, ceo, coo, cfo, deputy cino, deputy pgm
3. **IT roles**: it pm, information technology project manager, consultant, business owner
4. **Support roles**: stakeholder, subject matter expert, sponsor, coordinator

### Additional Acronyms Added
`cino`, `cto`, `cio`, `ceo`, `coo`, `cfo`, `pgm`, `dpgm`, `dba`, `sa`, `sysadmin`

### Additional Noise Patterns Fixed
- Added `responsible`, `accountable`, `serves`, `acting`, `works`, `reports`, `directly`, `overall` to noise_starters
- Added `for` to connector_words (catches "Responsible for..." patterns)

---

## 🔴 CRITICAL: Session v3.0.91b - ROLE EXTRACTION ACCURACY FIX

### Summary
Major accuracy improvements to role extraction through expanded false positive filtering.

### Before/After Metrics (NASA SOW Test Document)
| Metric | v3.0.91 | v3.0.91b |
|--------|---------|----------|
| Precision | 52% | **100%** |
| Recall | 96% | **94%** |
| F1 Score | 68% | **97%** |
| False Positives | 32 | **0** |

### Key Changes (role_extractor_v3.py)
1. **Expanded FALSE_POSITIVES list** - Added 50+ new entries:
   - Generic words: progress, upcoming, distinct, coordinating, etc.
   - Event names: test readiness review, design review, etc.
   - Facilities: panel test facility, flight facility, etc.
   - Processes: reliability centered maintenance, property management, etc.

2. **New SINGLE_WORD_EXCLUSIONS set** - Blocks single-word false positives:
   - Nouns: progress, work, test, task, plan, phase, etc.
   - Adjectives: technical, functional, operational, etc.
   - Verbs/gerunds: coordinating, managing, performing, etc.

3. **Enhanced _is_valid_role() method**:
   - Added valid_acronyms check before length validation (COR, PM, SE, etc.)
   - Added noise_starters rejection (the, a, contract, provide, etc.)
   - Added connector_words rejection in positions 2-4 (is, are, shall, etc.)
   - Added noise_endings rejection (begins, ends, various, etc.)

4. **Expanded KNOWN_ROLES list**:
   - Added: test manager, cor, contractor, customer, government, nasa
   - Added: test team, project team, technical team, etc.
   - Added: facility operators, shift engineers, etc.

---

## 🔴 CRITICAL: Session v3.0.91 - DOCLING INTEGRATION (Complete)

### Summary
Integrated Docling (IBM's open-source document parser) for AI-powered document extraction with **100% air-gapped operation** and **memory optimization** (images disabled).

### Key Files Created/Modified
| File | Purpose | Version |
|------|---------|---------|
| `docling_extractor.py` | Core Docling wrapper with offline config | v1.1.0 |
| `role_integration.py` | Enhanced with Docling support + table boosting | v2.6.0 |
| `core.py` | **Main review engine now uses Docling first** | - |
| `statement_forge/routes.py` | **Statement Forge now uses Docling first** | - |
| `setup_docling.bat` | Install Docling + download models + configure offline | - |
| `setup.bat` | Removed ping check - just runs pip directly | - |
| `bundle_for_airgap.ps1` | Create complete offline deployment packages | - |
| `requirements.txt` | Added Docling dependencies with docs | - |
| `help-docs.js` | New tech-docling section + updated extraction docs | v3.0.91 |
| `app.py` | Added /api/docling/status endpoint | - |
| `README.md` | Updated with Docling installation instructions | - |

### Full Docling Integration (v3.0.91)
Docling is now used **throughout** the application:
1. **Main Document Review** (`core.py`) - Docling first, legacy fallback
2. **Role Extraction** (`role_integration.py`) - Docling with table boosting
3. **Statement Forge** (`statement_forge/routes.py`) - Docling first, legacy fallback
4. **API Status** (`app.py`) - Reports Docling availability

### Enhanced Non-Docling Extraction (v3.0.91+)
For systems without Docling AI models, we now use multi-library extraction:

**Table Extraction (enhanced_table_extractor.py v1.0.0):**
1. **Camelot lattice** - Best for bordered tables (~90% accuracy)
2. **Camelot stream** - For borderless tables (~80% accuracy)
3. **Tabula** - Alternative algorithm (~75% accuracy)
4. **pdfplumber** - Fallback (~70% accuracy)
- Automatic deduplication of overlapping tables
- RACI matrix detection with confidence boosting

**OCR Support (ocr_extractor.py v1.0.0):**
- Automatic detection of scanned vs native text PDFs
- Tesseract OCR integration (pytesseract)
- Image preprocessing for better accuracy
- Confidence scoring per word
- Falls back automatically when text extraction yields < 200 chars/page

**NLP Enhancement (nlp_enhancer.py v1.0.0):**
- Enhanced role patterns with confidence weights
- sklearn-based role clustering and deduplication
- Text similarity for finding related content
- Readability metrics (Flesch, Gunning Fog)
- Optional spaCy NER integration

**PDF Extraction (pdf_extractor_v2.py v2.9.1):**
- Multi-library table extraction
- OCR fallback for scanned PDFs
- Enhanced heading detection
- Font-aware extraction (with PyMuPDF)

### New API Endpoints
- `/api/extraction/capabilities` - Reports all available extraction methods and accuracy estimates

### Setup Scripts
- `setup_enhancements.bat` - Install optional NLP enhancements (spaCy, PyMuPDF, textstat)
- `setup_docling.bat` - Docling installation with SSL bypass for corporate networks

### Accuracy Estimates by Configuration

| Configuration | Table | Role | Text |
|--------------|-------|------|------|
| **Base (pdfplumber only)** | ~70% | ~75% | ~80% |
| **+ Camelot/Tabula** | ~88% | ~80% | ~80% |
| **+ OCR** | ~88% | ~80% | ~85% |
| **+ spaCy/sklearn** | ~88% | ~90% | ~85% |
| **+ Docling AI** | ~95% | ~95% | ~95% |

### Air-Gapped Configuration (CRITICAL)
Environment variables set **automatically** by installers to prevent ANY network access:
```bash
# Model location
DOCLING_ARTIFACTS_PATH=<path_to_models>

# Block ALL network access
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
HF_DATASETS_OFFLINE=1

# Disable telemetry
HF_HUB_DISABLE_TELEMETRY=1
DO_NOT_TRACK=1
ANONYMIZED_TELEMETRY=false
```

### Memory Optimization Settings
Images are **disabled by default** to reduce memory usage (~500MB saved):
```python
# In docling_extractor.py - set automatically
do_picture_classifier = False     # No image classification
do_picture_description = False    # No image descriptions
generate_page_images = False      # No page screenshots
generate_picture_images = False   # No picture extraction
```

### Maximizing Docling Potential
1. **Table-based role boosting**: Roles found in tables get +20% confidence
2. **RACI detection**: Automatic detection of RACI matrix columns
3. **Section awareness**: Document sections used for context
4. **Paragraph typing**: Text classified as heading/list/table_cell
5. **Rich metadata**: Page numbers, confidence scores, extraction timing

### Installation Paths
| Scenario | Steps |
|----------|-------|
| Online | Run `setup_docling.bat` - downloads ~2.7GB |
| Air-gapped | Run `bundle_for_airgap.ps1` on internet machine → transfer → `INSTALL_AIRGAP.bat` |

### Fallback Architecture
```python
if docling_available:
    use_docling()  # Superior AI extraction (95% table accuracy)
else:
    use_legacy()   # pdfplumber + python-docx (70% table accuracy)
```
**Critical**: TWR works without Docling - no breaking changes.

### API Endpoint Added
```
GET /api/docling/status

Response:
{
  "available": true,
  "backend": "docling",
  "version": "2.70.0",
  "offline_mode": true,
  "offline_ready": true,
  "image_processing": false
}
```

### Help Documentation Added
- Navigation: Technical → Docling AI Engine
- Content: Full installation, configuration, troubleshooting guide
- Updated: Quick Start, Version History, About sections

### Disk Space Requirements
- PyTorch (CPU): ~800 MB
- Docling packages: ~700 MB
- AI models: ~1.2 GB
- **Total: ~2.7 GB**

---

## 🔴 CRITICAL: Session v3.0.90 - PATCH CONSOLIDATION LESSON

### The Problem
Verification revealed that fixes from v3.0.76-v3.0.89 existed in separate patch files but were **never properly merged**. Each patch was created from a different base version.

### What Happened
| Version | Had | Missing |
|---------|-----|---------|
| v3.0.76 | Iterative pruning | Dashed lines, export |
| v3.0.77-79 | Dashed lines, dimmed fixes | Iterative pruning |
| v3.0.80-82 | Export functions | Iterative pruning |
| v3.0.85 | Export fix module | Iterative pruning |

### Root Cause
Each chat session started from a different version or applied fixes to different base files. When "complete" packages were created, they only included that session's changes.

### The Fix
Manually merged all features:
1. Started with v3.0.82 roles.js (has export + dashed lines)
2. Added v3.0.76 iterative pruning code
3. Used v3.0.80 style.css (has correct dimmed opacities)
4. Used v3.0.85 index.html (has export dropdown + script tag)
5. Copied roles-export-fix.js from v3.0.85

### Prevention Pattern
BEFORE creating a "complete" package:
1. List ALL documented features from changelog
2. grep for each feature in actual code
3. If missing, find patch that has it
4. Merge manually
5. Verify ALL features present
6. NEVER trust changelog without code verification

---

## Session: v3.0.87 - SCRIPT LOADING FIX

### The Problem
Export button didn't work even though roles-export-fix.js existed.

### Root Cause
The .js file was created but **never added to index.html**!

### The Fix
Added to index.html before </body>:
```html
<script src="/static/js/roles-export-fix.js"></script>
```

### Lesson
**JS Module Checklist:**
1. Create the .js file
2. Add <script> tag to index.html
3. Verify in browser DevTools (Network tab)
4. Check console for module load message

---

## Session: v3.0.85 - ROLE EXPORT FIX

### The Problem
Export button clicked but nothing happened.

### Root Cause
button-fixes.js handled the click event but had no actual export logic. The Role Details tab uses /api/roles/aggregated, but export was trying to use window.State.

### The Fix
Created roles-export-fix.js that:
1. Intercepts export button clicks
2. Fetches from /api/roles/aggregated
3. Builds CSV from API response
4. Downloads file

---

## Session: v3.0.80 - EXPORT DROPDOWN

### The Problem
Single export button was too limiting.

### The Solution
Added dropdown with multiple options:
- Export All Roles (CSV)
- Export Current Document (CSV)
- Export All Roles (JSON)

---

## Session: v3.0.79 - DIMMED VISIBILITY FIX

### The Problem
When selecting a node, other nodes became nearly invisible.

### Root Cause
CSS .dimmed class had extremely low opacity (0.3, 0, 0.1)

### The Fix
```css
.graph-node.dimmed { opacity: 0.5; }
.graph-node.dimmed .graph-node-label { opacity: 0.4; }
.graph-link.dimmed { stroke-opacity: 0.3; }
```

---

## Session: v3.0.77 - SELF-EXPLANATORY GRAPH

### The Problem
Graph wasn't self-explanatory.

### The Solution
1. Distinct line styles: Dashed for role-role, solid for role-document
2. Distinct colors: Purple vs blue
3. Enhanced legend with visual examples

### LINK_STYLES Configuration
```javascript
const LINK_STYLES = {
    'role-role': { dashArray: '6,3', label: 'Roles Co-occur', color: '#7c3aed' },
    'role-document': { dashArray: 'none', label: 'Role in Document', color: '#4A90D9' },
};
```

---

## Session: v3.0.76 - PHANTOM LINES FIX

### The Problem
After v3.0.75 removed orphans, "phantom lines" still appeared going to peripheral nodes.

### Root Cause
v3.0.75 only removed nodes with 0 connections. Nodes with 1 connection still appeared.

### The Fix
Iterative pruning with MIN_CONNECTIONS = 2:
```javascript
const MIN_CONNECTIONS = 2;
let pruneIterations = 0;
let nodesRemoved = true;

while (nodesRemoved && pruneIterations < 10) {
    pruneIterations++;
    nodesRemoved = false;
    // Count connections, filter, re-filter links, repeat
}
```

---

## Session: v3.0.75 - ORPHAN NODES FIX

### The Problem
Disconnected nodes (floating circles) appeared in graph.

### The Fix
Filter nodes based on actual connections:
```javascript
const connectedNodeIds = new Set();
links.forEach(link => {
    connectedNodeIds.add(sourceId);
    connectedNodeIds.add(targetId);
});
nodes = nodes.filter(n => connectedNodeIds.has(n.id));
```

---

## Development Patterns

### Pattern 1: Console Logging
```javascript
console.log('[TWR ModuleName] Loading vX.X.X...');
```

### Pattern 2: Backward Compatibility
```javascript
const btn = document.getElementById('my-button');
if (btn && !btn._initialized) {
    btn._initialized = true;
    btn.addEventListener('click', handler);
}
```

### Pattern 3: State Access
```javascript
const State = window.State || window.TWR?.State?.State || {};
```

### Pattern 4: API Data Extraction
```javascript
const roles = result.data || result.roles || [];
const name = role.canonical_name || role.name || 'Unknown';
```

---

## Files That Commonly Need Updates

| File | When to Update |
|------|----------------|
| version.json | Every version bump |
| help-docs.js | Every version bump |
| roles.js | Graph/export changes |
| style.css | Visual changes |
| index.html | New UI/script tags |
| TWR_LESSONS_LEARNED.md | Every fix |

---

## Debugging Checklist

1. Check browser console for [TWR ...] logs
2. Check Network tab for failed API calls
3. Check version in Help → About
4. Hard refresh with Ctrl+Shift+R
5. Use grep to search codebase

---

## Session: 2026-01-28 (Setup Consolidation)

### Changes Made
- **Unified setup.bat**: Combined `setup.bat` and `setup_enhancements.bat` into single comprehensive setup
- **Added Fix Assistant v2 deps**: ReportLab for PDF report generation
- **Updated version references**: setup_docling.bat now references v3.0.97
- **Updated requirements.txt**: Added Fix Assistant v2 section with ReportLab

### Files Modified
- `setup.bat` - Completely rewritten (unified)
- `setup_enhancements.bat` - REMOVED (merged into setup.bat)
- `setup_docling.bat` - Version updated to v3.0.97
- `requirements.txt` - Added ReportLab dependency

### Setup Structure
```
setup.bat           - Run this first (installs everything except Docling)
setup_docling.bat   - Run separately when AI extraction is approved
start_twr.bat       - Generated by setup.bat to launch the app
```

### Verification Checklist
- [ ] Run setup.bat on fresh Windows install
- [ ] Verify all [OK] status messages
- [ ] Confirm start_twr.bat is generated
- [ ] Test app launch via start_twr.bat
