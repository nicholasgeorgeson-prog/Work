<# 
    TechWriterReview v3.0.70 Patch
    CSS Fix for Roles Tabs Visibility
    
    WHAT THIS FIXES:
    - Roles & Responsibilities tabs showing blank content
    - Missing CSS rules for .roles-section.active
    
    USAGE:
    1. Extract this ZIP to a temporary folder
    2. Right-click UPDATE.ps1 and select "Run with PowerShell"
    3. Enter your TWR install path when prompted (e.g., C:\TWR)
#>

param(
    [string]$InstallPath = ""
)

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host "   TechWriterReview v3.0.70 Patch" -ForegroundColor Cyan
Write-Host "   CSS Fix for Roles Tabs Visibility" -ForegroundColor Cyan
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host ""

# Get install path
if (-not $InstallPath) {
    Write-Host "  Enter your TWR install path" -ForegroundColor Yellow
    Write-Host "  (e.g., C:\TWR or C:\Users\You\Desktop\Doc Review)" -ForegroundColor Gray
    Write-Host ""
    $InstallPath = Read-Host "  Path"
}

# Validate path
$AppDir = Join-Path $InstallPath "app"
if (-not (Test-Path $AppDir)) {
    Write-Host ""
    Write-Host "  [ERROR] app folder not found at: $AppDir" -ForegroundColor Red
    Write-Host "  Please check your install path and try again." -ForegroundColor Gray
    Write-Host ""
    pause
    exit 1
}

# Find the CSS file to patch
$TargetCSS = Join-Path $AppDir "static\css\style.css"
if (-not (Test-Path $TargetCSS)) {
    $TargetCSS = Join-Path $AppDir "TechWriterReview\static\css\style.css"
}

if (-not (Test-Path $TargetCSS)) {
    Write-Host ""
    Write-Host "  [ERROR] style.css not found" -ForegroundColor Red
    Write-Host "  Checked:" -ForegroundColor Gray
    Write-Host "    - $AppDir\static\css\style.css" -ForegroundColor Gray
    Write-Host "    - $AppDir\TechWriterReview\static\css\style.css" -ForegroundColor Gray
    Write-Host ""
    pause
    exit 1
}

# Backup existing CSS
$BackupPath = "$TargetCSS.backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
Copy-Item -Path $TargetCSS -Destination $BackupPath -Force
Write-Host "  [OK] Backed up existing CSS to:" -ForegroundColor Green
Write-Host "       $BackupPath" -ForegroundColor Gray

# Copy new CSS
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PatchCSS = Join-Path $ScriptDir "TechWriterReview\static\css\style.css"

if (-not (Test-Path $PatchCSS)) {
    Write-Host ""
    Write-Host "  [ERROR] Patch CSS not found at: $PatchCSS" -ForegroundColor Red
    Write-Host "  Make sure you extracted the full patch ZIP." -ForegroundColor Gray
    Write-Host ""
    pause
    exit 1
}

Copy-Item -Path $PatchCSS -Destination $TargetCSS -Force
Write-Host "  [OK] Applied CSS patch" -ForegroundColor Green

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Green
Write-Host "   Patch Applied Successfully!" -ForegroundColor Green
Write-Host "  ==========================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Refresh your browser (Ctrl+F5) to see the fix." -ForegroundColor Yellow
Write-Host ""
pause
