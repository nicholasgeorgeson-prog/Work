/**
 * TechWriterReview History Fixes
 * ==============================
 * Fixes the History tab not loading data when opened.
 * 
 * Version: 3.0.53
 * 
 * Problem: The History tab in the top nav opens the modal but never calls
 * loadScanHistory() to fetch the data. The modal appears empty.
 * 
 * Root Cause: In events.js, the 'history' case handler only calls showModal()
 * without calling loadScanHistory() first. The sidebar btn-scan-history works
 * because it calls showScanHistoryModal() which includes the data load.
 * 
 * Solution: Override the top nav history button to load data before showing modal.
 */

(function() {
    'use strict';
    
    console.log('[TWR] Loading history-fixes v3.0.53...');
    
    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Format date for display
     */
    function formatScanDate(dateStr) {
        try {
            const date = new Date(dateStr);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        } catch (e) {
            return dateStr || 'Unknown';
        }
    }
    
    /**
     * Render scan history data into the table
     */
    function renderHistoryTable(history) {
        const tbody = document.getElementById('scan-history-body');
        const emptyMsg = document.getElementById('scan-history-empty');
        const table = document.querySelector('.scan-history-table');
        
        if (!tbody) {
            console.error('[TWR] History table body not found');
            return;
        }
        
        if (!history || history.length === 0) {
            if (emptyMsg) emptyMsg.style.display = 'block';
            if (table) table.style.display = 'none';
            console.log('[TWR] No history data to display');
            return;
        }
        
        if (emptyMsg) emptyMsg.style.display = 'none';
        if (table) table.style.display = 'block';
        
        tbody.innerHTML = history.map(scan => {
            const dateStr = formatScanDate(scan.scan_time);
            
            let changeHtml = '<span class="change-indicator unchanged">First scan</span>';
            if (scan.issues_added > 0 || scan.issues_removed > 0) {
                changeHtml = `
                    <span class="change-indicator added">+${scan.issues_added || 0}</span>
                    <span class="change-indicator removed">-${scan.issues_removed || 0}</span>
                `;
            }
            
            // Use scan.scan_id or scan.id (API may return either)
            const scanId = scan.scan_id || scan.id;
            
            return `
                <tr data-scan-id="${scanId}">
                    <td><strong>${escapeHtml(scan.filename)}</strong></td>
                    <td>${dateStr}</td>
                    <td>${scan.issue_count || 0}</td>
                    <td>${scan.score || '--'}</td>
                    <td><span class="grade-badge grade-${(scan.grade || 'U').toLowerCase()}">${scan.grade || '--'}</span></td>
                    <td>${changeHtml}</td>
                    <td>
                        <button class="btn btn-ghost btn-sm btn-delete-scan" 
                                data-action="delete-scan"
                                data-scan-id="${scanId}"
                                data-filename="${escapeHtml(scan.filename)}"
                                title="Delete this scan">
                            <i data-lucide="trash-2"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        
        // Refresh icons for the new buttons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
        
        console.log(`[TWR] Rendered ${history.length} history entries`);
    }
    
    /**
     * Load scan history from API
     */
    async function loadHistory() {
        console.log('[TWR] Loading scan history from API...');
        
        try {
            // Try using the global api function if available
            if (typeof window.api === 'function') {
                const result = await window.api('/scan-history', 'GET');
                if (result && result.success && result.data) {
                    renderHistoryTable(result.data);
                    return true;
                } else if (result && !result.success) {
                    console.warn('[TWR] API returned error:', result.error);
                }
            }
            
            // Fallback: direct fetch
            const response = await fetch('/api/scan-history');
            const result = await response.json();
            
            if (result.success && result.data) {
                renderHistoryTable(result.data);
                return true;
            } else {
                console.warn('[TWR] No history data returned:', result);
                renderHistoryTable([]);
                return false;
            }
        } catch (err) {
            console.error('[TWR] Failed to load scan history:', err);
            renderHistoryTable([]);
            return false;
        }
    }
    
    /**
     * Show the history modal
     */
    function showHistoryModal() {
        const modal = document.getElementById('modal-scan-history');
        if (modal) {
            modal.classList.add('active');
            modal.style.display = 'flex';
        }
        // Also try the global showModal if available
        if (typeof window.showModal === 'function') {
            window.showModal('modal-scan-history');
        }
    }
    
    /**
     * Initialize the history fixes
     */
    function initHistoryFixes() {
        // Find the top nav History link
        const historyNav = document.getElementById('nav-history') || 
                          document.querySelector('[data-view="history"]');
        
        if (!historyNav) {
            console.log('[TWR] History nav not found, retrying...');
            setTimeout(initHistoryFixes, 200);
            return;
        }
        
        console.log('[TWR] Patching history nav click handler...');
        
        // Clone the element to remove existing event listeners
        const newHistoryNav = historyNav.cloneNode(true);
        historyNav.parentNode.replaceChild(newHistoryNav, historyNav);
        
        // Add our fixed handler
        newHistoryNav.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('[TWR] History nav clicked - loading data...');
            
            // Update active state
            document.querySelectorAll('.top-nav-link').forEach(l => l.classList.remove('active'));
            newHistoryNav.classList.add('active');
            
            // Load data FIRST
            await loadHistory();
            
            // Then show modal
            showHistoryModal();
        });
        
        // Also ensure the refresh button works
        const refreshBtn = document.getElementById('btn-refresh-history');
        if (refreshBtn) {
            // Clone to remove old handlers
            const newRefreshBtn = refreshBtn.cloneNode(true);
            refreshBtn.parentNode.replaceChild(newRefreshBtn, refreshBtn);
            
            newRefreshBtn.addEventListener('click', async () => {
                console.log('[TWR] Refresh history clicked');
                await loadHistory();
                if (typeof toast === 'function') {
                    toast('success', 'History refreshed');
                }
            });
        }
        
        // Expose our loadHistory function globally so other code can use it
        window.loadScanHistory = loadHistory;
        window.renderScanHistory = renderHistoryTable;
        
        // Also patch the sidebar history button to use our improved function
        const sidebarHistoryBtn = document.getElementById('btn-scan-history');
        if (sidebarHistoryBtn && !sidebarHistoryBtn._historyPatched) {
            sidebarHistoryBtn._historyPatched = true;
            
            const newSidebarBtn = sidebarHistoryBtn.cloneNode(true);
            sidebarHistoryBtn.parentNode.replaceChild(newSidebarBtn, sidebarHistoryBtn);
            
            newSidebarBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                await loadHistory();
                showHistoryModal();
            });
        }
        
        console.log('[TWR] History fixes applied successfully');
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            // Wait a bit for other scripts to initialize
            setTimeout(initHistoryFixes, 300);
        });
    } else {
        setTimeout(initHistoryFixes, 300);
    }
    
})();

console.log('[TWR] History fixes module loaded v3.0.53');
