# TechWriterReview - Lessons Learned & Development Patterns

## Version: 3.0.91

---

## 🔴 CRITICAL: Session v3.0.91 - DOCLING INTEGRATION (Complete)

### Summary
Integrated Docling (IBM's open-source document parser) for AI-powered document extraction with **100% air-gapped operation** and **memory optimization** (images disabled).

### Key Files Created/Modified
| File | Purpose | Version |
|------|---------|---------|
| `docling_extractor.py` | Core Docling wrapper with offline config | v1.1.0 |
| `role_integration.py` | Enhanced with Docling support + table boosting | v2.6.0 |
| `setup_docling.bat` | Install Docling + download models + configure offline | - |
| `bundle_for_airgap.ps1` | Create complete offline deployment packages | - |
| `requirements.txt` | Added Docling dependencies with docs | - |
| `help-docs.js` | New tech-docling section + updated extraction docs | v3.0.91 |
| `app.py` | Added /api/docling/status endpoint | - |
| `README.md` | Updated with Docling installation instructions | - |

### Air-Gapped Configuration (CRITICAL)
Environment variables set **automatically** by installers to prevent ANY network access:
```bash
# Model location
DOCLING_ARTIFACTS_PATH=<path_to_models>

# Block ALL network access
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
HF_DATASETS_OFFLINE=1

# Disable telemetry
HF_HUB_DISABLE_TELEMETRY=1
DO_NOT_TRACK=1
ANONYMIZED_TELEMETRY=false
```

### Memory Optimization Settings
Images are **disabled by default** to reduce memory usage (~500MB saved):
```python
# In docling_extractor.py - set automatically
do_picture_classifier = False     # No image classification
do_picture_description = False    # No image descriptions
generate_page_images = False      # No page screenshots
generate_picture_images = False   # No picture extraction
```

### Maximizing Docling Potential
1. **Table-based role boosting**: Roles found in tables get +20% confidence
2. **RACI detection**: Automatic detection of RACI matrix columns
3. **Section awareness**: Document sections used for context
4. **Paragraph typing**: Text classified as heading/list/table_cell
5. **Rich metadata**: Page numbers, confidence scores, extraction timing

### Installation Paths
| Scenario | Steps |
|----------|-------|
| Online | Run `setup_docling.bat` - downloads ~2.7GB |
| Air-gapped | Run `bundle_for_airgap.ps1` on internet machine → transfer → `INSTALL_AIRGAP.bat` |

### Fallback Architecture
```python
if docling_available:
    use_docling()  # Superior AI extraction (95% table accuracy)
else:
    use_legacy()   # pdfplumber + python-docx (70% table accuracy)
```
**Critical**: TWR works without Docling - no breaking changes.

### API Endpoint Added
```
GET /api/docling/status

Response:
{
  "available": true,
  "backend": "docling",
  "version": "2.70.0",
  "offline_mode": true,
  "offline_ready": true,
  "image_processing": false
}
```

### Help Documentation Added
- Navigation: Technical → Docling AI Engine
- Content: Full installation, configuration, troubleshooting guide
- Updated: Quick Start, Version History, About sections

### Disk Space Requirements
- PyTorch (CPU): ~800 MB
- Docling packages: ~700 MB
- AI models: ~1.2 GB
- **Total: ~2.7 GB**

---

## 🔴 CRITICAL: Session v3.0.90 - PATCH CONSOLIDATION LESSON

### The Problem
Verification revealed that fixes from v3.0.76-v3.0.89 existed in separate patch files but were **never properly merged**. Each patch was created from a different base version.

### What Happened
| Version | Had | Missing |
|---------|-----|---------|
| v3.0.76 | Iterative pruning | Dashed lines, export |
| v3.0.77-79 | Dashed lines, dimmed fixes | Iterative pruning |
| v3.0.80-82 | Export functions | Iterative pruning |
| v3.0.85 | Export fix module | Iterative pruning |

### Root Cause
Each chat session started from a different version or applied fixes to different base files. When "complete" packages were created, they only included that session's changes.

### The Fix
Manually merged all features:
1. Started with v3.0.82 roles.js (has export + dashed lines)
2. Added v3.0.76 iterative pruning code
3. Used v3.0.80 style.css (has correct dimmed opacities)
4. Used v3.0.85 index.html (has export dropdown + script tag)
5. Copied roles-export-fix.js from v3.0.85

### Prevention Pattern
BEFORE creating a "complete" package:
1. List ALL documented features from changelog
2. grep for each feature in actual code
3. If missing, find patch that has it
4. Merge manually
5. Verify ALL features present
6. NEVER trust changelog without code verification

---

## Session: v3.0.87 - SCRIPT LOADING FIX

### The Problem
Export button didn't work even though roles-export-fix.js existed.

### Root Cause
The .js file was created but **never added to index.html**!

### The Fix
Added to index.html before </body>:
```html
<script src="/static/js/roles-export-fix.js"></script>
```

### Lesson
**JS Module Checklist:**
1. Create the .js file
2. Add <script> tag to index.html
3. Verify in browser DevTools (Network tab)
4. Check console for module load message

---

## Session: v3.0.85 - ROLE EXPORT FIX

### The Problem
Export button clicked but nothing happened.

### Root Cause
button-fixes.js handled the click event but had no actual export logic. The Role Details tab uses /api/roles/aggregated, but export was trying to use window.State.

### The Fix
Created roles-export-fix.js that:
1. Intercepts export button clicks
2. Fetches from /api/roles/aggregated
3. Builds CSV from API response
4. Downloads file

---

## Session: v3.0.80 - EXPORT DROPDOWN

### The Problem
Single export button was too limiting.

### The Solution
Added dropdown with multiple options:
- Export All Roles (CSV)
- Export Current Document (CSV)
- Export All Roles (JSON)

---

## Session: v3.0.79 - DIMMED VISIBILITY FIX

### The Problem
When selecting a node, other nodes became nearly invisible.

### Root Cause
CSS .dimmed class had extremely low opacity (0.3, 0, 0.1)

### The Fix
```css
.graph-node.dimmed { opacity: 0.5; }
.graph-node.dimmed .graph-node-label { opacity: 0.4; }
.graph-link.dimmed { stroke-opacity: 0.3; }
```

---

## Session: v3.0.77 - SELF-EXPLANATORY GRAPH

### The Problem
Graph wasn't self-explanatory.

### The Solution
1. Distinct line styles: Dashed for role-role, solid for role-document
2. Distinct colors: Purple vs blue
3. Enhanced legend with visual examples

### LINK_STYLES Configuration
```javascript
const LINK_STYLES = {
    'role-role': { dashArray: '6,3', label: 'Roles Co-occur', color: '#7c3aed' },
    'role-document': { dashArray: 'none', label: 'Role in Document', color: '#4A90D9' },
};
```

---

## Session: v3.0.76 - PHANTOM LINES FIX

### The Problem
After v3.0.75 removed orphans, "phantom lines" still appeared going to peripheral nodes.

### Root Cause
v3.0.75 only removed nodes with 0 connections. Nodes with 1 connection still appeared.

### The Fix
Iterative pruning with MIN_CONNECTIONS = 2:
```javascript
const MIN_CONNECTIONS = 2;
let pruneIterations = 0;
let nodesRemoved = true;

while (nodesRemoved && pruneIterations < 10) {
    pruneIterations++;
    nodesRemoved = false;
    // Count connections, filter, re-filter links, repeat
}
```

---

## Session: v3.0.75 - ORPHAN NODES FIX

### The Problem
Disconnected nodes (floating circles) appeared in graph.

### The Fix
Filter nodes based on actual connections:
```javascript
const connectedNodeIds = new Set();
links.forEach(link => {
    connectedNodeIds.add(sourceId);
    connectedNodeIds.add(targetId);
});
nodes = nodes.filter(n => connectedNodeIds.has(n.id));
```

---

## Development Patterns

### Pattern 1: Console Logging
```javascript
console.log('[TWR ModuleName] Loading vX.X.X...');
```

### Pattern 2: Backward Compatibility
```javascript
const btn = document.getElementById('my-button');
if (btn && !btn._initialized) {
    btn._initialized = true;
    btn.addEventListener('click', handler);
}
```

### Pattern 3: State Access
```javascript
const State = window.State || window.TWR?.State?.State || {};
```

### Pattern 4: API Data Extraction
```javascript
const roles = result.data || result.roles || [];
const name = role.canonical_name || role.name || 'Unknown';
```

---

## Files That Commonly Need Updates

| File | When to Update |
|------|----------------|
| version.json | Every version bump |
| help-docs.js | Every version bump |
| roles.js | Graph/export changes |
| style.css | Visual changes |
| index.html | New UI/script tags |
| TWR_LESSONS_LEARNED.md | Every fix |

---

## Debugging Checklist

1. Check browser console for [TWR ...] logs
2. Check Network tab for failed API calls
3. Check version in Help → About
4. Hard refresh with Ctrl+Shift+R
5. Use grep to search codebase
