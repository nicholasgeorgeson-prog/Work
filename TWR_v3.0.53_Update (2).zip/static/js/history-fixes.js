/**
 * TechWriterReview History Fixes & Enhancements
 * ==============================================
 * Fixes the History tab and adds scan recall/management features.
 * 
 * Version: 3.0.53
 * 
 * Features:
 * - Fixes History tab not loading data when opened
 * - Adds "Load" button to recall previous scan results
 * - Adds history management (clear old scans, view stats)
 * 
 * Backend Requirements:
 * - /api/scan-history/<scan_id>/recall - GET full scan results
 * - /api/scan-history/clear - POST to clear history
 * - /api/scan-history/stats - GET storage statistics
 * 
 * See BACKEND_PATCH_scan_recall.py for required API endpoints.
 */

(function() {
    'use strict';
    
    console.log('[TWR] Loading history-fixes v3.0.53...');
    
    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Format date for display
     */
    function formatScanDate(dateStr) {
        try {
            const date = new Date(dateStr);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        } catch (e) {
            return dateStr || 'Unknown';
        }
    }
    
    /**
     * Format bytes to human readable
     */
    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    /**
     * Render scan history data into the table with Load buttons
     */
    function renderHistoryTable(history) {
        const tbody = document.getElementById('scan-history-body');
        const emptyMsg = document.getElementById('scan-history-empty');
        const table = document.querySelector('.scan-history-table');
        
        if (!tbody) {
            console.error('[TWR] History table body not found');
            return;
        }
        
        if (!history || history.length === 0) {
            if (emptyMsg) emptyMsg.style.display = 'block';
            if (table) table.style.display = 'none';
            console.log('[TWR] No history data to display');
            return;
        }
        
        if (emptyMsg) emptyMsg.style.display = 'none';
        if (table) table.style.display = 'block';
        
        tbody.innerHTML = history.map(scan => {
            const dateStr = formatScanDate(scan.scan_time);
            const scanId = scan.scan_id || scan.id;
            
            let changeHtml = '<span class="change-indicator unchanged">First scan</span>';
            if (scan.issues_added > 0 || scan.issues_removed > 0) {
                changeHtml = `
                    <span class="change-indicator added">+${scan.issues_added || 0}</span>
                    <span class="change-indicator removed">-${scan.issues_removed || 0}</span>
                `;
            }
            
            return `
                <tr data-scan-id="${scanId}">
                    <td><strong>${escapeHtml(scan.filename)}</strong></td>
                    <td>${dateStr}</td>
                    <td>${scan.issue_count || 0}</td>
                    <td>${scan.score || '--'}</td>
                    <td><span class="grade-badge grade-${(scan.grade || 'U').toLowerCase()}">${scan.grade || '--'}</span></td>
                    <td>${changeHtml}</td>
                    <td>
                        <div style="display: flex; gap: 4px;">
                            <button class="btn btn-ghost btn-sm btn-load-scan" 
                                    data-action="load-scan"
                                    data-scan-id="${scanId}"
                                    data-filename="${escapeHtml(scan.filename)}"
                                    title="Load this scan's results">
                                <i data-lucide="upload"></i>
                            </button>
                            <button class="btn btn-ghost btn-sm btn-delete-scan" 
                                    data-action="delete-scan"
                                    data-scan-id="${scanId}"
                                    data-filename="${escapeHtml(scan.filename)}"
                                    title="Delete this scan">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
        
        // Refresh icons for the new buttons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
        
        // Add event listeners for new buttons
        bindHistoryTableEvents(tbody);
        
        console.log(`[TWR] Rendered ${history.length} history entries`);
    }
    
    /**
     * Bind click events for history table buttons
     */
    function bindHistoryTableEvents(tbody) {
        tbody.querySelectorAll('.btn-load-scan').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const scanId = btn.dataset.scanId;
                const filename = btn.dataset.filename;
                await recallScan(scanId, filename);
            });
        });
        
        tbody.querySelectorAll('.btn-delete-scan').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const scanId = btn.dataset.scanId;
                const filename = btn.dataset.filename;
                await deleteScan(scanId, filename);
            });
        });
    }
    
    /**
     * Recall/load a previous scan's results
     */
    async function recallScan(scanId, filename) {
        console.log(`[TWR] Recalling scan ${scanId} for ${filename}...`);
        
        if (typeof toast === 'function') {
            toast('info', `Loading scan for "${filename}"...`);
        }
        
        try {
            // Try the recall endpoint
            let result;
            if (typeof window.api === 'function') {
                result = await window.api(`/scan-history/${scanId}/recall`, 'GET');
            } else {
                const response = await fetch(`/api/scan-history/${scanId}/recall`);
                result = await response.json();
            }
            
            if (result && result.success && result.data) {
                const scanData = result.data;
                
                // Close the history modal
                const modal = document.getElementById('modal-scan-history');
                if (modal) {
                    modal.classList.remove('active');
                    modal.style.display = 'none';
                }
                
                // Populate the UI with recalled results
                populateRecalledScan(scanData);
                
                if (typeof toast === 'function') {
                    toast('success', `Loaded scan from ${formatScanDate(scanData.scan_time)}`);
                }
            } else {
                // Backend endpoint might not exist yet
                const errorMsg = result?.error || 'Recall feature requires backend update. See BACKEND_PATCH_scan_recall.py';
                console.warn('[TWR] Recall failed:', errorMsg);
                
                if (typeof toast === 'function') {
                    toast('warning', errorMsg);
                }
            }
        } catch (err) {
            console.error('[TWR] Failed to recall scan:', err);
            if (typeof toast === 'function') {
                toast('error', 'Failed to load scan. Backend may need update.');
            }
        }
    }
    
    /**
     * Populate the UI with recalled scan data
     */
    function populateRecalledScan(scanData) {
        console.log('[TWR] Populating UI with recalled scan data...');
        
        const results = scanData.results;
        if (!results) {
            console.warn('[TWR] No results in scan data');
            return;
        }
        
        // Update State if available
        if (typeof State !== 'undefined') {
            State.filename = scanData.filename;
            State.filepath = scanData.filepath;
            State.reviewResults = results;
            State.issues = results.issues || [];
            State.filteredIssues = [...State.issues];
            State.roles = results.roles || {};
            State.documentId = scanData.document_id;
            
            // Mark as recalled (not live)
            State.isRecalledScan = true;
            State.recalledScanTime = scanData.scan_time;
        }
        
        // Update filename display
        const filenameEl = document.getElementById('current-filename');
        if (filenameEl) {
            filenameEl.textContent = scanData.filename + ' (historical)';
            filenameEl.title = `Scan from ${formatScanDate(scanData.scan_time)}`;
        }
        
        // Show recalled scan indicator
        showRecalledBanner(scanData);
        
        // Use existing functions to update UI if available
        if (typeof updateResultsUI === 'function') {
            updateResultsUI(results);
        } else if (typeof window.updateResultsUI === 'function') {
            window.updateResultsUI(results);
        }
        
        if (typeof updateSeverityCounts === 'function') {
            updateSeverityCounts(results.by_severity || {});
        }
        
        if (typeof updateCategoryFilters === 'function') {
            updateCategoryFilters(results.by_category || {});
        }
        
        if (typeof renderIssuesList === 'function') {
            renderIssuesList();
        } else if (typeof window.renderIssuesList === 'function') {
            window.renderIssuesList();
        }
        
        // Show issues container
        const issuesContainer = document.getElementById('issues-container');
        if (issuesContainer) {
            issuesContainer.style.display = 'block';
        }
        
        // Show analytics if available
        if (typeof showAnalyticsAccordion === 'function') {
            showAnalyticsAccordion(results);
        }
        
        console.log('[TWR] UI populated with recalled scan');
    }
    
    /**
     * Show a banner indicating this is a recalled/historical scan
     */
    function showRecalledBanner(scanData) {
        // Remove existing banner if any
        const existingBanner = document.getElementById('recalled-scan-banner');
        if (existingBanner) existingBanner.remove();
        
        // Create banner
        const banner = document.createElement('div');
        banner.id = 'recalled-scan-banner';
        banner.className = 'recalled-scan-banner';
        banner.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; background: linear-gradient(90deg, #3b82f6, #1d4ed8); color: white; font-size: 13px;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <i data-lucide="history" style="width: 16px; height: 16px;"></i>
                    <span>Viewing historical scan from <strong>${formatScanDate(scanData.scan_time)}</strong></span>
                    <span style="opacity: 0.8;">• ${scanData.issue_count} issues • Score: ${scanData.score}</span>
                </div>
                <button id="btn-clear-recalled" class="btn btn-sm" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 4px 12px;">
                    <i data-lucide="x" style="width: 14px; height: 14px;"></i> Clear
                </button>
            </div>
        `;
        
        // Insert at top of main content
        const appContainer = document.querySelector('.app-container') || document.querySelector('main');
        if (appContainer) {
            appContainer.insertBefore(banner, appContainer.firstChild);
        }
        
        // Refresh icons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
        
        // Add clear handler
        document.getElementById('btn-clear-recalled')?.addEventListener('click', () => {
            clearRecalledState();
        });
    }
    
    /**
     * Clear the recalled scan state
     */
    function clearRecalledState() {
        const banner = document.getElementById('recalled-scan-banner');
        if (banner) banner.remove();
        
        if (typeof State !== 'undefined') {
            State.isRecalledScan = false;
            State.recalledScanTime = null;
        }
        
        // Update filename display
        const filenameEl = document.getElementById('current-filename');
        if (filenameEl && State?.filename) {
            filenameEl.textContent = State.filename;
            filenameEl.title = '';
        }
    }
    
    /**
     * Delete a scan from history
     */
    async function deleteScan(scanId, filename) {
        if (!confirm(`Delete scan record for "${filename}"?\n\nThis cannot be undone.`)) {
            return;
        }
        
        try {
            let result;
            if (typeof window.api === 'function') {
                result = await window.api(`/scan-history/${scanId}`, 'DELETE');
            } else {
                const response = await fetch(`/api/scan-history/${scanId}`, { method: 'DELETE' });
                result = await response.json();
            }
            
            if (result && result.success) {
                if (typeof toast === 'function') {
                    toast('success', 'Scan deleted');
                }
                await loadHistory();
            } else {
                if (typeof toast === 'function') {
                    toast('error', result?.error || 'Failed to delete scan');
                }
            }
        } catch (err) {
            console.error('[TWR] Delete scan error:', err);
            if (typeof toast === 'function') {
                toast('error', 'Failed to delete scan');
            }
        }
    }
    
    /**
     * Load scan history from API
     */
    async function loadHistory() {
        console.log('[TWR] Loading scan history from API...');
        
        try {
            let result;
            if (typeof window.api === 'function') {
                result = await window.api('/scan-history', 'GET');
            } else {
                const response = await fetch('/api/scan-history');
                result = await response.json();
            }
            
            if (result && result.success && result.data) {
                renderHistoryTable(result.data);
                return true;
            } else {
                console.warn('[TWR] No history data returned:', result);
                renderHistoryTable([]);
                return false;
            }
        } catch (err) {
            console.error('[TWR] Failed to load scan history:', err);
            renderHistoryTable([]);
            return false;
        }
    }
    
    /**
     * Show the history modal
     */
    function showHistoryModal() {
        const modal = document.getElementById('modal-scan-history');
        if (modal) {
            modal.classList.add('active');
            modal.style.display = 'flex';
        }
        if (typeof window.showModal === 'function') {
            window.showModal('modal-scan-history');
        }
    }
    
    /**
     * Load and display history storage stats
     */
    async function loadHistoryStats() {
        try {
            let result;
            if (typeof window.api === 'function') {
                result = await window.api('/scan-history/stats', 'GET');
            } else {
                const response = await fetch('/api/scan-history/stats');
                result = await response.json();
            }
            
            if (result && result.success && result.data) {
                const stats = result.data;
                const statsHtml = `
                    <div class="history-stats" style="padding: 12px; background: var(--bg-surface); border-radius: 8px; margin-bottom: 16px; font-size: 13px;">
                        <div style="display: flex; gap: 24px; flex-wrap: wrap;">
                            <div><strong>${stats.document_count}</strong> documents</div>
                            <div><strong>${stats.scan_count}</strong> scans</div>
                            <div><strong>${stats.database_size_mb}</strong> MB storage</div>
                            ${stats.oldest_scan ? `<div>Oldest: ${formatScanDate(stats.oldest_scan)}</div>` : ''}
                        </div>
                    </div>
                `;
                
                const container = document.querySelector('.scan-history-container');
                const existingStats = container?.querySelector('.history-stats');
                if (existingStats) existingStats.remove();
                
                if (container) {
                    container.insertAdjacentHTML('afterbegin', statsHtml);
                }
            }
        } catch (err) {
            console.log('[TWR] Stats endpoint not available:', err.message);
        }
    }
    
    /**
     * Clear history with options
     */
    async function clearHistory(options) {
        try {
            let result;
            if (typeof window.api === 'function') {
                result = await window.api('/scan-history/clear', 'POST', options);
            } else {
                const response = await fetch('/api/scan-history/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(options)
                });
                result = await response.json();
            }
            
            if (result && result.success) {
                if (typeof toast === 'function') {
                    toast('success', result.data?.message || 'History cleared');
                }
                await loadHistory();
                await loadHistoryStats();
            } else {
                if (typeof toast === 'function') {
                    toast('error', result?.error || 'Failed to clear history');
                }
            }
        } catch (err) {
            console.error('[TWR] Clear history error:', err);
            if (typeof toast === 'function') {
                toast('warning', 'Clear history requires backend update');
            }
        }
    }
    
    /**
     * Add history management UI to the modal
     */
    function addHistoryManagementUI() {
        const modalFooter = document.querySelector('#modal-scan-history .modal-footer');
        if (!modalFooter) return;
        
        // Check if already added
        if (modalFooter.querySelector('.history-management')) return;
        
        const managementHtml = `
            <div class="history-management" style="display: flex; gap: 8px; margin-right: auto;">
                <button class="btn btn-secondary btn-sm" id="btn-clear-old-scans" title="Clear scans older than 30 days">
                    <i data-lucide="calendar-x"></i> Clear Old
                </button>
                <button class="btn btn-secondary btn-sm" id="btn-keep-recent" title="Keep only last 5 scans per document">
                    <i data-lucide="filter"></i> Keep Recent
                </button>
                <button class="btn btn-danger btn-sm" id="btn-clear-all-history" title="Clear all history (careful!)">
                    <i data-lucide="trash"></i> Clear All
                </button>
            </div>
        `;
        
        modalFooter.insertAdjacentHTML('afterbegin', managementHtml);
        
        // Refresh icons
        if (typeof lucide !== 'undefined') {
            try { lucide.createIcons(); } catch(e) {}
        }
        
        // Bind events
        document.getElementById('btn-clear-old-scans')?.addEventListener('click', () => {
            if (confirm('Delete all scans older than 30 days?')) {
                clearHistory({ older_than_days: 30 });
            }
        });
        
        document.getElementById('btn-keep-recent')?.addEventListener('click', () => {
            if (confirm('Keep only the 5 most recent scans for each document?\n\nOlder scans will be deleted.')) {
                clearHistory({ keep_per_document: 5 });
            }
        });
        
        document.getElementById('btn-clear-all-history')?.addEventListener('click', () => {
            if (confirm('⚠️ DELETE ALL SCAN HISTORY?\n\nThis will remove ALL historical scan data and cannot be undone!')) {
                if (confirm('Are you REALLY sure? Type "yes" in your head before clicking OK.')) {
                    clearHistory({ clear_all: true });
                }
            }
        });
    }
    
    /**
     * Initialize the history fixes
     */
    function initHistoryFixes() {
        // Find the top nav History link
        const historyNav = document.getElementById('nav-history') || 
                          document.querySelector('[data-view="history"]');
        
        if (!historyNav) {
            console.log('[TWR] History nav not found, retrying...');
            setTimeout(initHistoryFixes, 200);
            return;
        }
        
        console.log('[TWR] Patching history nav click handler...');
        
        // Clone the element to remove existing event listeners
        const newHistoryNav = historyNav.cloneNode(true);
        historyNav.parentNode.replaceChild(newHistoryNav, historyNav);
        
        // Add our fixed handler
        newHistoryNav.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('[TWR] History nav clicked - loading data...');
            
            // Update active state
            document.querySelectorAll('.top-nav-link').forEach(l => l.classList.remove('active'));
            newHistoryNav.classList.add('active');
            
            // Load data FIRST
            await loadHistory();
            await loadHistoryStats();
            
            // Add management UI
            addHistoryManagementUI();
            
            // Then show modal
            showHistoryModal();
        });
        
        // Also ensure the refresh button works
        const refreshBtn = document.getElementById('btn-refresh-history');
        if (refreshBtn) {
            const newRefreshBtn = refreshBtn.cloneNode(true);
            refreshBtn.parentNode.replaceChild(newRefreshBtn, refreshBtn);
            
            newRefreshBtn.addEventListener('click', async () => {
                console.log('[TWR] Refresh history clicked');
                await loadHistory();
                await loadHistoryStats();
                if (typeof toast === 'function') {
                    toast('success', 'History refreshed');
                }
            });
        }
        
        // Expose functions globally
        window.loadScanHistory = loadHistory;
        window.renderScanHistory = renderHistoryTable;
        window.recallScan = recallScan;
        window.clearScanHistory = clearHistory;
        
        // Also patch the sidebar history button
        const sidebarHistoryBtn = document.getElementById('btn-scan-history');
        if (sidebarHistoryBtn && !sidebarHistoryBtn._historyPatched) {
            sidebarHistoryBtn._historyPatched = true;
            
            const newSidebarBtn = sidebarHistoryBtn.cloneNode(true);
            sidebarHistoryBtn.parentNode.replaceChild(newSidebarBtn, sidebarHistoryBtn);
            
            newSidebarBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                await loadHistory();
                await loadHistoryStats();
                addHistoryManagementUI();
                showHistoryModal();
            });
        }
        
        console.log('[TWR] History fixes applied successfully');
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(initHistoryFixes, 300);
        });
    } else {
        setTimeout(initHistoryFixes, 300);
    }
    
})();

console.log('[TWR] History fixes module loaded v3.0.53');
