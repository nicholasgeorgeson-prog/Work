# TechWriterReview Installation

## Requirements
- Windows 10/11 or Windows Server 2016+
- Python 3.8 or later (https://python.org/downloads)
- ~500MB disk space

## Quick Install

1. **Extract** this ZIP to a temporary folder (e.g., `C:\TWR_Install`)

2. **Right-click** `INSTALL.ps1` → **Run with PowerShell**
   - Or open PowerShell and run: `.\INSTALL.ps1`

3. **Choose install location** when prompted (or press Enter for default `C:\TWR`)

4. **Wait for installation** - progress bar shows package installation status

5. **Create desktop shortcut** when prompted (optional)

6. **Launch** using `Run_TWR.bat` or the desktop shortcut

7. **Open browser** to http://127.0.0.1:5050

## Custom Install Location

The installer will prompt you to choose a location. You can also specify it via command line:

```powershell
.\INSTALL.ps1 -InstallPath "D:\Tools\TWR"
```

## Air-Gapped Installation

If you don't have internet access on the target machine:

1. On a machine with internet, download Python wheel files:
   ```
   pip download -r requirements.txt -d wheels/
   ```

2. Copy the wheels folder to the target machine

3. Install with:
   ```
   pip install --no-index --find-links=wheels/ -r requirements.txt
   ```

## Troubleshooting

**"Python not found"**
- Install Python 3.8+ from python.org
- Make sure "Add Python to PATH" is checked during installation

**"Module not found" errors**
- Delete the `.venv` folder in the install directory
- Re-run INSTALL.ps1

**Server won't start**
- Check if port 5050 is in use: `netstat -an | findstr 5050`
- Check logs in the `app/logs/` folder

## Files After Installation

```
C:\TWR\
├── Run_TWR.bat      # Start the server (auto-restarts on update)
├── Stop_TWR.bat     # Stop the server
├── .venv\           # Python virtual environment
├── updates\         # Drop update packages here
├── backups\         # Automatic backups before updates
└── app\             # Application files
    ├── app.py       # Main application
    ├── config.json  # Settings
    └── logs\        # Log files
```

## Version

TechWriterReview v3.0.51

## What's New in 3.0.51

- **Custom install location**: Installer now prompts you to choose where to install
- **Installation progress bar**: See real-time progress during package installation
- **Desktop shortcut with icon**: Optional shortcut with custom TWR icon
- **Auto-restart on update**: When you apply updates from Settings → Updates,
  the server automatically restarts and refreshes your browser. No manual steps needed.
- **Fixed update detection**: "Check for Updates" now correctly shows available updates.
