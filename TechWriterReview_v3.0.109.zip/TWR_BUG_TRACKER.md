# TechWriterReview - Bug & Issue Tracker

**Version:** 3.0.108  
**Last Updated:** 2026-01-28  
**Status Legend:** 🔴 Critical | 🟡 Medium | 🟢 Low | ⚪ Info | ✅ Fixed

---

## Summary Dashboard

| Priority | Open | Fixed | Total |
|----------|------|-------|-------|
| 🔴 Critical | 0 | 7 | 7 |
| 🟡 Medium | 4 | 7 | 11 |
| 🟢 Low | 8 | 0 | 8 |
| ⚪ Info/Enhancement | 4 | 0 | 4 |

**Overall Status:** Production Ready (no critical or high-severity open bugs)

---

## Open Issues

### 🟡 MEDIUM Priority (4 open)

#### BUG-M02: Batch Memory - Files loaded entirely in memory
**Status:** Open  
**Location:** `app.py` batch upload endpoint  
**Impact:** High memory usage when batch processing many large documents  
**Evidence:** Code review audit finding  
**Fix:** Add batch size limits, stream processing for large batches  
**Effort:** Medium (2-4 hours)

#### BUG-M03: SessionManager Growth - No automatic cleanup
**Status:** Open  
**Location:** `app.py` SessionManager class  
**Impact:** Memory growth over long server runtime  
**Evidence:** Code review audit finding  
**Fix:** Add periodic cleanup hook, TTL-based session expiration  
**Effort:** Medium (2-3 hours)

#### BUG-M04: Batch Error Context - Missing tracebacks
**Status:** Open  
**Location:** `app.py` batch processing  
**Impact:** Hard to debug batch failures - only error message, no traceback  
**Evidence:** Code review audit finding  
**Fix:** Log full traceback alongside error message  
**Effort:** Low (30 minutes)

#### BUG-M05: Progress Persistence Key Collision
**Status:** Open  
**Location:** `static/js/features/fix-assistant-state.js`  
**Impact:** localStorage key collision if same filename reviewed twice  
**Evidence:** Documented in NEXT_SESSION_PROMPT.md  
**Fix:** Use hash of filename + file size or upload timestamp  
**Effort:** Low (1 hour)

---

### 🟢 LOW Priority (8 open)

#### BUG-L01: Version comments outdated in file headers
**Status:** Open  
**Location:** Multiple Python files  
**Impact:** Confusing for developers  
**Fix:** Update all file header version comments  
**Effort:** Low (30 minutes)

#### BUG-L02: Missing type hints in some functions
**Status:** Open  
**Location:** Various Python modules  
**Impact:** IDE support, code documentation  
**Fix:** Add type hints gradually  
**Effort:** Medium (ongoing)

#### BUG-L03: Console log prefixes inconsistent
**Status:** Open  
**Location:** JavaScript files  
**Impact:** Harder to filter logs  
**Fix:** Standardize all log prefixes to `[TWR Module]` format  
**Effort:** Low (1 hour)

#### BUG-L04: Magic numbers in statistics calculation
**Status:** Open  
**Location:** Statistics/analytics code  
**Impact:** Code clarity  
**Fix:** Extract to named constants  
**Effort:** Low (30 minutes)

#### BUG-L05: Learner export endpoint lacks CSRF
**Status:** Open  
**Location:** `app.py` learner export  
**Impact:** Very low - read-only endpoint  
**Fix:** Add CSRF for consistency (optional)  
**Effort:** Low (15 minutes)

#### BUG-L06: Minor unused imports
**Status:** Open  
**Location:** Various Python files  
**Impact:** Code cleanliness  
**Fix:** Run linter and remove unused imports  
**Effort:** Low (30 minutes)

#### BUG-L07: Batch limit constants not defined
**Status:** Open (Skipped Test)  
**Location:** `app.py`  
**Impact:** Test skipped; batch limits not enforced  
**Evidence:** Test `test_batch_constants_defined` skipped  
**Fix:** Define `MAX_BATCH_FILES`, `MAX_BATCH_SIZE` constants  
**Effort:** Low (30 minutes)

#### BUG-L08: Sound effects not discoverable
**Status:** Open  
**Location:** `static/js/features/sound-effects.js`  
**Impact:** Users don't know sounds exist (disabled by default)  
**Evidence:** Documented in NEXT_SESSION_PROMPT.md  
**Fix:** Add one-time tooltip or mention in Fix Assistant header  
**Effort:** Low (1 hour)

---

### ⚪ INFO / Enhancements (4 open)

#### ENH-001: Role consolidation engine
**Status:** Planned  
**Description:** Merge similar roles (Engineer/Engineers)  
**Effort:** Medium

#### ENH-002: Dictionary sharing
**Status:** Planned  
**Description:** Export/import role dictionaries for teams  
**Effort:** Medium

#### ENH-003: Graph export
**Status:** Planned  
**Description:** PNG/SVG download option for role graphs  
**Effort:** Medium

#### ENH-004: Multi-document comparison
**Status:** Planned  
**Description:** Side-by-side role analysis  
**Effort:** High

---

## Fixed Issues (Recent)

### ✅ v3.0.108 Fixes

| Bug ID | Description | File |
|--------|-------------|------|
| BUG-009 | Document filter dropdown not populated | role_integration.py, roles.js |

### ✅ v3.0.107 Fixes

| Bug ID | Description | File |
|--------|-------------|------|
| BUG-007 | Role Details missing sample_contexts | roles.js |
| BUG-008 | Role-Doc Matrix stuck on "Loading" | roles.js |

### ✅ v3.0.106 Fixes

| Bug ID | Description | File |
|--------|-------------|------|
| BUG-006 | Fix Assistant v2 Document Viewer empty (0 paragraphs) | core.py |
| BUG-M01 | Remaining deprecated datetime.utcnow() calls | config_logging.py |

### ✅ v3.0.105 Fixes

| Bug ID | Description | File |
|--------|-------------|------|
| BUG-001 | Report generator API signature mismatch | report_generator.py |
| BUG-002 | Learner stats missing success wrapper | app.py |
| BUG-003 | Acronym checker mode handling | acronym_checker.py |
| BUG-004 | Role classification tiebreak logic | role_extractor_v3.py |
| BUG-005 | Comment pack missing location hints | comment_inserter.py |
| WARN-001 | Deprecated datetime.utcnow() (partial) | app.py |

### ✅ v3.0.104 Fixes

| Bug ID | Description | File |
|--------|-------------|------|
| #1 | BodyText style conflict blocking FAv2 | report_generator.py |
| #2 | Logger reserved keyword conflict | app.py |
| #3 | Static file security test expectations | tests.py |
| #4 | CSS test location mismatches | tests.py |

### ✅ v3.0.98 Fixes

| Bug ID | Description |
|--------|-------------|
| BUG-001 | Double browser tab on startup |
| BUG-002 | Export modal crash |
| BUG-003 | Context highlighting showing wrong text |
| BUG-004 | Hyperlink status panel missing |
| BUG-005 | Version history gaps |
| BUG-007 | Role Details tab context preview |
| BUG-008 | Document filter dropdown |
| BUG-009 | Role-Document matrix tab missing |

### ✅ v3.0.97 Fixes (Fix Assistant v2 Integration)

| Issue | Description |
|-------|-------------|
| 1.1 | State.fixes never set |
| 1.2 | Backend missing FAV2 data fields |
| 2.1 | Job result endpoint missing FAV2 fields |
| 2.2 | Missing method stubs in FixAssistant API |
| 3.1 | Help documentation not updated |

---

## Testing Status

**Latest Test Run:** 2026-01-28  
**Result:** 117 tests passed, 1 skipped  
**Skipped Test:** `test_batch_constants_defined` (constants not yet defined)

### Test Coverage by Feature

| Feature | Tests | Status |
|---------|-------|--------|
| API Endpoints | 5 | ✅ Pass |
| Authentication | 4 | ✅ Pass |
| Acronym Checker | 6 | ✅ Pass |
| Analytics | 3 | ✅ Pass |
| Batch Limits | 2 | ⚠️ 1 Skip |
| Comment Inserter | 11 | ✅ Pass |
| Config | 4 | ✅ Pass |
| Error Handling | 2 | ✅ Pass |
| Export | 3 | ✅ Pass |
| File Validation | 4 | ✅ Pass |
| Fix Assistant v2 | 5 | ✅ Pass |
| Hyperlink Health | 6 | ✅ Pass |
| Role Extraction | 9 | ✅ Pass |
| Statement Forge | 4 | ✅ Pass |
| Static Security | 5 | ✅ Pass |
| UI Polish | 6 | ✅ Pass |
| Version | 3 | ✅ Pass |

---

## Prioritization Strategy

### Immediate (This Sprint)
1. **BUG-M01** - datetime deprecation fix (15 min, prevents future breaks)
2. **BUG-L07** - Define batch constants (30 min, unblocks skipped test)
3. **BUG-M04** - Add traceback to batch errors (30 min, debugging quality)

### Short-term (Next Sprint)
4. **BUG-M03** - SessionManager cleanup (2-3 hrs, prevents memory issues)
5. **BUG-M05** - Fix localStorage key collision (1 hr, data integrity)
6. **BUG-L03** - Standardize console prefixes (1 hr, maintainability)

### Medium-term (Backlog)
7. **BUG-M02** - Batch memory optimization (2-4 hrs)
8. **BUG-L01** - Update file header versions (30 min)
9. **BUG-L08** - Sound effects discoverability (1 hr)

### Low Priority (Tech Debt)
10. **BUG-L02** - Type hints (ongoing)
11. **BUG-L04** - Extract magic numbers (30 min)
12. **BUG-L05** - CSRF on learner export (15 min)
13. **BUG-L06** - Remove unused imports (30 min)

---

## Bug Reporting Template

When finding new bugs, add them with this format:

```markdown
#### BUG-XXX: [Brief Title]
**Status:** Open  
**Priority:** 🔴/🟡/🟢  
**Location:** `file.py` line XXX  
**Impact:** [What breaks or degrades]  
**Evidence:** [How you found it - test failure, user report, code review]  
**Steps to Reproduce:**
1. Step 1
2. Step 2
3. Expected: X, Actual: Y

**Fix:** [Proposed solution]  
**Effort:** Low/Medium/High (time estimate)
```

---

## Notes

- All 🔴 Critical bugs were fixed in v3.0.97-v3.0.105
- The skipped test is intentional (feature not yet implemented)
- Deprecation warnings don't break functionality but should be fixed before Python 3.14
- Memory-related issues (M02, M03) only affect long-running instances with heavy usage
