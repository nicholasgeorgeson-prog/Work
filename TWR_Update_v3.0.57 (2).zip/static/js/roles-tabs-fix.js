/**
 * TechWriterReview - Roles Tabs Fix (Robust Version)
 * v3.0.55c - Direct tab handling and content rendering
 * 
 * ISSUES FIXED:
 * 1. Tabs not switching properly
 * 2. No data loading when State.roles is empty
 * 3. Missing empty states for tabs without data
 */

(function() {
    'use strict';
    
    console.log('[TWR RolesTabs] Loading...');
    
    // Cache for API data
    const Cache = {
        aggregated: null,
        matrix: null,
        scanHistory: null,
        dictionary: null  // v3.0.56: fallback to dictionary when no scan data
    };
    
    /**
     * Escape HTML special characters
     */
    function escapeHtml(str) {
        if (str == null) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    
    /**
     * Show toast notification
     */
    function showToast(type, message) {
        if (typeof window.toast === 'function') {
            window.toast(type, message);
        } else if (window.TWR?.Modals?.toast) {
            window.TWR.Modals.toast(type, message);
        } else {
            console.log(`[TWR ${type}] ${message}`);
        }
    }
    
    /**
     * Fetch dictionary roles (fallback when no scan data)
     */
    async function fetchDictionary() {
        if (Cache.dictionary !== null) return Cache.dictionary;
        
        try {
            const response = await fetch('/api/roles/dictionary?include_inactive=false');
            const result = await response.json();
            
            if (result.success) {
                Cache.dictionary = result.data?.roles || [];
                console.log('[TWR RolesTabs] Loaded', Cache.dictionary.length, 'dictionary roles');
            } else {
                Cache.dictionary = [];
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Dictionary fetch error:', error);
            Cache.dictionary = [];
        }
        
        return Cache.dictionary;
    }
    
    /**
     * Fetch aggregated roles from API
     */
    async function fetchAggregatedRoles() {
        if (Cache.aggregated !== null) return Cache.aggregated;
        
        try {
            const response = await fetch('/api/roles/aggregated?include_deliverables=true');
            const result = await response.json();
            
            if (result.success) {
                Cache.aggregated = result.data || [];
                console.log('[TWR RolesTabs] Loaded', Cache.aggregated.length, 'aggregated roles');
            } else {
                console.warn('[TWR RolesTabs] API returned error:', result.error);
                Cache.aggregated = [];
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Fetch error:', error);
            Cache.aggregated = [];
        }
        
        return Cache.aggregated;
    }
    
    /**
     * Fetch role-document matrix from API
     */
    async function fetchMatrix() {
        if (Cache.matrix !== null) return Cache.matrix;
        
        try {
            const response = await fetch('/api/roles/matrix');
            const result = await response.json();
            
            if (result.success) {
                Cache.matrix = result.data || {};
                console.log('[TWR RolesTabs] Loaded matrix data');
            } else {
                Cache.matrix = {};
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Matrix fetch error:', error);
            Cache.matrix = {};
        }
        
        return Cache.matrix;
    }
    
    /**
     * Fetch scan history from API
     */
    async function fetchScanHistory() {
        if (Cache.scanHistory !== null) return Cache.scanHistory;
        
        try {
            const response = await fetch('/api/scan-history?limit=50');
            const result = await response.json();
            
            if (result.success) {
                Cache.scanHistory = result.data || [];
                console.log('[TWR RolesTabs] Loaded', Cache.scanHistory.length, 'scan history items');
            } else {
                Cache.scanHistory = [];
            }
        } catch (error) {
            console.error('[TWR RolesTabs] Scan history fetch error:', error);
            Cache.scanHistory = [];
        }
        
        return Cache.scanHistory;
    }
    
    /**
     * Create empty state HTML
     */
    function emptyState(icon, title, message) {
        return `
            <div class="empty-state" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;text-align:center;color:var(--text-muted);">
                <i data-lucide="${icon}" style="width:48px;height:48px;margin-bottom:16px;opacity:0.5;"></i>
                <h4 style="margin:0 0 8px 0;color:var(--text-secondary);">${title}</h4>
                <p style="margin:0;max-width:400px;">${message}</p>
            </div>
        `;
    }
    
    // =========================================================================
    // TAB RENDERERS
    // =========================================================================
    
    /**
     * Get category color for visualization
     */
    function getCategoryColor(category) {
        const colors = {
            'Management': '#1976d2',
            'Technical': '#388e3c', 
            'Program': '#7b1fa2',
            'Engineering': '#f57c00',
            'Quality': '#c2185b',
            'Support': '#0097a7',
            'Operations': '#5d4037',
            'Custom': '#607d8b',
            'Role': '#9e9e9e'
        };
        return colors[category] || colors['Role'];
    }
    
    /**
     * Render Overview tab
     */
    async function renderOverview() {
        console.log('[TWR RolesTabs] Rendering Overview...');
        
        let roles = await fetchAggregatedRoles();
        const history = await fetchScanHistory();
        let dataSource = 'scans';
        
        // Fallback to dictionary if no aggregated roles
        if (roles.length === 0) {
            roles = await fetchDictionary();
            dataSource = 'dictionary';
            console.log('[TWR RolesTabs] Falling back to dictionary data');
        }
        
        // Update stat cards
        const totalRoles = roles.length;
        const totalMentions = roles.reduce((sum, r) => sum + (r.total_mentions || 1), 0);
        const totalDocs = history.length || 0;
        
        // Get unique categories
        const categories = new Set(roles.map(r => r.category).filter(Boolean));
        
        // Update elements
        const els = {
            roles: document.getElementById('total-roles-count'),
            resp: document.getElementById('total-responsibilities-count'),
            docs: document.getElementById('total-documents-count'),
            interactions: document.getElementById('total-interactions-count'),
            sidebarRoles: document.getElementById('sidebar-roles-count'),
            sidebarResp: document.getElementById('sidebar-resp-count')
        };
        
        if (els.roles) els.roles.textContent = totalRoles;
        if (els.resp) els.resp.textContent = totalMentions;
        if (els.docs) els.docs.textContent = totalDocs;
        if (els.interactions) els.interactions.textContent = categories.size;
        if (els.sidebarRoles) els.sidebarRoles.textContent = totalRoles;
        if (els.sidebarResp) els.sidebarResp.textContent = totalMentions;
        
        // Show data source indicator
        const topRolesList = document.getElementById('top-roles-list');
        if (topRolesList) {
            let sourceNote = '';
            if (dataSource === 'dictionary') {
                sourceNote = `
                    <div style="padding:12px;background:var(--bg-tertiary,#fff3cd);border-radius:6px;margin-bottom:12px;font-size:12px;border:1px solid #ffc107;">
                        <i data-lucide="info" style="width:14px;height:14px;display:inline-block;vertical-align:middle;margin-right:6px;color:#856404;"></i>
                        <strong>Showing dictionary roles.</strong> Scan documents with "Role Extraction" enabled to see extracted roles with context and RACI data.
                    </div>
                `;
            }
            
            if (roles.length > 0) {
                const sorted = [...roles].sort((a, b) => (b.total_mentions || b.document_count || 1) - (a.total_mentions || a.document_count || 1));
                topRolesList.innerHTML = sourceNote + sorted.slice(0, 10).map((role, i) => {
                    const catColor = getCategoryColor(role.category);
                    const docInfo = role.document_count ? `${role.document_count} docs` : (role.source || 'dictionary');
                    return `
                    <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:var(--bg-secondary);border-radius:6px;margin-bottom:8px;border-left:3px solid ${catColor};">
                        <span style="font-weight:bold;color:var(--accent);min-width:24px;">${i + 1}</span>
                        <div style="flex:1;min-width:0;">
                            <div style="font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(role.role_name)}</div>
                            <div style="font-size:11px;color:var(--text-muted);">
                                <span style="padding:1px 6px;background:${catColor}20;color:${catColor};border-radius:3px;margin-right:6px;">${role.category || 'Role'}</span>
                                ${docInfo}
                            </div>
                        </div>
                        <div style="font-size:14px;font-weight:600;color:var(--accent);">${role.total_mentions || 1}</div>
                    </div>
                `}).join('');
            } else {
                topRolesList.innerHTML = `<p class="text-muted" style="padding:20px;text-align:center;">No roles found. Seed the dictionary or scan documents with "Role Extraction" enabled.</p>`;
            }
        }
        
        // Render distribution chart by category
        const chartContainer = document.getElementById('roles-distribution-chart');
        if (chartContainer && roles.length > 0) {
            // Group by category
            const categoryCount = {};
            roles.forEach(r => {
                const cat = r.category || 'Uncategorized';
                categoryCount[cat] = (categoryCount[cat] || 0) + 1;
            });
            
            const sortedCategories = Object.entries(categoryCount).sort((a, b) => b[1] - a[1]);
            const maxVal = Math.max(...sortedCategories.map(([, count]) => count));
            
            chartContainer.innerHTML = sortedCategories.map(([cat, count]) => {
                const pct = Math.max(5, (count / maxVal * 100));
                const color = getCategoryColor(cat);
                return `
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                        <span style="width:110px;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(cat)}">${escapeHtml(cat)}</span>
                        <div style="flex:1;height:18px;background:var(--bg-secondary);border-radius:3px;overflow:hidden;">
                            <div style="width:${pct}%;height:100%;background:${color};transition:width 0.3s;"></div>
                        </div>
                        <span style="width:40px;text-align:right;font-size:12px;color:var(--text-muted);">${count}</span>
                    </div>
                `;
            }).join('');
        } else if (chartContainer) {
            chartContainer.innerHTML = '<p class="text-muted text-center">No data for chart</p>';
        }
        
        refreshIcons();
    }
    
    /**
     * Render Details tab - shows rich role information
     */
    /**
     * Initialize Role Details controls (search input, sort dropdown)
     * v3.0.57: Ensures controls work when details tab is rendered
     */
    function initDetailsControls() {
        const State = window.State || window.TWR?.State?.get?.() || {};
        
        // Search input
        const searchInput = document.getElementById('roles-search');
        if (searchInput && !searchInput._tabsFixInitialized) {
            searchInput._tabsFixInitialized = true;
            searchInput.addEventListener('input', () => {
                filterDetailsRoles(searchInput.value);
            });
        }
        
        // Sort dropdown
        const sortSelect = document.getElementById('roles-sort');
        if (sortSelect && !sortSelect._tabsFixInitialized) {
            sortSelect._tabsFixInitialized = true;
            sortSelect.addEventListener('change', () => {
                State.detailsSort = sortSelect.value;
                console.log('[TWR RolesTabs] Details sort changed to:', sortSelect.value);
                renderDetails();
            });
        }
        
        console.log('[TWR RolesTabs] Details controls initialized');
    }
    
    /**
     * Filter role cards by search text
     */
    function filterDetailsRoles(searchText) {
        const filter = searchText.toLowerCase().trim();
        const cards = document.querySelectorAll('#roles-report-content > div[style*="border"]');
        
        cards.forEach(card => {
            const roleNameEl = card.querySelector('h4');
            const roleName = roleNameEl?.textContent?.toLowerCase() || '';
            const cardText = card.textContent?.toLowerCase() || '';
            
            if (!filter || roleName.includes(filter) || cardText.includes(filter)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
        
        console.log('[TWR RolesTabs] Filtered roles by:', filter || '(none)');
    }
    
    async function renderDetails() {
        console.log('[TWR RolesTabs] Rendering Details...');
        
        const container = document.getElementById('roles-report-content');
        if (!container) return;
        
        // Initialize controls
        initDetailsControls();
        
        let roles = await fetchAggregatedRoles();
        let dataSource = 'scans';
        
        // Fallback to dictionary if no aggregated roles
        if (roles.length === 0) {
            roles = await fetchDictionary();
            dataSource = 'dictionary';
        }
        
        if (roles.length === 0) {
            container.innerHTML = emptyState('users', 'No Roles Found', 
                'Seed the Role Dictionary or scan documents with "Role Extraction" enabled to detect organizational roles.');
            refreshIcons();
            return;
        }
        
        // Source indicator
        let sourceNote = '';
        if (dataSource === 'dictionary') {
            sourceNote = `
                <div style="padding:12px;background:var(--bg-tertiary,#fff3cd);border-radius:6px;margin-bottom:16px;font-size:12px;border:1px solid #ffc107;">
                    <i data-lucide="info" style="width:14px;height:14px;display:inline-block;vertical-align:middle;margin-right:6px;color:#856404;"></i>
                    <strong>Showing dictionary roles.</strong> Scan documents to see extracted context, responsibilities, and document associations.
                </div>
            `;
        }
        
        // Get sort preference
        const State = window.State || window.TWR?.State?.get?.() || {};
        const sortBy = State.detailsSort || document.getElementById('roles-sort')?.value || 'count-desc';
        
        // Sort roles based on selection
        const sorted = [...roles].sort((a, b) => {
            switch (sortBy) {
                case 'count-asc':
                    return (a.document_count || a.total_mentions || 1) - (b.document_count || b.total_mentions || 1);
                case 'alpha':
                    return (a.role_name || '').localeCompare(b.role_name || '');
                case 'count-desc':
                default:
                    return (b.document_count || b.total_mentions || 1) - (a.document_count || a.total_mentions || 1);
            }
        });
        
        container.innerHTML = sourceNote + sorted.map(role => {
            const catColor = getCategoryColor(role.category);
            const aliases = role.aliases?.length > 0 ? role.aliases.join(', ') : null;
            const description = role.description || null;
            const documents = role.documents?.length > 0 ? role.documents : null;
            
            return `
            <div style="border:1px solid var(--border-default);border-radius:8px;padding:16px;margin-bottom:12px;border-left:4px solid ${catColor};" data-role-name="${escapeHtml(role.role_name)}">
                <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:10px;">
                    <div>
                        <h4 style="margin:0 0 6px 0;font-size:16px;">${escapeHtml(role.role_name)}</h4>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <span style="font-size:11px;padding:2px 8px;background:${catColor}20;color:${catColor};border-radius:4px;font-weight:500;">${escapeHtml(role.category || 'Role')}</span>
                            ${role.source ? `<span style="font-size:11px;padding:2px 8px;background:var(--bg-secondary);border-radius:4px;">Source: ${escapeHtml(role.source)}</span>` : ''}
                            ${role.is_deliverable ? '<span style="font-size:11px;padding:2px 8px;background:#e3f2fd;color:#1976d2;border-radius:4px;">Deliverable</span>' : ''}
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:24px;font-weight:bold;color:var(--accent);">${role.document_count || role.total_mentions || 1}</div>
                        <div style="font-size:11px;color:var(--text-muted);">${role.document_count ? 'documents' : 'mentions'}</div>
                    </div>
                </div>
                
                ${description ? `
                <div style="margin-bottom:10px;padding:10px;background:var(--bg-secondary);border-radius:6px;">
                    <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px;">Description</div>
                    <div style="font-size:13px;">${escapeHtml(description)}</div>
                </div>
                ` : ''}
                
                ${aliases ? `
                <div style="margin-bottom:10px;">
                    <span style="font-size:12px;color:var(--text-muted);margin-right:8px;">Also known as:</span>
                    <span style="font-size:12px;">${escapeHtml(aliases)}</span>
                </div>
                ` : ''}
                
                ${documents ? `
                <div style="font-size:12px;">
                    <span style="color:var(--text-muted);margin-right:8px;">Found in:</span>
                    <span>${documents.slice(0, 5).map(d => `<span style="padding:2px 6px;background:var(--bg-secondary);border-radius:3px;margin-right:4px;">${escapeHtml(d)}</span>`).join('')}${documents.length > 5 ? `<span style="color:var(--text-muted);">+${documents.length - 5} more</span>` : ''}</span>
                </div>
                ` : ''}
                
                <div style="font-size:13px;color:var(--text-secondary);margin-top:8px;">
                    <strong>${role.total_mentions || 1}</strong> total mentions
                </div>
            </div>
        `}).join('');
        
        // Re-apply any existing search filter
        const searchInput = document.getElementById('roles-search');
        if (searchInput?.value) {
            filterDetailsRoles(searchInput.value);
        }
        
        refreshIcons();
    }
    
    /**
     * Render Cross-Reference tab (Role × Document count matrix)
     * NOTE: This tab requires actual scan data - dictionary roles don't have document associations
     */
    async function renderCrossRef() {
        console.log('[TWR RolesTabs] Rendering Cross-Reference...');
        
        const container = document.getElementById('crossref-matrix');
        if (!container) return;
        
        const matrix = await fetchMatrix();
        
        if (!matrix || !matrix.roles || Object.keys(matrix.roles).length === 0) {
            // Check if dictionary has data to show helpful message
            const dictRoles = await fetchDictionary();
            const hasDict = dictRoles.length > 0;
            
            container.innerHTML = `
                <div class="empty-state" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;text-align:center;color:var(--text-muted);">
                    <i data-lucide="table" style="width:48px;height:48px;margin-bottom:16px;opacity:0.5;"></i>
                    <h4 style="margin:0 0 8px 0;color:var(--text-secondary);">No Cross-Reference Data</h4>
                    <p style="margin:0 0 16px 0;max-width:450px;">
                        ${hasDict 
                            ? `You have <strong>${dictRoles.length} roles</strong> in your dictionary, but Cross-Reference requires scan data to show which roles appear in which documents.`
                            : 'Scan documents with "Role Extraction" enabled to see role distribution across documents.'
                        }
                    </p>
                    <div style="background:var(--bg-secondary);padding:16px;border-radius:8px;text-align:left;max-width:400px;">
                        <div style="font-weight:600;margin-bottom:8px;color:var(--text-primary);">To populate this tab:</div>
                        <ol style="margin:0;padding-left:20px;color:var(--text-secondary);font-size:13px;">
                            <li>Open a document (.docx or .pdf)</li>
                            <li>Enable "Role Extraction" in the sidebar</li>
                            <li>Click "Run Review"</li>
                            <li>Return here to see the matrix</li>
                        </ol>
                    </div>
                </div>
            `;
            refreshIcons();
            return;
        }
        
        const { documents = {}, roles = {}, connections = {} } = matrix;
        const docList = Object.entries(documents);
        const roleList = Object.entries(roles);
        
        if (roleList.length === 0 || docList.length === 0) {
            container.innerHTML = emptyState('table', 'Insufficient Data', 
                'Need at least one role and one document to display cross-reference.');
            refreshIcons();
            return;
        }
        
        // Sort roles by total mentions across all docs
        const roleTotals = {};
        roleList.forEach(([roleId, roleName]) => {
            let total = 0;
            if (connections[roleId]) {
                Object.values(connections[roleId]).forEach(count => total += count);
            }
            roleTotals[roleId] = total;
        });
        
        roleList.sort((a, b) => (roleTotals[b[0]] || 0) - (roleTotals[a[0]] || 0));
        
        // Calculate column totals for documents
        const docTotals = {};
        docList.forEach(([docId]) => {
            let total = 0;
            roleList.forEach(([roleId]) => {
                total += connections[roleId]?.[docId] || 0;
            });
            docTotals[docId] = total;
        });
        
        // Helper function for heatmap color
        function getHeatmapColor(count) {
            if (count === 0) return '';
            if (count <= 2) return 'background:#e3f2fd;';
            if (count <= 5) return 'background:#90caf9;';
            if (count <= 10) return 'background:#42a5f5;color:white;';
            return 'background:#1976d2;color:white;';
        }
        
        // Build table
        let html = `
            <table class="crossref-table" style="width:100%;border-collapse:collapse;font-size:12px;">
                <thead>
                    <tr>
                        <th style="text-align:left;padding:10px;border-bottom:2px solid var(--border-default);background:var(--bg-surface);position:sticky;left:0;top:0;z-index:2;min-width:160px;">
                            Role
                        </th>
        `;
        
        // Document headers
        docList.forEach(([docId, docName]) => {
            const shortName = docName.length > 18 ? docName.slice(0, 15) + '...' : docName;
            html += `
                <th style="padding:10px;border-bottom:2px solid var(--border-default);background:var(--bg-surface);position:sticky;top:0;z-index:1;min-width:80px;max-width:120px;text-align:center;" 
                    title="${escapeHtml(docName)}">
                    ${escapeHtml(shortName)}
                </th>
            `;
        });
        
        // Total column header
        html += `
            <th style="padding:10px;border-bottom:2px solid var(--border-default);background:var(--bg-tertiary,#f5f5f5);position:sticky;top:0;z-index:1;min-width:60px;text-align:center;font-weight:bold;">
                Total
            </th>
        </tr></thead><tbody>`;
        
        // Role rows
        roleList.forEach(([roleId, roleName]) => {
            const rowTotal = roleTotals[roleId] || 0;
            html += `
                <tr class="crossref-row" data-role="${escapeHtml(roleName)}">
                    <td style="padding:10px;border-bottom:1px solid var(--border-default);background:var(--bg-surface);position:sticky;left:0;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;" 
                        title="${escapeHtml(roleName)}">
                        ${escapeHtml(roleName)}
                    </td>
            `;
            
            // Cell for each document
            docList.forEach(([docId]) => {
                const count = connections[roleId]?.[docId] || 0;
                const colorStyle = getHeatmapColor(count);
                html += `
                    <td style="padding:10px;text-align:center;border-bottom:1px solid var(--border-default);${colorStyle}">
                        ${count || '-'}
                    </td>
                `;
            });
            
            // Row total
            html += `
                <td style="padding:10px;text-align:center;border-bottom:1px solid var(--border-default);background:var(--bg-tertiary,#f5f5f5);font-weight:bold;">
                    ${rowTotal}
                </td>
            </tr>`;
        });
        
        // Footer row with column totals
        html += `
            <tr class="crossref-totals" style="font-weight:bold;">
                <td style="padding:10px;border-top:2px solid var(--border-default);background:var(--bg-tertiary,#f5f5f5);position:sticky;left:0;">
                    Total
                </td>
        `;
        
        let grandTotal = 0;
        docList.forEach(([docId]) => {
            const colTotal = docTotals[docId] || 0;
            grandTotal += colTotal;
            html += `
                <td style="padding:10px;text-align:center;border-top:2px solid var(--border-default);background:var(--bg-tertiary,#f5f5f5);">
                    ${colTotal}
                </td>
            `;
        });
        
        html += `
            <td style="padding:10px;text-align:center;border-top:2px solid var(--border-default);background:var(--bg-tertiary,#f0f0f0);">
                ${grandTotal}
            </td>
        </tr></tbody></table>`;
        
        container.innerHTML = html;
        
        // Setup search filter
        const searchInput = document.getElementById('crossref-search');
        if (searchInput && !searchInput._filterInitialized) {
            searchInput._filterInitialized = true;
            searchInput.addEventListener('input', function() {
                const filter = this.value.toLowerCase();
                document.querySelectorAll('.crossref-row').forEach(row => {
                    const roleName = row.dataset.role?.toLowerCase() || '';
                    row.style.display = roleName.includes(filter) ? '' : 'none';
                });
            });
        }
        
        // Setup CSV export
        const exportBtn = document.getElementById('btn-crossref-export');
        if (exportBtn && !exportBtn._exportInitialized) {
            exportBtn._exportInitialized = true;
            exportBtn.addEventListener('click', function() {
                exportCrossRefCSV(roleList, docList, connections, roleTotals, docTotals);
            });
        }
        
        console.log('[TWR RolesTabs] Cross-Reference rendered with', roleList.length, 'roles ×', docList.length, 'documents');
    }
    
    /**
     * Export Cross-Reference as CSV
     */
    function exportCrossRefCSV(roleList, docList, connections, roleTotals, docTotals) {
        let csv = 'Role,' + docList.map(([, name]) => `"${name.replace(/"/g, '""')}"`).join(',') + ',Total\n';
        
        roleList.forEach(([roleId, roleName]) => {
            const row = [`"${roleName.replace(/"/g, '""')}"`];
            docList.forEach(([docId]) => {
                row.push(connections[roleId]?.[docId] || 0);
            });
            row.push(roleTotals[roleId] || 0);
            csv += row.join(',') + '\n';
        });
        
        // Totals row
        const totalsRow = ['Total'];
        let grandTotal = 0;
        docList.forEach(([docId]) => {
            totalsRow.push(docTotals[docId] || 0);
            grandTotal += docTotals[docId] || 0;
        });
        totalsRow.push(grandTotal);
        csv += totalsRow.join(',') + '\n';
        
        // Download
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'role_crossref_' + new Date().toISOString().slice(0, 10) + '.csv';
        link.click();
        URL.revokeObjectURL(url);
        
        showToast('success', 'Cross-reference exported to CSV');
    }
    
    /**
     * Initialize RACI matrix controls (sort dropdown, filter checkbox)
     * v3.0.57: Ensures controls work when matrix is rendered via roles-tabs-fix.js
     */
    function initRaciControls() {
        const State = window.State || window.TWR?.State?.get?.() || {};
        
        // Sort dropdown
        const sortSelect = document.getElementById('matrix-sort');
        if (sortSelect && !sortSelect._tabsFixInitialized) {
            sortSelect._tabsFixInitialized = true;
            sortSelect.addEventListener('change', () => {
                State.matrixSort = sortSelect.value;
                console.log('[TWR RolesTabs] Sort changed to:', sortSelect.value);
                // Re-render the matrix
                if (typeof window.TWR?.Roles?.renderRolesMatrix === 'function') {
                    window.TWR.Roles.renderRolesMatrix();
                } else if (typeof window.renderRolesMatrix === 'function') {
                    window.renderRolesMatrix();
                }
            });
        }
        
        // Filter checkbox
        const filterCritical = document.getElementById('matrix-filter-critical');
        if (filterCritical && !filterCritical._tabsFixInitialized) {
            filterCritical._tabsFixInitialized = true;
            filterCritical.addEventListener('change', () => {
                State.matrixFilterCritical = filterCritical.checked;
                console.log('[TWR RolesTabs] Filter critical changed to:', filterCritical.checked);
                // Re-render the matrix
                if (typeof window.TWR?.Roles?.renderRolesMatrix === 'function') {
                    window.TWR.Roles.renderRolesMatrix();
                } else if (typeof window.renderRolesMatrix === 'function') {
                    window.renderRolesMatrix();
                }
            });
        }
        
        // Reset button
        const resetBtn = document.getElementById('btn-raci-reset');
        if (resetBtn && !resetBtn._tabsFixInitialized) {
            resetBtn._tabsFixInitialized = true;
            resetBtn.addEventListener('click', () => {
                State.raciEdits = {};
                showToast('success', 'RACI matrix reset to detected values');
                if (typeof window.TWR?.Roles?.renderRolesMatrix === 'function') {
                    window.TWR.Roles.renderRolesMatrix();
                } else if (typeof window.renderRolesMatrix === 'function') {
                    window.renderRolesMatrix();
                }
            });
        }
        
        // Export button
        const exportBtn = document.getElementById('btn-raci-export');
        if (exportBtn && !exportBtn._tabsFixInitialized) {
            exportBtn._tabsFixInitialized = true;
            exportBtn.addEventListener('click', () => {
                if (typeof window.TWR?.Roles?.exportRaciMatrix === 'function') {
                    window.TWR.Roles.exportRaciMatrix();
                } else {
                    showToast('info', 'Export requires scan data');
                }
            });
        }
        
        console.log('[TWR RolesTabs] RACI controls initialized');
    }
    
    /**
     * Render Matrix tab - RACI assignments
     * RACI data requires actual document scans with action verb analysis.
     */
    async function renderMatrix() {
        console.log('[TWR RolesTabs] Rendering RACI Matrix...');
        
        const container = document.getElementById('responsibility-matrix');
        if (!container) {
            console.warn('[TWR RolesTabs] responsibility-matrix container not found');
            return;
        }
        
        // First try the original renderer if State.roles has data with action_types
        const State = window.State || window.TWR?.State?.get?.() || {};
        if (State.roles && Object.keys(State.roles).length > 0) {
            // Check if we have actual RACI data (action_types)
            const hasActionTypes = Object.values(State.roles).some(r => 
                r.action_types && Object.keys(r.action_types).length > 0
            );
            
            if (hasActionTypes) {
                // Original renderer uses 'matrix-container' but our HTML has 'responsibility-matrix'
                let matrixContainer = document.getElementById('matrix-container');
                if (!matrixContainer) {
                    container.innerHTML = '<div id="matrix-container"></div>';
                    matrixContainer = document.getElementById('matrix-container');
                }
                
                if (typeof window.TWR?.Roles?.renderRolesMatrix === 'function') {
                    window.TWR.Roles.renderRolesMatrix();
                    initRaciControls();  // v3.0.57: Initialize controls after render
                    return;
                } else if (typeof window.renderRolesMatrix === 'function') {
                    window.renderRolesMatrix();
                    initRaciControls();  // v3.0.57: Initialize controls after render
                    return;
                }
            }
        }
        
        // Initialize controls even when showing fallback (for when data loads later)
        initRaciControls();
        
        // Check for dictionary data to show helpful guidance
        let roles = await fetchAggregatedRoles();
        let dataSource = 'scans';
        
        if (roles.length === 0) {
            roles = await fetchDictionary();
            dataSource = 'dictionary';
        }
        
        if (roles.length === 0) {
            container.innerHTML = emptyState('grid-3x3', 'No RACI Data Available',
                'Scan a document with "Role Extraction" enabled to generate RACI assignments.');
            refreshIcons();
            return;
        }
        
        // Show explanation and role list without RACI assignments
        const catColors = {};
        roles.forEach(r => {
            if (r.category && !catColors[r.category]) {
                catColors[r.category] = getCategoryColor(r.category);
            }
        });
        
        let html = `
            <div style="padding:16px;background:var(--bg-tertiary,#fff3cd);border-radius:8px;margin-bottom:20px;border:1px solid #ffc107;">
                <div style="display:flex;align-items:start;gap:12px;">
                    <i data-lucide="alert-triangle" style="width:24px;height:24px;color:#856404;flex-shrink:0;margin-top:2px;"></i>
                    <div>
                        <div style="font-weight:600;color:#856404;margin-bottom:8px;">RACI Matrix Requires Document Scans</div>
                        <p style="margin:0 0 12px 0;font-size:13px;color:#856404;">
                            ${dataSource === 'dictionary' 
                                ? `You have <strong>${roles.length} roles</strong> in your dictionary, but RACI assignments (R/A/C/I) are computed by analyzing action verbs in documents.`
                                : 'RACI assignments are computed from action verbs like "shall perform", "approve", "review", "notify".'
                            }
                        </p>
                        <div style="font-size:12px;color:#856404;">
                            <strong>How RACI is detected:</strong>
                            <ul style="margin:8px 0 0 0;padding-left:20px;">
                                <li><strong>R</strong> (Responsible): "shall perform", "executes", "develops", "creates"</li>
                                <li><strong>A</strong> (Accountable): "approves", "authorizes", "owns", "certifies"</li>
                                <li><strong>C</strong> (Consulted): "reviews", "advises", "coordinates", "supports"</li>
                                <li><strong>I</strong> (Informed): "is notified", "receives reports", "monitors"</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 style="margin:0 0 12px 0;color:var(--text-secondary);">
                ${dataSource === 'dictionary' ? 'Dictionary Roles' : 'Known Roles'} (${roles.length})
            </h4>
            
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
        `;
        
        // Show roles as chips grouped by category
        const byCategory = {};
        roles.forEach(r => {
            const cat = r.category || 'Uncategorized';
            if (!byCategory[cat]) byCategory[cat] = [];
            byCategory[cat].push(r);
        });
        
        Object.entries(byCategory).sort((a, b) => b[1].length - a[1].length).slice(0, 10).forEach(([cat, catRoles]) => {
            const color = getCategoryColor(cat);
            html += `
                <div style="margin-bottom:12px;width:100%;">
                    <div style="font-size:12px;font-weight:600;color:${color};margin-bottom:6px;">${escapeHtml(cat)} (${catRoles.length})</div>
                    <div style="display:flex;flex-wrap:wrap;gap:6px;">
                        ${catRoles.slice(0, 15).map(r => `
                            <span style="padding:4px 10px;background:${color}15;border:1px solid ${color}40;border-radius:4px;font-size:12px;">${escapeHtml(r.role_name)}</span>
                        `).join('')}
                        ${catRoles.length > 15 ? `<span style="padding:4px 10px;color:var(--text-muted);font-size:12px;">+${catRoles.length - 15} more</span>` : ''}
                    </div>
                </div>
            `;
        });
        
        if (Object.keys(byCategory).length > 10) {
            html += `<div style="width:100%;color:var(--text-muted);font-size:12px;margin-top:8px;">+${Object.keys(byCategory).length - 10} more categories</div>`;
        }
        
        html += '</div>';
        
        container.innerHTML = html;
        refreshIcons();
    }
    
    /**
     * Render Adjudication tab - shows roles for review with richer context
     */
    async function renderAdjudication() {
        console.log('[TWR RolesTabs] Rendering Adjudication...');
        
        const container = document.getElementById('adjudication-list');
        if (!container) return;
        
        let roles = await fetchAggregatedRoles();
        let dataSource = 'scans';
        
        // Fallback to dictionary
        if (roles.length === 0) {
            roles = await fetchDictionary();
            dataSource = 'dictionary';
        }
        
        // Update stats
        const pendingEl = document.getElementById('adj-pending-count');
        const confirmedEl = document.getElementById('adj-confirmed-count');
        const deliverableEl = document.getElementById('adj-deliverable-count');
        const rejectedEl = document.getElementById('adj-rejected-count');
        
        // Count by status if available
        const pending = roles.filter(r => !r.status || r.status === 'pending').length;
        const confirmed = roles.filter(r => r.status === 'confirmed' || r.is_active === true).length;
        const deliverables = roles.filter(r => r.is_deliverable).length;
        const rejected = roles.filter(r => r.status === 'rejected' || r.is_active === false).length;
        
        if (pendingEl) pendingEl.textContent = pending || roles.length;
        if (confirmedEl) confirmedEl.textContent = confirmed || '0';
        if (deliverableEl) deliverableEl.textContent = deliverables;
        if (rejectedEl) rejectedEl.textContent = rejected || '0';
        
        if (roles.length === 0) {
            container.innerHTML = emptyState('check-circle', 'No Roles to Adjudicate',
                'Seed the Role Dictionary or scan documents with "Role Extraction" enabled to detect roles for review.');
            refreshIcons();
            return;
        }
        
        // Source indicator
        let sourceNote = '';
        if (dataSource === 'dictionary') {
            sourceNote = `
                <div style="padding:12px;background:var(--bg-tertiary,#e3f2fd);border-radius:6px;margin-bottom:16px;font-size:12px;border:1px solid #90caf9;">
                    <i data-lucide="info" style="width:14px;height:14px;display:inline-block;vertical-align:middle;margin-right:6px;color:#1976d2;"></i>
                    <strong>Showing dictionary roles.</strong> Scan documents to see extracted roles with document context and specific locations.
                </div>
            `;
        }
        
        container.innerHTML = sourceNote + roles.slice(0, 50).map(role => {
            const catColor = getCategoryColor(role.category);
            const documents = role.documents?.slice(0, 2).join(', ') || role.source_document || null;
            const description = role.description ? (role.description.length > 80 ? role.description.slice(0, 77) + '...' : role.description) : null;
            
            return `
            <div class="adjudication-item" data-role="${escapeHtml(role.role_name)}" data-role-id="${role.id || ''}"
                 style="display:flex;align-items:start;gap:12px;padding:14px 16px;border:1px solid var(--border-default);border-radius:8px;margin-bottom:10px;transition:all 0.15s;border-left:4px solid ${catColor};">
                <input type="checkbox" class="adj-item-checkbox" style="width:18px;height:18px;margin-top:2px;flex-shrink:0;">
                <div style="flex:1;min-width:0;">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                        <span style="font-weight:600;font-size:14px;">${escapeHtml(role.role_name)}</span>
                        <span style="font-size:10px;padding:2px 6px;background:${catColor}20;color:${catColor};border-radius:3px;font-weight:500;">${role.category || 'Role'}</span>
                        ${role.is_deliverable ? '<span style="font-size:10px;padding:2px 6px;background:#e3f2fd;color:#1976d2;border-radius:3px;">Deliverable</span>' : ''}
                    </div>
                    
                    ${description ? `
                    <div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;font-style:italic;">"${escapeHtml(description)}"</div>
                    ` : ''}
                    
                    <div style="font-size:11px;color:var(--text-muted);display:flex;flex-wrap:wrap;gap:8px;">
                        ${role.document_count ? `<span><strong>${role.document_count}</strong> documents</span>` : ''}
                        ${role.total_mentions ? `<span><strong>${role.total_mentions}</strong> mentions</span>` : ''}
                        ${role.source ? `<span>Source: <strong>${escapeHtml(role.source)}</strong></span>` : ''}
                        ${documents ? `<span>Found in: ${escapeHtml(documents)}${role.documents?.length > 2 ? '...' : ''}</span>` : ''}
                    </div>
                </div>
                <div style="display:flex;gap:6px;flex-shrink:0;">
                    <button class="btn btn-ghost btn-sm adj-btn-confirm" title="Confirm as Role" style="color:var(--success);padding:6px 8px;">
                        <i data-lucide="user-check" style="width:16px;height:16px;"></i>
                    </button>
                    <button class="btn btn-ghost btn-sm adj-btn-deliverable" title="Mark as Deliverable" style="color:var(--info);padding:6px 8px;">
                        <i data-lucide="package" style="width:16px;height:16px;"></i>
                    </button>
                    <button class="btn btn-ghost btn-sm adj-btn-reject" title="Reject" style="color:var(--error);padding:6px 8px;">
                        <i data-lucide="x-circle" style="width:16px;height:16px;"></i>
                    </button>
                </div>
            </div>
        `}).join('');
        
        if (roles.length > 50) {
            container.innerHTML += `<p style="text-align:center;color:var(--text-muted);font-size:12px;margin-top:12px;">Showing 50 of ${roles.length} roles</p>`;
        }
        
        refreshIcons();
    }
    
    /**
     * Render Documents tab
     */
    async function renderDocuments() {
        console.log('[TWR RolesTabs] Rendering Documents...');
        
        const tbody = document.getElementById('document-log-body');
        if (!tbody) {
            console.warn('[TWR RolesTabs] document-log-body not found');
            return;
        }
        
        const history = await fetchScanHistory();
        
        if (history.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">
                <i data-lucide="file-text" style="display:block;margin:0 auto 12px;width:32px;height:32px;opacity:0.5;"></i>
                No scan history. Open and scan documents to see them here.
            </td></tr>`;
            refreshIcons();
            return;
        }
        
        tbody.innerHTML = history.map(scan => {
            const date = new Date(scan.scan_time || scan.scanned_at || scan.created_at);
            const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            return `<tr>
                <td style="padding:10px;"><strong>${escapeHtml(scan.filename || 'Unknown')}</strong></td>
                <td style="padding:10px;">${dateStr}</td>
                <td style="padding:10px;text-align:center;">${scan.role_count ?? '-'}</td>
                <td style="padding:10px;text-align:center;">${scan.issue_count ?? '-'}</td>
                <td style="padding:10px;text-align:center;">${scan.grade || '-'}</td>
            </tr>`;
        }).join('');
    }
    
    /**
     * Refresh Lucide icons
     */
    function refreshIcons() {
        if (typeof lucide !== 'undefined' && lucide.createIcons) {
            try { lucide.createIcons(); } catch(e) { console.warn('Icon refresh failed:', e); }
        }
    }
    
    // =========================================================================
    // TAB SWITCHING
    // =========================================================================
    
    /**
     * Switch to a tab and render its content
     */
    async function switchToTab(tabName) {
        console.log('[TWR RolesTabs] === Switching to tab:', tabName, '===');
        
        // Update nav item active states
        const navItems = document.querySelectorAll('.roles-nav-item');
        console.log('[TWR RolesTabs] Updating', navItems.length, 'nav items');
        navItems.forEach(item => {
            const isActive = item.dataset.tab === tabName;
            item.classList.toggle('active', isActive);
            item.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
        
        // Hide ALL sections - remove active class and clear inline display
        const allSections = document.querySelectorAll('#modal-roles .roles-section');
        console.log('[TWR RolesTabs] Hiding', allSections.length, 'sections');
        allSections.forEach(section => {
            section.classList.remove('active');
            section.style.removeProperty('display'); // Let CSS handle it
        });
        
        // Show ONLY the target section by adding active class
        const targetSection = document.getElementById(`roles-${tabName}`);
        if (targetSection) {
            targetSection.classList.add('active');
            console.log('[TWR RolesTabs] Activated section: roles-' + tabName, 'classList:', targetSection.classList.toString());
        } else {
            console.warn('[TWR RolesTabs] Section not found: roles-' + tabName);
        }
        
        // Render tab content
        switch (tabName) {
            case 'overview':
                await renderOverview();
                break;
            case 'details':
                await renderDetails();
                break;
            case 'matrix':
                await renderMatrix();
                break;
            case 'adjudication':
                await renderAdjudication();
                break;
            case 'documents':
                await renderDocuments();
                break;
            case 'graph':
                // Graph uses its own renderer from roles.js
                if (typeof window.TWR?.Roles?.renderRolesGraph === 'function') {
                    window.TWR.Roles.renderRolesGraph();
                }
                break;
            case 'dictionary':
                // Dictionary uses our other fix
                if (typeof window.TWR?.DictFix?.loadDictionary === 'function') {
                    window.TWR.DictFix.loadDictionary();
                }
                break;
            case 'crossref':
                await renderCrossRef();
                break;
        }
        
        console.log('[TWR RolesTabs] === Tab switch complete ===');
    }
    
    /**
     * Initialize tab click handlers using event delegation
     * This is more robust than attaching to individual buttons
     */
    function initTabHandlers() {
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.warn('[TWR RolesTabs] modal-roles not found for tab handlers');
            return;
        }
        
        // Count nav items for debugging
        const navItems = modal.querySelectorAll('.roles-nav-item');
        console.log('[TWR RolesTabs] Found', navItems.length, 'nav items');
        
        // Remove any existing delegation handler
        if (modal._tabDelegationHandler) {
            modal.removeEventListener('click', modal._tabDelegationHandler, true);
        }
        
        // Create delegation handler
        modal._tabDelegationHandler = async function(e) {
            // Find if we clicked on a nav item or inside one
            const navItem = e.target.closest('.roles-nav-item');
            if (!navItem) return;
            
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            
            const tabName = navItem.dataset.tab;
            console.log('[TWR RolesTabs] Tab clicked:', tabName, 'element:', navItem);
            
            if (tabName) {
                await switchToTab(tabName);
            }
        };
        
        // Attach with capture phase to run before other handlers
        modal.addEventListener('click', modal._tabDelegationHandler, true);
        
        console.log('[TWR RolesTabs] Tab delegation handler attached to modal');
    }
    
    /**
     * Initialize when modal opens
     */
    function onModalOpen() {
        console.log('[TWR RolesTabs] Modal opened, loading initial data...');
        
        // Clear cache to get fresh data
        Cache.aggregated = null;
        Cache.dictionary = null;
        Cache.matrix = null;
        Cache.scanHistory = null;
        
        // Render the overview tab (default)
        switchToTab('overview');
    }
    
    /**
     * Setup modal observer
     */
    function setupModalObserver() {
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.warn('[TWR RolesTabs] modal-roles not found');
            return;
        }
        
        // Watch for modal visibility changes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes') {
                    const isVisible = modal.style.display !== 'none' && 
                                     !modal.classList.contains('hidden') &&
                                     modal.offsetParent !== null;
                    
                    if (isVisible && !modal._rolesTabsLoaded) {
                        modal._rolesTabsLoaded = true;
                        onModalOpen();
                    } else if (!isVisible) {
                        modal._rolesTabsLoaded = false;
                    }
                }
            });
        });
        
        observer.observe(modal, { attributes: true, attributeFilter: ['style', 'class'] });
        
        // Also check if already visible
        if (modal.style.display !== 'none' && modal.offsetParent !== null) {
            onModalOpen();
        }
    }
    
    /**
     * Setup modal close handlers
     */
    function setupCloseHandlers() {
        const modal = document.getElementById('modal-roles');
        if (!modal) return;
        
        // Close button
        modal.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', function() {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            });
        });
        
        // Click outside to close (on the modal backdrop)
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            }
        });
        
        // Escape key to close
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.style.display !== 'none') {
                modal.style.display = 'none';
                modal.classList.remove('active');
                document.body.classList.remove('modal-open');
            }
        });
    }
    
    // =========================================================================
    // INIT
    // =========================================================================
    
    function init() {
        initTabHandlers();
        setupModalObserver();
        setupCloseHandlers();
        console.log('[TWR RolesTabs] Fully initialized');
    }
    
    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Expose API
    window.TWR = window.TWR || {};
    window.TWR.RolesTabs = {
        switchToTab,
        renderOverview,
        renderDetails,
        renderMatrix,
        renderCrossRef,
        renderAdjudication,
        renderDocuments,
        fetchAggregatedRoles,
        fetchMatrix,
        fetchScanHistory,
        fetchDictionary,
        getCategoryColor,
        exportCrossRefCSV,
        initRaciControls,
        initDetailsControls,
        filterDetailsRoles
    };
    
    // =========================================================================
    // OVERRIDE: Allow opening Roles modal without a scan
    // The original showRolesModal() in roles.js blocks if State.roles is empty
    // =========================================================================
    
    /**
     * Show Roles modal - bypasses the "no roles detected" check
     */
    function showRolesModalOverride() {
        console.log('[TWR RolesTabs] Opening Roles modal (override)...');
        
        const modal = document.getElementById('modal-roles');
        if (!modal) {
            console.error('[TWR RolesTabs] modal-roles not found');
            return;
        }
        
        // Ensure tab handlers are attached
        initTabHandlers();
        
        // Show the modal
        modal.style.display = 'flex';
        modal.classList.add('active');
        document.body.classList.add('modal-open');
        
        // Clear any inline display styles from sections
        // Let CSS control visibility via .active class
        modal.querySelectorAll('.roles-section').forEach(section => {
            section.style.removeProperty('display');
            section.classList.remove('active');
        });
        
        // Clear cache and trigger data load
        Cache.aggregated = null;
        Cache.dictionary = null;
        Cache.matrix = null;
        Cache.scanHistory = null;
        modal._rolesTabsLoaded = true;
        
        // Switch to overview tab and load data
        switchToTab('overview');
        
        // Refresh icons
        refreshIcons();
    }
    
    /**
     * Override the global showRolesModal function
     */
    function installShowModalOverride() {
        // Override the global function
        window.showRolesModal = showRolesModalOverride;
        
        // Also override in TWR.Roles if it exists
        if (window.TWR?.Roles) {
            window.TWR.Roles.showRolesModal = showRolesModalOverride;
        }
        
        // Re-attach click handler to nav-roles button
        const navRoles = document.getElementById('nav-roles');
        if (navRoles) {
            // Remove any existing listeners by cloning
            const newNavRoles = navRoles.cloneNode(true);
            navRoles.parentNode.replaceChild(newNavRoles, navRoles);
            
            newNavRoles.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                showRolesModalOverride();
            });
            
            console.log('[TWR RolesTabs] nav-roles click handler installed');
        }
        
        // Also handle the footer button
        const btnRolesReport = document.getElementById('btn-roles-report');
        if (btnRolesReport) {
            // Enable the button
            btnRolesReport.disabled = false;
            btnRolesReport.removeAttribute('disabled');
            
            // Clone to remove existing handlers
            const newBtn = btnRolesReport.cloneNode(true);
            newBtn.disabled = false;
            btnRolesReport.parentNode.replaceChild(newBtn, btnRolesReport);
            
            newBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                showRolesModalOverride();
            });
            
            console.log('[TWR RolesTabs] btn-roles-report enabled and handler installed');
        }
        
        console.log('[TWR RolesTabs] showRolesModal override installed');
    }
    
    // Install override after a short delay to ensure other scripts have loaded
    setTimeout(installShowModalOverride, 100);
    
})();
