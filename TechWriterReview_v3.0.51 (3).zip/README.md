# TechWriterReview Installation

## Requirements
- Windows 10/11 or Windows Server 2016+
- Python 3.8 or later (https://python.org/downloads)
- ~500MB disk space

## Quick Install

1. **Extract** this ZIP to a temporary folder (e.g., `C:\TWR_Install`)

2. **Right-click** `INSTALL.ps1` → **Run with PowerShell**
   - Or open PowerShell and run: `.\INSTALL.ps1`

3. **Follow the prompts** - installation takes about 1-2 minutes

4. **Launch** using `Run_TWR.bat` in the install folder (default: `C:\TWR`)

5. **Open browser** to http://127.0.0.1:5050

## Custom Install Location

```powershell
.\INSTALL.ps1 -InstallPath "D:\Tools\TWR"
```

## Air-Gapped Installation

If you don't have internet access on the target machine:

1. On a machine with internet, download Python wheel files:
   ```
   pip download -r requirements.txt -d wheels/
   ```

2. Copy the wheels folder to the target machine

3. Install with:
   ```
   pip install --no-index --find-links=wheels/ -r requirements.txt
   ```

## Troubleshooting

**"Python not found"**
- Install Python 3.8+ from python.org
- Make sure "Add Python to PATH" is checked during installation

**"Module not found" errors**
- Delete the `.venv` folder in the install directory
- Re-run INSTALL.ps1

**Server won't start**
- Check if port 5050 is in use: `netstat -an | findstr 5050`
- Check logs in the `app/logs/` folder

## Files After Installation

```
C:\TWR\
├── Run_TWR.bat      # Start the server (auto-restarts on update)
├── Stop_TWR.bat     # Stop the server
├── .venv\           # Python virtual environment
├── updates\         # Drop update packages here
├── backups\         # Automatic backups before updates
└── app\             # Application files
    ├── app.py       # Main application
    ├── config.json  # Settings
    └── logs\        # Log files
```

## Version

TechWriterReview v3.0.51

## What's New in 3.0.51

- **Auto-restart on update**: When you apply updates from Settings → Updates,
  the server automatically restarts and refreshes your browser. No manual steps needed.
- **Fixed update detection**: "Check for Updates" now correctly shows available updates.
